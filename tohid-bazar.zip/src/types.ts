export type OrderStatus = 'pending' | 'confirmed' | 'processing' | 'shipped' | 'delivered' | 'cancelled';

export type PaymentMethod = 'cod' | 'bkash' | 'nagad' | 'online';

export interface ProductReview {
  id: string;
  userName: string;
  rating: number; // 1-5
  comment: string;
  date: string;
}

export interface Product {
  id: string;
  name: string;
  nameBn: string;
  category: string;
  categoryBn: string;
  brand: string;
  regularPrice: number;
  discountPrice: number;
  stock: number;
  sku: string;
  image: string;
  images?: string[];
  videoUrl?: string; // YouTube or video URL
  description: string;
  descriptionBn: string;
  rating: number;
  reviewCount: number;
  reviews?: ProductReview[];
  isFeatured?: boolean;
  isFlashSale?: boolean;
  isBestSelling?: boolean;
  isNewArrival?: boolean;
  unit?: string; // e.g., '1 pc', '1 kg'
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface OrderItem {
  productId: string;
  productName: string;
  productImage: string;
  price: number;
  quantity: number;
  total: number;
}

export interface Order {
  id: string; // e.g. TB-94821
  date: string;
  customerName: string;
  phoneNumber: string;
  district: string;
  upazila: string;
  address: string;
  note?: string;
  deliveryArea: 'inside_dhaka' | 'outside_dhaka';
  deliveryCharge: number;
  subtotal: number;
  discountAmount: number;
  couponCode?: string;
  grandTotal: number;
  paymentMethod: PaymentMethod;
  paymentStatus: 'unpaid' | 'paid' | 'verifying';
  transactionId?: string;
  senderNumber?: string;
  status: OrderStatus;
  items: OrderItem[];
  trackingTimeline: {
    status: OrderStatus;
    time: string;
    description: string;
  }[];
}

export interface Advertisement {
  id: string;
  title: string;
  placement: 'top_header' | 'home_middle' | 'sidebar' | 'footer';
  type: 'image' | 'adsterra' | 'adsense';
  imageUrl?: string;
  targetUrl?: string;
  adCode?: string; // HTML or script snippet
  isEnabled: boolean;
}

export interface Coupon {
  id: string;
  code: string;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  minOrderAmount: number;
  isActive: boolean;
  expiryDate?: string;
}

export interface SocialPost {
  id: string;
  title: string;
  titleBn: string;
  content: string;
  imageUrl?: string;
  videoUrl?: string; // YouTube video link
  date: string;
  likes: number;
  shares: number;
}

export interface WebsiteSettings {
  siteName: string;
  siteNameBn: string;
  sloganBn: string;
  logoText: string;
  announcementText: string;
  insideDhakaCharge: number;
  outsideDhakaCharge: number;
  freeDeliveryThreshold: number;
  whatsappNumber: string;
  phoneContact: string;
  emailContact: string;
  address: string;
  facebookUrl: string;
  youtubeUrl: string;
  instagramUrl: string;
  tiktokUrl: string;
  bkashNumber: string;
  bkashType: 'personal' | 'merchant';
  nagadNumber: string;
  nagadType: 'personal' | 'merchant';
  adminEmail: string;
  adminPasswordHash: string;
}

export interface District {
  name: string;
  nameBn: string;
}
