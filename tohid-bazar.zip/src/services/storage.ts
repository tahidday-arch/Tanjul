import { Product, Order, Advertisement, Coupon, SocialPost, WebsiteSettings, CartItem } from '../types';
import {
  INITIAL_PRODUCTS,
  INITIAL_ORDERS,
  INITIAL_ADVERTISEMENTS,
  INITIAL_COUPONS,
  INITIAL_POSTS,
  INITIAL_SETTINGS
} from '../data/initialData';

const KEYS = {
  PRODUCTS: 'tohid_bazar_products_v1',
  ORDERS: 'tohid_bazar_orders_v1',
  ADS: 'tohid_bazar_ads_v1',
  COUPONS: 'tohid_bazar_coupons_v1',
  POSTS: 'tohid_bazar_posts_v1',
  SETTINGS: 'tohid_bazar_settings_v1',
  CART: 'tohid_bazar_cart_v1',
  WISHLIST: 'tohid_bazar_wishlist_v1',
};

export const storageService = {
  getProducts(): Product[] {
    try {
      const data = localStorage.getItem(KEYS.PRODUCTS);
      return data ? JSON.parse(data) : INITIAL_PRODUCTS;
    } catch {
      return INITIAL_PRODUCTS;
    }
  },

  saveProducts(products: Product[]): void {
    localStorage.setItem(KEYS.PRODUCTS, JSON.stringify(products));
  },

  getOrders(): Order[] {
    try {
      const data = localStorage.getItem(KEYS.ORDERS);
      return data ? JSON.parse(data) : INITIAL_ORDERS;
    } catch {
      return INITIAL_ORDERS;
    }
  },

  saveOrders(orders: Order[]): void {
    localStorage.setItem(KEYS.ORDERS, JSON.stringify(orders));
  },

  addOrder(newOrder: Order): Order[] {
    const orders = this.getOrders();
    const updated = [newOrder, ...orders];
    this.saveOrders(updated);
    return updated;
  },

  updateOrderStatus(orderId: string, status: Order['status'], note?: string): Order[] {
    const orders = this.getOrders();
    const now = new Date().toLocaleString('bn-BD', { hour12: true });
    const updated = orders.map((ord) => {
      if (ord.id === orderId) {
        const timeline = ord.trackingTimeline || [];
        const statusDescriptions: Record<Order['status'], string> = {
          pending: 'অর্ডারটি সিস্টেমে জমা হয়েছে।',
          confirmed: 'অর্ডার নিশ্চিত করা হয়েছে।',
          processing: 'অর্ডারটি প্যাকিং ও প্রস্তুত করা হচ্ছে।',
          shipped: 'পণ্য কুরিয়ারে হস্তান্তর করা হয়েছে।',
          delivered: 'পণ্য সফলভাবে ক্রেতার কাছে পৌঁছে দেওয়া হয়েছে।',
          cancelled: 'অর্ডারটি বাতিল করা হয়েছে।'
        };

        return {
          ...ord,
          status,
          trackingTimeline: [
            ...timeline,
            {
              status,
              time: now,
              description: note || statusDescriptions[status] || `অবস্থা পরিবর্তন: ${status}`
            }
          ]
        };
      }
      return ord;
    });
    this.saveOrders(updated);
    return updated;
  },

  getAdvertisements(): Advertisement[] {
    try {
      const data = localStorage.getItem(KEYS.ADS);
      return data ? JSON.parse(data) : INITIAL_ADVERTISEMENTS;
    } catch {
      return INITIAL_ADVERTISEMENTS;
    }
  },

  saveAdvertisements(ads: Advertisement[]): void {
    localStorage.setItem(KEYS.ADS, JSON.stringify(ads));
  },

  getCoupons(): Coupon[] {
    try {
      const data = localStorage.getItem(KEYS.COUPONS);
      return data ? JSON.parse(data) : INITIAL_COUPONS;
    } catch {
      return INITIAL_COUPONS;
    }
  },

  saveCoupons(coupons: Coupon[]): void {
    localStorage.setItem(KEYS.COUPONS, JSON.stringify(coupons));
  },

  getPosts(): SocialPost[] {
    try {
      const data = localStorage.getItem(KEYS.POSTS);
      return data ? JSON.parse(data) : INITIAL_POSTS;
    } catch {
      return INITIAL_POSTS;
    }
  },

  savePosts(posts: SocialPost[]): void {
    localStorage.setItem(KEYS.POSTS, JSON.stringify(posts));
  },

  getSettings(): WebsiteSettings {
    try {
      const data = localStorage.getItem(KEYS.SETTINGS);
      if (data) {
        const parsed = JSON.parse(data);
        let modified = false;
        // Automatically upgrade previous placeholder values to the user's updated number
        if (!parsed.bkashNumber || parsed.bkashNumber === '01700000000') {
          parsed.bkashNumber = INITIAL_SETTINGS.bkashNumber;
          modified = true;
        }
        if (!parsed.whatsappNumber || parsed.whatsappNumber === '+8801700000000' || parsed.whatsappNumber === '01700000000') {
          parsed.whatsappNumber = INITIAL_SETTINGS.whatsappNumber;
          modified = true;
        }
        if (!parsed.nagadNumber || parsed.nagadNumber === '01800000000') {
          parsed.nagadNumber = INITIAL_SETTINGS.nagadNumber;
          modified = true;
        }
        if (!parsed.phoneContact || parsed.phoneContact === '+880 1700-000000') {
          parsed.phoneContact = INITIAL_SETTINGS.phoneContact;
          modified = true;
        }
        if (!parsed.adminEmail || parsed.adminEmail === 'admin@tohidbazar.com') {
          parsed.adminEmail = INITIAL_SETTINGS.adminEmail;
          modified = true;
        }
        if (!parsed.adminPasswordHash || parsed.adminPasswordHash === 'admin123') {
          parsed.adminPasswordHash = INITIAL_SETTINGS.adminPasswordHash;
          modified = true;
        }
        const merged = { ...INITIAL_SETTINGS, ...parsed };
        if (modified) {
          this.saveSettings(merged);
        }
        return merged;
      }
      return INITIAL_SETTINGS;
    } catch {
      return INITIAL_SETTINGS;
    }
  },

  saveSettings(settings: WebsiteSettings): void {
    localStorage.setItem(KEYS.SETTINGS, JSON.stringify(settings));
  },

  getCart(): CartItem[] {
    try {
      const data = localStorage.getItem(KEYS.CART);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveCart(cart: CartItem[]): void {
    localStorage.setItem(KEYS.CART, JSON.stringify(cart));
  },

  getWishlist(): string[] {
    try {
      const data = localStorage.getItem(KEYS.WISHLIST);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveWishlist(wishlist: string[]): void {
    localStorage.setItem(KEYS.WISHLIST, JSON.stringify(wishlist));
  },

  resetAllToDefault(): void {
    localStorage.removeItem(KEYS.PRODUCTS);
    localStorage.removeItem(KEYS.ORDERS);
    localStorage.removeItem(KEYS.ADS);
    localStorage.removeItem(KEYS.COUPONS);
    localStorage.removeItem(KEYS.POSTS);
    localStorage.removeItem(KEYS.SETTINGS);
    localStorage.removeItem(KEYS.CART);
    localStorage.removeItem(KEYS.WISHLIST);
  }
};
