import { Product, Order, Advertisement, Coupon, SocialPost, WebsiteSettings, District } from '../types';

export const BANGLADESH_DISTRICTS: District[] = [
  { name: 'Dhaka', nameBn: 'ঢাকা' },
  { name: 'Gazipur', nameBn: 'গাজীপুর' },
  { name: 'Narayanganj', nameBn: 'নারায়ণগঞ্জ' },
  { name: 'Chattogram', nameBn: 'চট্টগ্রাম' },
  { name: 'Cox\'s Bazar', nameBn: 'কক্সবাজার' },
  { name: 'Cumilla', nameBn: 'কুমিল্লা' },
  { name: 'Sylhet', nameBn: 'সিলেট' },
  { name: 'Rajshahi', nameBn: 'রাজশাহী' },
  { name: 'Bogura', nameBn: 'বগুড়া' },
  { name: 'Khulna', nameBn: 'খুলনা' },
  { name: 'Barishal', nameBn: 'বরিশাল' },
  { name: 'Rangpur', nameBn: 'রংপুর' },
  { name: 'Mymensingh', nameBn: 'ময়মনসিংহ' },
  { name: 'Tangail', nameBn: 'টাঙ্গাইল' },
  { name: 'Faridpur', nameBn: 'ফরিদপুর' },
  { name: 'Kishoreganj', nameBn: 'কিশোরগঞ্জ' },
  { name: 'Noakhali', nameBn: 'নোয়াখালী' },
  { name: 'Feni', nameBn: 'ফেনী' },
  { name: 'Brahmanbaria', nameBn: 'ব্রাহ্মণবাড়িয়া' },
  { name: 'Habiganj', nameBn: 'হবিগঞ্জ' },
  { name: 'Moulvibazar', nameBn: 'মৌলভীবাজার' },
  { name: 'Sunamganj', nameBn: 'সুনামগঞ্জ' },
  { name: 'Narsingdi', nameBn: 'নরসিংদী' },
  { name: 'Manikganj', nameBn: 'মানিকগঞ্জ' },
  { name: 'Munshiganj', nameBn: 'মুন্সীগঞ্জ' },
  { name: 'Pabna', nameBn: 'পাবনা' },
  { name: 'Sirajganj', nameBn: 'সিরাজগঞ্জ' },
  { name: 'Dinajpur', nameBn: 'দিনাজপুর' },
  { name: 'Jessore', nameBn: 'যশোর' },
  { name: 'Kushtia', nameBn: 'কুষ্টিয়া' },
];

export const INITIAL_CATEGORIES = [
  { id: 'all', name: 'All Categories', nameBn: 'সকল ক্যাটাগরি', icon: 'ShoppingBag', count: 12 },
  { id: 'grocery', name: 'Grocery & Organic', nameBn: 'গ্রোসারি ও অরগানিক', icon: 'Apple', count: 4, image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=500&auto=format&fit=crop&q=80' },
  { id: 'electronics', name: 'Electronics & Gadgets', nameBn: 'ইলেকট্রনিক্স ও গ্যাজেট', icon: 'Headphones', count: 3, image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500&auto=format&fit=crop&q=80' },
  { id: 'fashion', name: 'Fashion & Clothing', nameBn: 'ফ্যাশন ও পোশাক', icon: 'Shirt', count: 3, image: 'https://images.unsplash.com/photo-1489987707025-afc232f7ea0f?w=500&auto=format&fit=crop&q=80' },
  { id: 'home', name: 'Home & Kitchen', nameBn: 'হোম ও কিচেন', icon: 'Home', count: 2, image: 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?w=500&auto=format&fit=crop&q=80' },
  { id: 'beauty', name: 'Health & Beauty', nameBn: 'স্বাস্থ্য ও রূপচর্চা', icon: 'Sparkles', count: 2, image: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=500&auto=format&fit=crop&q=80' },
];

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prod-1',
    name: 'Tohid Premium Pure Honey 500g',
    nameBn: 'তৌহিদ প্রিমিয়াম খাঁটি সুন্দরবনের মধু ৫০০ গ্রাম',
    category: 'grocery',
    categoryBn: 'গ্রোসারি ও অরগানিক',
    brand: 'Tohid Organic',
    regularPrice: 750,
    discountPrice: 580,
    stock: 25,
    sku: 'TB-HONEY-01',
    image: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=800&auto=format&fit=crop&q=80',
    images: [
      'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1587049352851-8d4e89133924?w=800&auto=format&fit=crop&q=80'
    ],
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    description: '100% pure organic raw honey collected directly from the Sundarbans mangrove forest. Natural taste, unpasteurized, and full of health benefits.',
    descriptionBn: 'সুন্দরবনের প্রাকৃতিক চাক থেকে সংগৃহীত শতভাগ খাঁটি ও প্রাকৃতিক মধু। কোনো প্রকার রাসায়নিক বা চিনি মিশ্রণ ছাড়া প্রক্রিয়াজাত। প্রতিদিনের রোগ প্রতিরোধ ক্ষমতা বৃদ্ধি করে।',
    rating: 4.9,
    reviewCount: 42,
    isFeatured: true,
    isFlashSale: true,
    isBestSelling: true,
    unit: '৫০০ গ্রাম'
  },
  {
    id: 'prod-2',
    name: 'Premium Wireless Noise-Cancelling Earbuds TWS',
    nameBn: 'ওয়্যারলেস নয়েজ ক্যানসেলিং ব্লুটুথ ইয়ারবাডস TWS',
    category: 'electronics',
    categoryBn: 'ইলেকট্রনিক্স ও গ্যাজেট',
    brand: 'Acoustic Sound',
    regularPrice: 2200,
    discountPrice: 1450,
    stock: 18,
    sku: 'TB-TWS-02',
    image: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=800&auto=format&fit=crop&q=80',
    images: [
      'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1572536147248-ac59a8abfa4b?w=800&auto=format&fit=crop&q=80'
    ],
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    description: 'Bluetooth 5.3 earbuds with active noise cancellation, deep bass, 36 hours total battery backup with charging case, and water resistance.',
    descriptionBn: 'অ্যাক্টিভ নয়েজ ক্যান্সেলেশন এবং ডিপ বেস যুক্ত অত্যাধুনিক ব্লুটুথ ইয়ারবাডস। একবার চার্জে ৩৫ ঘণ্টার প্লে-ব্যাক টাইম এবং ওয়াটারপ্রুফ প্রযুক্তি।',
    rating: 4.8,
    reviewCount: 31,
    isFeatured: true,
    isFlashSale: true,
    isBestSelling: true,
    unit: '১ টি'
  },
  {
    id: 'prod-3',
    name: 'Traditional Mens Handloom Cotton Panjabi',
    nameBn: 'অভিজাত কটন খাদি হ্যান্ডলুম পাঞ্জাবি (আরামদায়ক)',
    category: 'fashion',
    categoryBn: 'ফ্যাশন ও পোশাক',
    brand: 'Tohid Crafts',
    regularPrice: 1850,
    discountPrice: 1290,
    stock: 12,
    sku: 'TB-PANJ-03',
    image: 'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=800&auto=format&fit=crop&q=80',
    images: [
      'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=800&auto=format&fit=crop&q=80'
    ],
    videoUrl: '',
    description: 'Authentic 100% fine cotton traditional men panjabi with intricate neck embroidery. Breathable, durable, and elegant for regular or festive wear.',
    descriptionBn: '১০০% পিওর কটন সুতায় বোনা আরামদায়ক খাদি পাঞ্জাবি। নিখুঁত সেলাই ও আকর্ষণীয় কলার ডিজাইন যা আপনাকে দেবে রাজকীয় লুক। যেকোনো অনুষ্ঠান বা প্রতিদিনের ব্যবহারের উপযোগী।',
    rating: 4.7,
    reviewCount: 19,
    isFeatured: true,
    isNewArrival: true,
    isBestSelling: false,
    unit: '১ সেট'
  },
  {
    id: 'prod-4',
    name: 'Smart Fitness Watch with Heart Rate & Blood Oxygen',
    nameBn: 'স্মার্ট ফিটনেস ওয়াচ (হার্ট রেট ও ব্লুটুথ কলিং)',
    category: 'electronics',
    categoryBn: 'ইলেকট্রনিক্স ও গ্যাজেট',
    brand: 'FitPro BD',
    regularPrice: 2800,
    discountPrice: 1890,
    stock: 8,
    sku: 'TB-SMART-04',
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop&q=80',
    images: [
      'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop&q=80'
    ],
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    description: '1.85 inch HD display smartwatch with Bluetooth calling, IP68 water resistance, multi-sport modes, and sleep monitor.',
    descriptionBn: 'বড় ১.৮৫ ইঞ্চি এইচডি কালার ডিসপ্লেসহ ব্লুটুথ কলিং স্মার্টওয়াচ। রক্তচাপ, হার্ট রেট এবং স্টেপ ট্র্যাকিং সুবিধা। ওয়াটারপ্রুফ এবং লং লাস্টিং ব্যাটারি।',
    rating: 4.9,
    reviewCount: 56,
    isFeatured: true,
    isFlashSale: true,
    isBestSelling: true,
    unit: '১ টি'
  },
  {
    id: 'prod-5',
    name: 'Cold Pressed Pure Mustard Oil 1 Litre',
    nameBn: 'ঘানির ভাঙা খাঁটি সরিষার তেল ১ লিটার',
    category: 'grocery',
    categoryBn: 'গ্রোসারি ও অরগানিক',
    brand: 'Tohid Organic',
    regularPrice: 380,
    discountPrice: 295,
    stock: 40,
    sku: 'TB-OIL-05',
    image: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=800&auto=format&fit=crop&q=80',
    images: [
      'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=800&auto=format&fit=crop&q=80'
    ],
    videoUrl: '',
    description: 'Authentic village wooden mill cold-pressed mustard oil with sharp natural pungency. Ideal for traditional cooking and authentic taste.',
    descriptionBn: 'গ্রামের ঐতিহ্যবাহী কাঠের ঘানিতে ভাঙানো প্রথম চাপের খাঁটি সরিষার তেল। ঝাঁজালো সুবাস এবং প্রাকৃতিকভাবে স্বাস্থ্যকর যা রান্নার স্বাদ বাড়ায় দ্বিগুণ।',
    rating: 4.8,
    reviewCount: 27,
    isFeatured: false,
    isNewArrival: true,
    isBestSelling: true,
    unit: '১ লিটার'
  },
  {
    id: 'prod-6',
    name: 'Multi-function Stainless Steel Kitchen Chopper',
    nameBn: 'মাল্টিফাংশন ফুড ও ভেজিটেবল চপার কাটার',
    category: 'home',
    categoryBn: 'হোম ও কিচেন',
    brand: 'KitchenMaster',
    regularPrice: 950,
    discountPrice: 650,
    stock: 14,
    sku: 'TB-CHOP-06',
    image: 'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=800&auto=format&fit=crop&q=80',
    images: [
      'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=800&auto=format&fit=crop&q=80'
    ],
    videoUrl: '',
    description: 'Quick hand-press food processor & vegetable chopper with stainless steel 4-layer blades. Cuts onions, garlic, and meat in seconds.',
    descriptionBn: 'রান্নার সময় বাঁচাতে চার স্তরবিশিষ্ট স্টেইনলেস স্টিল ব্লেডের দ্রুত কাটার চপার। পেঁয়াজ, রসুন, মরিচ এবং মাংস কুচি করুন খুব সহজেই কোনো ঝামেলা ছাড়া।',
    rating: 4.6,
    reviewCount: 14,
    isFeatured: false,
    isFlashSale: false,
    isNewArrival: true,
    unit: '১ পিস'
  },
  {
    id: 'prod-7',
    name: 'Natural Aloevera & Vitamin-E Face Wash & Gel',
    nameBn: 'ন্যাচারাল অ্যালোভেরা ও ভিটামিন-ই ফেস ওয়াশ ও জেল',
    category: 'beauty',
    categoryBn: 'স্বাস্থ্য ও রূপচর্চা',
    brand: 'BioGlow',
    regularPrice: 620,
    discountPrice: 480,
    stock: 22,
    sku: 'TB-GLOW-07',
    image: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=800&auto=format&fit=crop&q=80',
    images: [
      'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=800&auto=format&fit=crop&q=80'
    ],
    videoUrl: '',
    description: 'Gentle moisturizing face wash with natural aloe vera extract and Vitamin E. Cleans impurities, tightens pores, and gives radiant skin.',
    descriptionBn: 'শতভাগ প্রাকৃতিক ঘৃতকুমারী (অ্যালোভেরা) ও ভিটামিন ই সমৃদ্ধ ফেসওয়াশ। ত্বকের অতিরিক্ত তেল দূর করে প্রাকৃতিক কোমলতা ও উজ্জ্বলতা ফিরিয়ে আনে।',
    rating: 4.7,
    reviewCount: 23,
    isFeatured: true,
    isNewArrival: true,
    unit: '২০০ মিলি'
  },
  {
    id: 'prod-8',
    name: 'Premium Leather Bifold Wallet for Men',
    nameBn: '১০০% জেনুইন লেদার ওয়ালেট / মানিব্যাগ',
    category: 'fashion',
    categoryBn: 'ফ্যাশন ও পোশাক',
    brand: 'Tohid Crafts',
    regularPrice: 1100,
    discountPrice: 790,
    stock: 4, // low stock alert demo
    sku: 'TB-WALT-08',
    image: 'https://images.unsplash.com/photo-1627123424574-724758594e93?w=800&auto=format&fit=crop&q=80',
    images: [
      'https://images.unsplash.com/photo-1627123424574-724758594e93?w=800&auto=format&fit=crop&q=80'
    ],
    videoUrl: '',
    description: 'High grade cowhide leather wallet with RFID blocking, multiple card slots, coin pocket, and cash compartment.',
    descriptionBn: 'আসল চামড়ায় তৈরি টেকসই মানিব্যাগ। আরএফআইডি প্রটেকশনসহ অনেকগুলো কার্ড চেম্বার ও কয়েন পকেট। প্রিমিয়াম ফিনিশিং যা দীর্ঘস্থায়ী।',
    rating: 4.8,
    reviewCount: 38,
    isFeatured: true,
    isBestSelling: true,
    unit: '১ টি'
  },
  {
    id: 'prod-9',
    name: 'Premium Kalijira Rice (Aromatic) 5kg',
    nameBn: 'প্রিমিয়াম সুগন্ধি কালোজিরা পোলাও চাল ৫ কেজি',
    category: 'grocery',
    categoryBn: 'গ্রোসারি ও অরগানিক',
    brand: 'Tohid Organic',
    regularPrice: 850,
    discountPrice: 690,
    stock: 30,
    sku: 'TB-RICE-09',
    image: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=800&auto=format&fit=crop&q=80',
    images: [
      'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=800&auto=format&fit=crop&q=80'
    ],
    videoUrl: '',
    description: 'Aromatic small grain Kalijira rice for mouth-watering biryani, polao, and payesh. Naturally dried and stone-free sorted.',
    descriptionBn: 'সেরা মানের খাঁটি কালোজিরা সুবাসিত চাল। পোলাও, বিরিয়ানি ও পায়েশ রান্নায় অতুলনীয় সুবাস ছড়ায়। বাছাইকৃত পরিস্কার চাল।',
    rating: 4.9,
    reviewCount: 16,
    isFeatured: false,
    isBestSelling: true,
    unit: '৫ কেজি'
  }
];

export const INITIAL_ORDERS: Order[] = [
  {
    id: 'TB-98241',
    date: '2026-09-10 14:32',
    customerName: 'আরিফুল ইসলাম (Ariful Islam)',
    phoneNumber: '01711223344',
    district: 'Dhaka',
    upazila: 'Mirpur-10',
    address: 'বাড়ি # ৪২, রোড # ৬, ব্লক-সি, মিরপুর',
    note: 'সন্ধ্যার পর ডেলিভারি দিলে ভালো হয়',
    deliveryArea: 'inside_dhaka',
    deliveryCharge: 60,
    subtotal: 1450,
    discountAmount: 0,
    grandTotal: 1510,
    paymentMethod: 'cod',
    paymentStatus: 'unpaid',
    status: 'processing',
    items: [
      {
        productId: 'prod-2',
        productName: 'ওয়্যারলেস নয়েজ ক্যানসেলিং ব্লুটুথ ইয়ারবাডস TWS',
        productImage: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=800&auto=format&fit=crop&q=80',
        price: 1450,
        quantity: 1,
        total: 1450
      }
    ],
    trackingTimeline: [
      { status: 'pending', time: '2026-09-10 14:32', description: 'অর্ডারটি সিস্টেমে জমা হয়েছে।' },
      { status: 'confirmed', time: '2026-09-10 15:10', description: 'ফোন কলের মাধ্যমে অর্ডার নিশ্চিত করা হয়েছে।' },
      { status: 'processing', time: '2026-09-10 16:45', description: 'প্যাকেজিং এর কাজ চলছে।' }
    ]
  },
  {
    id: 'TB-98242',
    date: '2026-09-09 11:20',
    customerName: 'তানজিলা আক্তার (Tanjila Akter)',
    phoneNumber: '01822334455',
    district: 'Chattogram',
    upazila: 'GEC Circle',
    address: 'ফ্ল্যাট ৪বি, গ্রিন টাওয়ার, জিইসি মোড়',
    deliveryArea: 'outside_dhaka',
    deliveryCharge: 120,
    subtotal: 1160,
    discountAmount: 100,
    couponCode: 'WELCOME10',
    grandTotal: 1180,
    paymentMethod: 'bkash',
    paymentStatus: 'paid',
    transactionId: 'BK923847X1',
    senderNumber: '01822334455',
    status: 'shipped',
    items: [
      {
        productId: 'prod-1',
        productName: 'তৌহিদ প্রিমিয়াম খাঁটি সুন্দরবনের মধু ৫০০ গ্রাম',
        productImage: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=800&auto=format&fit=crop&q=80',
        price: 580,
        quantity: 2,
        total: 1160
      }
    ],
    trackingTimeline: [
      { status: 'pending', time: '2026-09-09 11:20', description: 'অর্ডার সাবমিট হয়েছে।' },
      { status: 'confirmed', time: '2026-09-09 11:45', description: 'বিকাশ পেমেন্ট যাচাই সম্পন্ন।' },
      { status: 'processing', time: '2026-09-09 14:00', description: 'প্যাকেজিং সম্পন্ন হয়েছে।' },
      { status: 'shipped', time: '2026-09-10 09:30', description: 'স্টেডফাস্ট কুরিয়ারে হস্তান্তর করা হয়েছে।' }
    ]
  }
];

export const INITIAL_ADVERTISEMENTS: Advertisement[] = [
  {
    id: 'ad-1',
    title: 'Top Banner - Flash Discount Offer',
    placement: 'top_header',
    type: 'image',
    imageUrl: 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=1200&auto=format&fit=crop&q=80',
    targetUrl: '#flash-sale',
    isEnabled: true
  },
  {
    id: 'ad-2',
    title: 'Middle Banner - Special Eid & Festive Discount',
    placement: 'home_middle',
    type: 'image',
    imageUrl: 'https://images.unsplash.com/photo-1607083206869-4c7672e72a8a?w=1200&auto=format&fit=crop&q=80',
    targetUrl: '#special-offers',
    isEnabled: true
  },
  {
    id: 'ad-3',
    title: 'Adsterra / Google AdSense Sponsored Box',
    placement: 'sidebar',
    type: 'adsense',
    adCode: '<div class="p-4 bg-amber-50 border border-amber-200 text-center rounded-xl"><span class="text-xs font-semibold text-amber-700 uppercase tracking-wider block mb-1">Sponsored Ad (Google AdSense / Adsterra Partner)</span><p class="text-sm font-medium text-slate-800">Best Quality Verified Products in Bangladesh. Fast Delivery to Your Doorstep!</p></div>',
    isEnabled: true
  }
];

export const INITIAL_COUPONS: Coupon[] = [
  {
    id: 'cp-1',
    code: 'TOHID10',
    discountType: 'percentage',
    discountValue: 10,
    minOrderAmount: 1000,
    isActive: true
  },
  {
    id: 'cp-2',
    code: 'EID50',
    discountType: 'fixed',
    discountValue: 50,
    minOrderAmount: 500,
    isActive: true
  }
];

export const INITIAL_POSTS: SocialPost[] = [
  {
    id: 'post-1',
    title: 'Sundarbans Pure Honey Unboxing & Review',
    titleBn: 'সুন্দরবনের খাঁটি মধুর আনবক্সিং এবং আসল মধু চেনার সহজ উপায়!',
    content: 'আজকে আমরা দেখাচ্ছি কীভাবে তৌহিদ বাজারের খাঁটি মধু সংগ্রহ করা হয় এবং খাঁটি মধু কীভাবে সহজে টেস্ট করবেন। বিস্তারিত জানতে ভিডিওটি দেখুন এবং বন্ধুদের সাথে শেয়ার করুন!',
    imageUrl: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=800&auto=format&fit=crop&q=80',
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    date: '2026-09-10',
    likes: 142,
    shares: 48
  },
  {
    id: 'post-2',
    title: 'Special Flash Sale Announcement 2026',
    titleBn: 'তৌহিদ বাজারে শুরু হয়েছে ধামাকা ফ্ল্যাশ সেল! সীমিত সময়ের অফার!',
    content: 'ইলেকট্রনিক্স ও প্রিমিয়াম গ্যাজেটে পাচ্ছেন ৫০% পর্যন্ত ক্যাশ ছাড়। স্টক সীমিত, তাই দেরি না করে এখনই অর্ডার করুন আপনার পছন্দের পণ্য।',
    imageUrl: 'https://images.unsplash.com/photo-1607083206869-4c7672e72a8a?w=800&auto=format&fit=crop&q=80',
    date: '2026-09-08',
    likes: 89,
    shares: 31
  }
];

export const INITIAL_SETTINGS: WebsiteSettings = {
  siteName: 'Tohid Bazar',
  siteNameBn: 'তৌহিদ বাজার',
  sloganBn: 'আপনার বিশ্বস্ত অনলাইন শপিং বাজার — সেরা পণ্য, দ্রুত ডেলিভারি',
  logoText: 'Tohid Bazar',
  announcementText: '🎉 তৌহিদ বাজারে স্বাগতম! সারা বাংলাদেশে ক্যাশ অন ডেলিভারি এবং ৭ দিনের সহজ রিটার্ন সুবিধা!',
  insideDhakaCharge: 60,
  outsideDhakaCharge: 120,
  freeDeliveryThreshold: 2500,
  whatsappNumber: '01858683583',
  phoneContact: '+880 1858-683583',
  emailContact: 'tahidday@gmail.com',
  address: 'মিরপুর-১০, ঢাকা, বাংলাদেশ',
  facebookUrl: 'https://facebook.com/tohidbazar',
  youtubeUrl: 'https://youtube.com/@tohidbazar',
  instagramUrl: 'https://instagram.com/tohidbazar',
  tiktokUrl: 'https://tiktok.com/@tohidbazar',
  bkashNumber: '01858683583',
  bkashType: 'personal',
  nagadNumber: '01858683583',
  nagadType: 'personal',
  adminEmail: 'rapeday8@gmail.com',
  adminPasswordHash: 'Tohid@123'
};
