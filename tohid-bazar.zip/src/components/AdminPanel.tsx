import React, { useState } from 'react';
import { 
  X, 
  LayoutDashboard, 
  ShoppingBag, 
  Package, 
  Megaphone, 
  Ticket, 
  Truck, 
  BarChart3, 
  Settings, 
  Plus, 
  Trash2, 
  Edit, 
  CheckCircle, 
  AlertTriangle, 
  DollarSign, 
  Users, 
  Search, 
  ExternalLink, 
  Phone, 
  MessageCircle,
  Eye,
  EyeOff,
  Mail,
  Key,
  LogOut,
  ShieldCheck,
  Save,
  RotateCcw,
  Check,
  Lock,
  Unlock,
  Video,
  Share2
} from 'lucide-react';
import { 
  Product, 
  Order, 
  Advertisement, 
  Coupon, 
  WebsiteSettings, 
  OrderStatus,
  SocialPost
} from '../types';
import { getWhatsAppUrl } from '../utils';

interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onAddProduct: (product: Product) => void;
  onUpdateProduct: (product: Product) => void;
  onDeleteProduct: (id: string) => void;
  orders: Order[];
  onUpdateOrderStatus: (orderId: string, status: OrderStatus, note?: string) => void;
  ads: Advertisement[];
  onToggleAd: (adId: string) => void;
  onAddAd: (ad: Advertisement) => void;
  onDeleteAd: (adId: string) => void;
  coupons: Coupon[];
  onAddCoupon: (coupon: Coupon) => void;
  onDeleteCoupon: (id: string) => void;
  settings: WebsiteSettings;
  onUpdateSettings: (settings: WebsiteSettings) => void;
  onResetToDefault: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  isOpen,
  onClose,
  products,
  onAddProduct,
  onUpdateProduct,
  onDeleteProduct,
  orders,
  onUpdateOrderStatus,
  ads,
  onToggleAd,
  onAddAd,
  onDeleteAd,
  coupons,
  onAddCoupon,
  onDeleteCoupon,
  settings,
  onUpdateSettings,
  onResetToDefault
}) => {
  // Authentication check - checks session storage
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem('tohid_bazar_admin_auth') === 'true';
    } catch {
      return false;
    }
  });
  const [adminEmailInput, setAdminEmailInput] = useState('');
  const [adminPasswordInput, setAdminPasswordInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [authError, setAuthError] = useState('');

  // Active Tab
  const [activeTab, setActiveTab] = useState<
    'dashboard' | 'orders' | 'products' | 'ads' | 'coupons' | 'delivery' | 'reports' | 'settings'
  >('dashboard');

  // Order filter & view
  const [orderStatusFilter, setOrderStatusFilter] = useState<string>('all');
  const [orderSearch, setOrderSearch] = useState('');
  const [viewingOrder, setViewingOrder] = useState<Order | null>(null);

  // Product Form modal state
  const [showProductModal, setShowProductModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [productForm, setProductForm] = useState<Partial<Product>>({
    name: '',
    nameBn: '',
    category: 'grocery',
    categoryBn: 'গ্রোসারি ও অরগানিক',
    brand: 'Tohid Bazar',
    regularPrice: 500,
    discountPrice: 450,
    stock: 20,
    sku: 'TB-NEW-01',
    image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=800&auto=format&fit=crop&q=80',
    videoUrl: '',
    description: '',
    descriptionBn: '',
    isFeatured: true,
    isFlashSale: false,
    unit: '১ টি'
  });

  // Settings form state
  const [settingsForm, setSettingsForm] = useState<WebsiteSettings>(settings);
  const [settingsSaved, setSettingsSaved] = useState(false);

  // Coupon form
  const [newCouponCode, setNewCouponCode] = useState('');
  const [newCouponType, setNewCouponType] = useState<'percentage' | 'fixed'>('percentage');
  const [newCouponValue, setNewCouponValue] = useState(10);
  const [newCouponMinOrder, setNewCouponMinOrder] = useState(500);

  // New Ad form
  const [newAdTitle, setNewAdTitle] = useState('');
  const [newAdPlacement, setNewAdPlacement] = useState<Advertisement['placement']>('home_middle');
  const [newAdType, setNewAdType] = useState<Advertisement['type']>('image');
  const [newAdImage, setNewAdImage] = useState('');
  const [newAdLink, setNewAdLink] = useState('');
  const [newAdCode, setNewAdCode] = useState('');

  if (!isOpen) return null;

  // Admin Login Verification
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const targetEmail = (settings.adminEmail || 'rapeday8@gmail.com').trim().toLowerCase();
    const targetPassword = (settings.adminPasswordHash || 'Tohid@123').trim();

    const inputEmail = adminEmailInput.trim().toLowerCase();
    const inputPassword = adminPasswordInput.trim();

    if (
      (inputEmail === targetEmail && inputPassword === targetPassword) ||
      (inputEmail === 'rapeday8@gmail.com' && inputPassword === 'Tohid@123')
    ) {
      setIsAuthenticated(true);
      try {
        sessionStorage.setItem('tohid_bazar_admin_auth', 'true');
      } catch {
        // ignore
      }
      setAuthError('');
    } else {
      if (inputEmail !== targetEmail && inputPassword !== targetPassword) {
        setAuthError('ভুল ইমেইল এবং পাসওয়ার্ড! অনুগ্রহ করে সঠিক তথ্য প্রদান করুন।');
      } else if (inputEmail !== targetEmail) {
        setAuthError('ভুল ইমেইল ঠিকানা! সঠিক এডমিন ইমেইল প্রদান করুন।');
      } else {
        setAuthError('ভুল পাসওয়ার্ড! সঠিক পাসওয়ার্ড প্রদান করুন।');
      }
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    try {
      sessionStorage.removeItem('tohid_bazar_admin_auth');
    } catch {
      // ignore
    }
    setAdminEmailInput('');
    setAdminPasswordInput('');
    setAuthError('');
  };

  const handleAutofillCredentials = () => {
    setAdminEmailInput(settings.adminEmail || 'rapeday8@gmail.com');
    setAdminPasswordInput(settings.adminPasswordHash || 'Tohid@123');
    setAuthError('');
  };

  // Metrics calculation
  const totalOrders = orders.length;
  const totalSales = orders.reduce((acc, o) => (o.status !== 'cancelled' ? acc + o.grandTotal : acc), 0);
  const totalProducts = products.length;
  const lowStockProducts = products.filter((p) => p.stock <= 5);
  const uniqueCustomers = new Set(orders.map((o) => o.phoneNumber)).size;

  // Filtered Orders
  const filteredOrders = orders.filter((o) => {
    const matchesStatus = orderStatusFilter === 'all' || o.status === orderStatusFilter;
    const matchesSearch = 
      o.id.toLowerCase().includes(orderSearch.toLowerCase()) ||
      o.customerName.toLowerCase().includes(orderSearch.toLowerCase()) ||
      o.phoneNumber.includes(orderSearch);
    return matchesStatus && matchesSearch;
  });

  // Save Product Handlers
  const handleOpenAddProduct = () => {
    setEditingProduct(null);
    setProductForm({
      name: '',
      nameBn: '',
      category: 'grocery',
      categoryBn: 'গ্রোসারি ও অরগানিক',
      brand: 'Tohid Bazar',
      regularPrice: 600,
      discountPrice: 480,
      stock: 20,
      sku: `TB-PROD-${Date.now().toString().slice(-4)}`,
      image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=800&auto=format&fit=crop&q=80',
      videoUrl: '',
      description: '',
      descriptionBn: '',
      isFeatured: true,
      isFlashSale: false,
      unit: '১ টি'
    });
    setShowProductModal(true);
  };

  const handleOpenEditProduct = (prod: Product) => {
    setEditingProduct(prod);
    setProductForm(prod);
    setShowProductModal(true);
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!productForm.nameBn || !productForm.discountPrice) return;

    if (editingProduct) {
      onUpdateProduct({
        ...editingProduct,
        ...productForm as Product
      });
    } else {
      const newProd: Product = {
        id: `prod-${Date.now()}`,
        name: productForm.name || productForm.nameBn || '',
        nameBn: productForm.nameBn || '',
        category: productForm.category || 'grocery',
        categoryBn: productForm.categoryBn || 'গ্রোসারি',
        brand: productForm.brand || 'Tohid Bazar',
        regularPrice: Number(productForm.regularPrice) || Number(productForm.discountPrice),
        discountPrice: Number(productForm.discountPrice),
        stock: Number(productForm.stock) || 0,
        sku: productForm.sku || `TB-${Date.now().toString().slice(-4)}`,
        image: productForm.image || 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=800&auto=format&fit=crop&q=80',
        videoUrl: productForm.videoUrl || '',
        description: productForm.description || '',
        descriptionBn: productForm.descriptionBn || '',
        rating: 5.0,
        reviewCount: 0,
        reviews: [],
        isFeatured: !!productForm.isFeatured,
        isFlashSale: !!productForm.isFlashSale,
        unit: productForm.unit || '১ টি'
      };
      onAddProduct(newProd);
    }

    setShowProductModal(false);
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSettings(settingsForm);
    setSettingsSaved(true);
    setTimeout(() => setSettingsSaved(false), 2500);
  };

  const handleAddCouponSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCouponCode.trim()) return;

    onAddCoupon({
      id: `cp-${Date.now()}`,
      code: newCouponCode.trim().toUpperCase(),
      discountType: newCouponType,
      discountValue: Number(newCouponValue),
      minOrderAmount: Number(newCouponMinOrder),
      isActive: true
    });

    setNewCouponCode('');
  };

  const handleAddAdSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAdTitle.trim()) return;

    onAddAd({
      id: `ad-${Date.now()}`,
      title: newAdTitle.trim(),
      placement: newAdPlacement,
      type: newAdType,
      imageUrl: newAdImage.trim() || undefined,
      targetUrl: newAdLink.trim() || '#',
      adCode: newAdCode.trim() || undefined,
      isEnabled: true
    });

    setNewAdTitle('');
    setNewAdImage('');
    setNewAdLink('');
    setNewAdCode('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/75 backdrop-blur-sm overflow-hidden animate-fade-in">
      <div className="bg-slate-900 text-slate-100 rounded-3xl max-w-6xl w-full h-[95vh] shadow-2xl flex flex-col overflow-hidden border border-slate-700">
        {/* Top Control Bar */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-400 text-slate-950 flex items-center justify-center font-black">
              👑
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-black text-white">
                  তৌহিদ বাজার — অ্যাডমিন কন্ট্রোল সেন্টার
                </h1>
                <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase">
                  Master Admin
                </span>
              </div>
              <p className="text-xs text-slate-400">ব্যবসায়িক ড্যাশবোর্ড, অর্ডার কন্ট্রোল, পণ্য, বিজ্ঞাপন ও ওয়েবসাইট নিয়ন্ত্রণ</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isAuthenticated && (
              <>
                <div className="hidden md:flex items-center gap-2 bg-slate-900 border border-slate-800 px-3 py-1 rounded-xl text-xs">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                  <span className="text-slate-300 font-mono text-[11px]">{settings.adminEmail || 'rapeday8@gmail.com'}</span>
                </div>
                <button
                  onClick={handleLogout}
                  className="text-xs text-rose-400 hover:text-white hover:bg-rose-600/30 border border-rose-500/30 bg-slate-900 px-3 py-1.5 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer"
                  title="লগআউট করুন"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">লগআউট</span>
                </button>
              </>
            )}
            <button
              onClick={() => {
                if (confirm('আপনি কি নিশ্চিত যে সমস্ত ডেটা ডিফল্ট অবস্থায় রিসেট করতে চান?')) {
                  onResetToDefault();
                }
              }}
              className="text-xs text-slate-400 hover:text-rose-400 bg-slate-800 px-3 py-1.5 rounded-xl transition-colors flex items-center gap-1 cursor-pointer"
              title="রিসেট ডেমো ডেটা"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">রিসেট ডেটা</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Lock Screen if unauthenticated */}
        {!isAuthenticated ? (
          <div className="flex-1 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
            <div className="max-w-md w-full bg-slate-800/95 p-6 sm:p-8 rounded-3xl border border-slate-700 shadow-2xl space-y-5">
              <div className="text-center space-y-2">
                <div className="w-16 h-16 bg-gradient-to-tr from-emerald-500 to-teal-400 text-slate-950 rounded-2xl flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/20">
                  <ShieldCheck className="w-8 h-8" />
                </div>
                <h2 className="text-xl font-black text-white">তৌহিদ বাজার — অ্যাডমিন লগইন</h2>
                <p className="text-xs text-slate-400">
                  অর্ডার, পণ্য ও সেটিংস পরিচালনা করতে নির্ধারিত অ্যাডমিন ইমেইল ও পাসওয়ার্ড দিয়ে লগইন করুন
                </p>
              </div>

              {/* Quick credential reminder & autofill */}
              <div className="bg-slate-900/90 border border-slate-700/80 rounded-2xl p-3.5 text-xs text-slate-300 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-amber-400 flex items-center gap-1">
                    <Key className="w-3.5 h-3.5" />
                    নির্ধারিত অ্যাডমিন ক্রেডেনশিয়াল:
                  </span>
                  <button
                    type="button"
                    onClick={handleAutofillCredentials}
                    className="text-[10px] bg-emerald-600/30 hover:bg-emerald-600/50 text-emerald-300 border border-emerald-500/40 px-2 py-0.5 rounded-lg transition-colors cursor-pointer font-bold"
                  >
                    অটো পূরণ করুন
                  </button>
                </div>
                <div className="font-mono text-[11px] bg-slate-950/70 p-2 rounded-xl space-y-1 text-slate-200">
                  <div><span className="text-slate-400">ইমেইল:</span> <span className="text-emerald-400 font-semibold">{settings.adminEmail || 'rapeday8@gmail.com'}</span></div>
                  <div><span className="text-slate-400">পাসওয়ার্ড:</span> <span className="text-amber-400 font-semibold">{settings.adminPasswordHash || 'Tohid@123'}</span></div>
                </div>
              </div>

              {authError && (
                <div className="text-xs text-rose-300 bg-rose-950/50 border border-rose-500/40 p-3 rounded-2xl flex items-center gap-2 animate-shake">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
                  <span>{authError}</span>
                </div>
              )}

              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-emerald-400" />
                    <span>অ্যাডমিন ইমেইল (Email)</span>
                  </label>
                  <input
                    type="email"
                    required
                    value={adminEmailInput}
                    onChange={(e) => setAdminEmailInput(e.target.value)}
                    placeholder="rapeday8@gmail.com"
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-amber-400" />
                    <span>অ্যাডমিন পাসওয়ার্ড (Password)</span>
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? "text" : "password"}
                      required
                      value={adminPasswordInput}
                      onChange={(e) => setAdminPasswordInput(e.target.value)}
                      placeholder="Tohid@123"
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 pr-10 text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white transition-colors cursor-pointer"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold py-3 rounded-xl shadow-lg shadow-emerald-600/30 transition-all cursor-pointer text-sm flex items-center justify-center gap-2 mt-2"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>অ্যাডমিন প্যানেলে প্রবেশ করুন</span>
                </button>
              </form>
            </div>
          </div>
        ) : (
          <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
            {/* Sidebar Navigation */}
            <div className="w-full md:w-60 bg-slate-950 border-r border-slate-800 p-3 flex md:flex-col gap-1 overflow-x-auto shrink-0">
              {[
                { id: 'dashboard', label: 'ড্যাশবোর্ড (Overview)', icon: LayoutDashboard },
                { id: 'orders', label: `অর্ডার সমূহ (${orders.length})`, icon: Package },
                { id: 'products', label: `পণ্য কন্ট্রোল (${products.length})`, icon: ShoppingBag },
                { id: 'ads', label: 'বিজ্ঞাপন (Ads & Banners)', icon: Megaphone },
                { id: 'coupons', label: 'কুপন ও ছাড় (Coupons)', icon: Ticket },
                { id: 'delivery', label: 'ডেলিভারি সেটিংস', icon: Truck },
                { id: 'reports', label: 'ব্যবসায়িক রিপোর্ট', icon: BarChart3 },
                { id: 'settings', label: 'ওয়েবসাইট কন্ট্রোল', icon: Settings }
              ].map((tab) => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as any)}
                    className={`flex items-center gap-2.5 px-3 py-2.5 rounded-2xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                      isActive
                        ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Main Content Area */}
            <div className="flex-1 bg-slate-900 p-4 sm:p-6 overflow-y-auto">
              {/* TAB 1: DASHBOARD */}
              {activeTab === 'dashboard' && (
                <div className="space-y-6">
                  <div>
                    <h2 className="text-xl font-bold text-white">ব্যবসায়িক ওভারভিউ (Dashboard)</h2>
                    <p className="text-xs text-slate-400">তৌহিদ বাজারের মোট বিক্রি, অর্ডার এবং পণ্যের লাইভ মেট্রিক্স</p>
                  </div>

                  {/* 4 Metric Cards */}
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700/80">
                      <div className="flex items-center justify-between text-slate-400 mb-2">
                        <span className="text-xs font-medium">মোট বিক্রি (Total Sales)</span>
                        <DollarSign className="w-4 h-4 text-emerald-400" />
                      </div>
                      <p className="text-xl sm:text-2xl font-black text-white">৳{totalSales.toLocaleString()}</p>
                      <span className="text-[11px] text-emerald-400 mt-1 block">সফল ডেলিভারি ও রানিং অর্ডার</span>
                    </div>

                    <div className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700/80">
                      <div className="flex items-center justify-between text-slate-400 mb-2">
                        <span className="text-xs font-medium">মোট অর্ডার (Total Orders)</span>
                        <Package className="w-4 h-4 text-indigo-400" />
                      </div>
                      <p className="text-xl sm:text-2xl font-black text-white">{totalOrders} টি</p>
                      <span className="text-[11px] text-slate-400 mt-1 block">সব চ্যানেল থেকে</span>
                    </div>

                    <div className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700/80">
                      <div className="flex items-center justify-between text-slate-400 mb-2">
                        <span className="text-xs font-medium">মোট ক্রেতা (Customers)</span>
                        <Users className="w-4 h-4 text-sky-400" />
                      </div>
                      <p className="text-xl sm:text-2xl font-black text-white">{uniqueCustomers} জন</p>
                      <span className="text-[11px] text-sky-400 mt-1 block">ইউনিক ফোন নম্বর</span>
                    </div>

                    <div className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700/80">
                      <div className="flex items-center justify-between text-slate-400 mb-2">
                        <span className="text-xs font-medium">মোট পণ্য (Products)</span>
                        <ShoppingBag className="w-4 h-4 text-amber-400" />
                      </div>
                      <p className="text-xl sm:text-2xl font-black text-white">{totalProducts} টি</p>
                      <span className="text-[11px] text-amber-400 mt-1 block">অ্যাক্টিভ ইনভেন্টরি</span>
                    </div>
                  </div>

                  {/* Low Stock Alert Box */}
                  {lowStockProducts.length > 0 && (
                    <div className="bg-amber-950/40 border border-amber-500/40 p-4 rounded-2xl">
                      <div className="flex items-center gap-2 text-amber-400 font-bold text-sm mb-2">
                        <AlertTriangle className="w-4 h-4" />
                        <span>লো স্টক অ্যালার্ট (Low Stock Alert - ৫টির নিচে মজুত আছে)</span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                        {lowStockProducts.map((lp) => (
                          <div key={lp.id} className="bg-slate-900/80 p-2.5 rounded-xl border border-amber-500/20 flex items-center justify-between text-xs">
                            <span className="text-slate-200 truncate max-w-[180px]">{lp.nameBn}</span>
                            <span className="font-bold text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded">
                              স্টক: {lp.stock}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Recent Orders Table Snapshot */}
                  <div className="bg-slate-800/60 rounded-2xl border border-slate-700 p-4">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-bold text-white text-sm">সাম্প্রতিক অর্ডার সমূহ (Recent Orders)</h3>
                      <button
                        onClick={() => setActiveTab('orders')}
                        className="text-xs text-emerald-400 hover:underline"
                      >
                        সব অর্ডার দেখুন ›
                      </button>
                    </div>

                    <div className="overflow-x-auto">
                      <table className="w-full text-xs text-left">
                        <thead className="text-slate-400 border-b border-slate-700">
                          <tr>
                            <th className="py-2">অর্ডার আইডি</th>
                            <th>গ্রাহক</th>
                            <th>তারিখ</th>
                            <th>পেমেন্ট</th>
                            <th>মোট বিল</th>
                            <th>স্ট্যাটাস</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-700/60">
                          {orders.slice(0, 4).map((ord) => (
                            <tr key={ord.id} className="hover:bg-slate-800/40">
                              <td className="py-2.5 font-mono text-emerald-400 font-bold">{ord.id}</td>
                              <td className="text-slate-200">{ord.customerName}</td>
                              <td className="text-slate-400">{ord.date}</td>
                              <td className="uppercase font-semibold text-slate-300">{ord.paymentMethod}</td>
                              <td className="font-bold text-white">৳{ord.grandTotal.toLocaleString()}</td>
                              <td>
                                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                                  ord.status === 'delivered' ? 'bg-emerald-500/20 text-emerald-400' :
                                  ord.status === 'cancelled' ? 'bg-rose-500/20 text-rose-400' :
                                  ord.status === 'shipped' ? 'bg-indigo-500/20 text-indigo-400' :
                                  'bg-amber-500/20 text-amber-400'
                                }`}>
                                  {ord.status}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: ORDER MANAGEMENT */}
              {activeTab === 'orders' && (
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <h2 className="text-xl font-bold text-white">অর্ডার কন্ট্রোল ও ম্যানেজমেন্ট</h2>
                      <p className="text-xs text-slate-400">নতুন অর্ডার পর্যালোচনা, স্ট্যাটাস পরিবর্তন ও গ্রাহকের সাথে যোগাযোগ</p>
                    </div>

                    {/* Order Search */}
                    <div className="relative">
                      <input
                        type="text"
                        value={orderSearch}
                        onChange={(e) => setOrderSearch(e.target.value)}
                        placeholder="আইডি বা ফোন দিয়ে খুঁজুন..."
                        className="bg-slate-800 border border-slate-700 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      />
                      <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                    </div>
                  </div>

                  {/* Filter Pills */}
                  <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
                    {[
                      { id: 'all', label: 'সকল' },
                      { id: 'pending', label: 'পেন্ডিং (Pending)' },
                      { id: 'confirmed', label: 'কনফার্মড' },
                      { id: 'processing', label: 'প্রসেসিং' },
                      { id: 'shipped', label: 'শিপড (কুরিয়ার)' },
                      { id: 'delivered', label: 'ডেলিভার্ড' },
                      { id: 'cancelled', label: 'বাতিল' }
                    ].map((f) => (
                      <button
                        key={f.id}
                        onClick={() => setOrderStatusFilter(f.id)}
                        className={`px-3 py-1.5 rounded-xl font-semibold transition-colors cursor-pointer ${
                          orderStatusFilter === f.id
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        {f.label}
                      </button>
                    ))}
                  </div>

                  {/* Orders Table */}
                  <div className="bg-slate-800/60 rounded-2xl border border-slate-700 overflow-hidden">
                    <div className="overflow-x-auto">
                      <table className="w-full text-xs text-left">
                        <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                          <tr>
                            <th className="p-3">অর্ডার আইডি</th>
                            <th className="p-3">তারিখ</th>
                            <th className="p-3">গ্রাহকের তথ্য</th>
                            <th className="p-3">ঠিকানা</th>
                            <th className="p-3">পেমেন্ট</th>
                            <th className="p-3">মোট বিল</th>
                            <th className="p-3">স্ট্যাটাস</th>
                            <th className="p-3 text-right">অ্যাকশন</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-700/60">
                          {filteredOrders.length === 0 ? (
                            <tr>
                              <td colSpan={8} className="p-8 text-center text-slate-400">
                                কোনো অর্ডার পাওয়া যায়নি।
                              </td>
                            </tr>
                          ) : (
                            filteredOrders.map((ord) => (
                              <tr key={ord.id} className="hover:bg-slate-800/40">
                                <td className="p-3 font-mono font-bold text-emerald-400">{ord.id}</td>
                                <td className="p-3 text-slate-400">{ord.date}</td>
                                <td className="p-3">
                                  <span className="font-bold text-white block">{ord.customerName}</span>
                                  <a href={`tel:${ord.phoneNumber}`} className="text-emerald-400 hover:underline">
                                    {ord.phoneNumber}
                                  </a>
                                </td>
                                <td className="p-3 max-w-[160px] truncate text-slate-300">
                                  {ord.address}, {ord.district}
                                </td>
                                <td className="p-3">
                                  <span className="uppercase font-bold text-slate-200 block">{ord.paymentMethod}</span>
                                  {ord.transactionId && (
                                    <span className="font-mono text-[10px] text-pink-400 block">Trx: {ord.transactionId}</span>
                                  )}
                                </td>
                                <td className="p-3 font-black text-white text-sm">৳{ord.grandTotal.toLocaleString()}</td>
                                <td className="p-3">
                                  {/* Quick Status Dropdown */}
                                  <select
                                    value={ord.status}
                                    onChange={(e) => onUpdateOrderStatus(ord.id, e.target.value as OrderStatus)}
                                    className="bg-slate-900 border border-slate-700 rounded-lg text-xs p-1 font-bold text-emerald-400 focus:outline-none"
                                  >
                                    <option value="pending">পেন্ডিং (Pending)</option>
                                    <option value="confirmed">কনফার্মড</option>
                                    <option value="processing">প্রসেসিং</option>
                                    <option value="shipped">শিপড (কুরিয়ার)</option>
                                    <option value="delivered">ডেলিভার্ড</option>
                                    <option value="cancelled">বাতিল (Cancel)</option>
                                  </select>
                                </td>
                                <td className="p-3 text-right space-x-1">
                                  {/* View Order Modal */}
                                  <button
                                    onClick={() => setViewingOrder(ord)}
                                    className="p-1.5 bg-slate-700 hover:bg-slate-600 rounded-lg text-slate-200 transition-colors"
                                    title="বিস্তারিত দেখুন"
                                  >
                                    <Eye className="w-3.5 h-3.5" />
                                  </button>

                                  {/* WhatsApp Direct Chat */}
                                  <a
                                    href={getWhatsAppUrl(ord.phoneNumber, `আসসালামু আলাইকুম ${ord.customerName}, তৌহিদ বাজার থেকে আপনার অর্ডার (${ord.id}) সম্পর্কে মেসেজ দেওয়া হয়েছে।`)}
                                    target="_blank"
                                    rel="noreferrer"
                                    className="inline-block p-1.5 bg-emerald-600/30 hover:bg-emerald-600 text-emerald-400 hover:text-white rounded-lg transition-colors"
                                    title="গ্রাহককে হোয়াটসঅ্যাপ মেসেজ দিন"
                                  >
                                    <MessageCircle className="w-3.5 h-3.5" />
                                  </a>
                                </td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {/* Detailed Order View Modal */}
                  {viewingOrder && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
                      <div className="bg-slate-900 text-white rounded-3xl max-w-lg w-full p-6 border border-slate-700 space-y-4 max-h-[90vh] overflow-y-auto">
                        <div className="flex justify-between items-center pb-3 border-b border-slate-800">
                          <div>
                            <h3 className="font-bold text-base">অর্ডার বিবরণী: {viewingOrder.id}</h3>
                            <span className="text-xs text-slate-400">{viewingOrder.date}</span>
                          </div>
                          <button onClick={() => setViewingOrder(null)} className="p-1 text-slate-400 hover:text-white">
                            <X className="w-5 h-5" />
                          </button>
                        </div>

                        {/* Customer & Address Details */}
                        <div className="bg-slate-800 p-4 rounded-2xl space-y-2 text-xs">
                          <p><span className="text-slate-400 font-medium">নাম: </span><span className="font-bold">{viewingOrder.customerName}</span></p>
                          <p><span className="text-slate-400 font-medium">মোবাইল: </span><span className="font-bold text-emerald-400">{viewingOrder.phoneNumber}</span></p>
                          <p><span className="text-slate-400 font-medium">জেলা ও উপজেলা: </span>{viewingOrder.district}, {viewingOrder.upazila}</p>
                          <p><span className="text-slate-400 font-medium">ঠিকানা: </span>{viewingOrder.address}</p>
                          {viewingOrder.note && <p><span className="text-amber-400 font-medium">নোট: </span>{viewingOrder.note}</p>}
                        </div>

                        {/* Payment Details */}
                        <div className="bg-slate-800 p-4 rounded-2xl space-y-1 text-xs">
                          <p><span className="text-slate-400 font-medium">পেমেন্ট মেথড: </span><span className="font-bold uppercase text-amber-400">{viewingOrder.paymentMethod}</span></p>
                          {viewingOrder.transactionId && (
                            <p><span className="text-slate-400 font-medium">TrxID: </span><span className="font-mono text-pink-400 font-bold">{viewingOrder.transactionId}</span></p>
                          )}
                          {viewingOrder.senderNumber && (
                            <p><span className="text-slate-400 font-medium">প্রেরকের নম্বর: </span>{viewingOrder.senderNumber}</p>
                          )}
                        </div>

                        {/* Items list */}
                        <div className="bg-slate-800 p-4 rounded-2xl space-y-2 text-xs">
                          <h4 className="font-bold text-slate-300 uppercase">পণ্যসমূহ ({viewingOrder.items.length})</h4>
                          {viewingOrder.items.map((it, idx) => (
                            <div key={idx} className="flex justify-between items-center py-1 border-b border-slate-700/50">
                              <span>{it.productName} × {it.quantity}</span>
                              <span className="font-bold">৳{it.total.toLocaleString()}</span>
                            </div>
                          ))}
                          <div className="pt-2 flex justify-between font-bold text-sm">
                            <span>সর্বমোট টাকা:</span>
                            <span className="text-emerald-400">৳{viewingOrder.grandTotal.toLocaleString()}</span>
                          </div>
                        </div>

                        {/* Change Status Buttons */}
                        <div className="space-y-2">
                          <label className="text-xs font-bold text-slate-300 block">স্ট্যাটাস আপডেট করুন:</label>
                          <div className="grid grid-cols-3 gap-2 text-xs">
                            {(['confirmed', 'processing', 'shipped', 'delivered', 'cancelled'] as OrderStatus[]).map((st) => (
                              <button
                                key={st}
                                onClick={() => {
                                  onUpdateOrderStatus(viewingOrder.id, st);
                                  setViewingOrder({ ...viewingOrder, status: st });
                                }}
                                className={`py-2 px-2 rounded-xl font-bold uppercase transition-colors cursor-pointer ${
                                  viewingOrder.status === st
                                    ? 'bg-emerald-600 text-white'
                                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                                }`}
                              >
                                {st}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* TAB 3: PRODUCTS CONTROL */}
              {activeTab === 'products' && (
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <h2 className="text-xl font-bold text-white">পণ্য নিয়ন্ত্রণ (Product Management)</h2>
                      <p className="text-xs text-slate-400">নতুন পণ্য যোগ করুন, দাম ও স্টক পরিবর্তন করুন অথবা পণ্য ডিলিট করুন</p>
                    </div>

                    <button
                      onClick={handleOpenAddProduct}
                      className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold px-4 py-2.5 rounded-2xl flex items-center gap-1.5 shadow-lg shadow-emerald-600/20 transition-all cursor-pointer self-start"
                    >
                      <Plus className="w-4 h-4" />
                      <span>নতুন পণ্য যোগ করুন (Add Product)</span>
                    </button>
                  </div>

                  {/* Products Grid / Table */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {products.map((p) => (
                      <div key={p.id} className="bg-slate-800/80 rounded-2xl border border-slate-700 p-3.5 flex flex-col justify-between">
                        <div>
                          <div className="relative aspect-video rounded-xl overflow-hidden bg-slate-900 mb-2.5">
                            <img src={p.image} alt={p.nameBn} className="w-full h-full object-cover" />
                            <span className="absolute top-2 left-2 bg-slate-950/80 text-emerald-400 text-[10px] font-bold px-2 py-0.5 rounded">
                              {p.categoryBn}
                            </span>
                            <span className="absolute bottom-2 right-2 bg-slate-950/80 text-white text-[10px] font-bold px-2 py-0.5 rounded font-mono">
                              স্টক: {p.stock}
                            </span>
                          </div>

                          <h3 className="font-bold text-white text-sm line-clamp-1">{p.nameBn}</h3>
                          <p className="text-xs text-slate-400 font-mono mt-0.5">SKU: {p.sku}</p>

                          <div className="mt-2 flex items-baseline gap-2">
                            <span className="font-black text-emerald-400 text-base">৳{p.discountPrice}</span>
                            {p.regularPrice > p.discountPrice && (
                              <span className="text-xs text-slate-500 line-through">৳{p.regularPrice}</span>
                            )}
                          </div>
                        </div>

                        {/* Action buttons */}
                        <div className="mt-4 pt-3 border-t border-slate-700/60 flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            {p.isFeatured && <span className="text-[10px] bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded">ফিচার্ড</span>}
                            {p.isFlashSale && <span className="text-[10px] bg-rose-500/20 text-rose-300 px-2 py-0.5 rounded">ফ্ল্যাশ সেল</span>}
                          </div>

                          <div className="flex items-center gap-1.5">
                            <button
                              onClick={() => handleOpenEditProduct(p)}
                              className="p-1.5 bg-slate-700 hover:bg-slate-600 rounded-lg text-slate-200 transition-colors"
                              title="এডিট করুন"
                            >
                              <Edit className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => {
                                if (confirm(`আপনি কি "${p.nameBn}" পণ্যটি মুছে ফেলতে চান?`)) {
                                  onDeleteProduct(p.id);
                                }
                              }}
                              className="p-1.5 bg-rose-900/40 hover:bg-rose-800 text-rose-300 rounded-lg transition-colors"
                              title="ডিলিট করুন"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Add / Edit Product Modal */}
                  {showProductModal && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
                      <div className="bg-slate-900 text-white rounded-3xl max-w-xl w-full p-6 border border-slate-700 space-y-4 max-h-[90vh] overflow-y-auto">
                        <div className="flex justify-between items-center pb-3 border-b border-slate-800">
                          <h3 className="font-bold text-base">
                            {editingProduct ? 'পণ্য এডিট করুন' : 'নতুন পণ্য যোগ করুন'}
                          </h3>
                          <button onClick={() => setShowProductModal(false)} className="p-1 text-slate-400 hover:text-white">
                            <X className="w-5 h-5" />
                          </button>
                        </div>

                        <form onSubmit={handleSaveProduct} className="space-y-4 text-xs">
                          <div>
                            <label className="font-bold text-slate-300 block mb-1">পণ্যের নাম (বাংলা) *</label>
                            <input
                              type="text"
                              required
                              value={productForm.nameBn || ''}
                              onChange={(e) => setProductForm({ ...productForm, nameBn: e.target.value })}
                              placeholder="e.g. প্রিমিয়াম মধু ৫০০ গ্রাম"
                              className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                            />
                          </div>

                          <div className="grid grid-cols-2 gap-3">
                            <div>
                              <label className="font-bold text-slate-300 block mb-1">ক্যাটাগরি</label>
                              <select
                                value={productForm.category || 'grocery'}
                                onChange={(e) => {
                                  const cats: Record<string, string> = {
                                    grocery: 'গ্রোসারি ও অরগানিক',
                                    electronics: 'ইলেকট্রনিক্স ও গ্যাজেট',
                                    fashion: 'ফ্যাশন ও পোশাক',
                                    home: 'হোম ও কিচেন',
                                    beauty: 'স্বাস্থ্য ও রূপচর্চা'
                                  };
                                  setProductForm({
                                    ...productForm,
                                    category: e.target.value,
                                    categoryBn: cats[e.target.value] || e.target.value
                                  });
                                }}
                                className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none"
                              >
                                <option value="grocery">গ্রোসারি ও অরগানিক</option>
                                <option value="electronics">ইলেকট্রনিক্স ও গ্যাজেট</option>
                                <option value="fashion">ফ্যাশন ও পোশাক</option>
                                <option value="home">হোম ও কিচেন</option>
                                <option value="beauty">স্বাস্থ্য ও রূপচর্চা</option>
                              </select>
                            </div>

                            <div>
                              <label className="font-bold text-slate-300 block mb-1">ব্র্যান্ড</label>
                              <input
                                type="text"
                                value={productForm.brand || ''}
                                onChange={(e) => setProductForm({ ...productForm, brand: e.target.value })}
                                placeholder="e.g. Tohid Organic"
                                className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none"
                              />
                            </div>
                          </div>

                          <div className="grid grid-cols-3 gap-3">
                            <div>
                              <label className="font-bold text-slate-300 block mb-1">সাধারণ মূল্য (৳)</label>
                              <input
                                type="number"
                                value={productForm.regularPrice || ''}
                                onChange={(e) => setProductForm({ ...productForm, regularPrice: Number(e.target.value) })}
                                className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none"
                              />
                            </div>

                            <div>
                              <label className="font-bold text-slate-300 block mb-1">ছাড়ের পর বিক্রয়মূল্য (৳) *</label>
                              <input
                                type="number"
                                required
                                value={productForm.discountPrice || ''}
                                onChange={(e) => setProductForm({ ...productForm, discountPrice: Number(e.target.value) })}
                                className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none"
                              />
                            </div>

                            <div>
                              <label className="font-bold text-slate-300 block mb-1">মজুত স্টক সংখ্যা</label>
                              <input
                                type="number"
                                value={productForm.stock || 0}
                                onChange={(e) => setProductForm({ ...productForm, stock: Number(e.target.value) })}
                                className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none"
                              />
                            </div>
                          </div>

                          <div>
                            <label className="font-bold text-slate-300 block mb-1">ছবির লিংক (Image URL)</label>
                            <input
                              type="url"
                              value={productForm.image || ''}
                              onChange={(e) => setProductForm({ ...productForm, image: e.target.value })}
                              placeholder="https://..."
                              className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none"
                            />
                          </div>

                          <div>
                            <label className="font-bold text-slate-300 block mb-1">ইউটিউব ভিডিও লিংক (YouTube Video URL - ঐচ্ছিক)</label>
                            <input
                              type="url"
                              value={productForm.videoUrl || ''}
                              onChange={(e) => setProductForm({ ...productForm, videoUrl: e.target.value })}
                              placeholder="https://www.youtube.com/watch?v=..."
                              className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none"
                            />
                          </div>

                          <div>
                            <label className="font-bold text-slate-300 block mb-1">পণ্যের বিস্তারিত বিবরণ (বাংলায়)</label>
                            <textarea
                              rows={3}
                              value={productForm.descriptionBn || ''}
                              onChange={(e) => setProductForm({ ...productForm, descriptionBn: e.target.value })}
                              placeholder="পণ্যের গুণাগুণ ও বৈশিষ্ট্য লিখুন..."
                              className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none"
                            />
                          </div>

                          <div className="flex items-center gap-6 pt-1">
                            <label className="flex items-center gap-2 cursor-pointer">
                              <input
                                type="checkbox"
                                checked={!!productForm.isFeatured}
                                onChange={(e) => setProductForm({ ...productForm, isFeatured: e.target.checked })}
                                className="w-4 h-4 text-emerald-600 rounded"
                              />
                              <span className="font-medium text-slate-300">ফিচার্ড পণ্য হিসেবে দেখান</span>
                            </label>

                            <label className="flex items-center gap-2 cursor-pointer">
                              <input
                                type="checkbox"
                                checked={!!productForm.isFlashSale}
                                onChange={(e) => setProductForm({ ...productForm, isFlashSale: e.target.checked })}
                                className="w-4 h-4 text-rose-600 rounded"
                              />
                              <span className="font-medium text-rose-300">ফ্ল্যাশ সেলে যুক্ত করুন</span>
                            </label>
                          </div>

                          <div className="pt-3 flex justify-end gap-2">
                            <button
                              type="button"
                              onClick={() => setShowProductModal(false)}
                              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition-colors cursor-pointer"
                            >
                              বাতিল
                            </button>
                            <button
                              type="submit"
                              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl transition-colors cursor-pointer"
                            >
                              সংরক্ষণ করুন (Save)
                            </button>
                          </div>
                        </form>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* TAB 4: ADVERTISEMENT SYSTEM */}
              {activeTab === 'ads' && (
                <div className="space-y-6">
                  <div>
                    <h2 className="text-xl font-bold text-white">বিজ্ঞাপন নিয়ন্ত্রণ (Advertisement System)</h2>
                    <p className="text-xs text-slate-400">
                      ওয়েবসাইটে ব্যানার বিজ্ঞাপন, Google AdSense অথবা Adsterra বিজ্ঞাপন ম্যানেজ ও শিডিউল করুন
                    </p>
                  </div>

                  {/* Add New Advertisement Form */}
                  <form onSubmit={handleAddAdSubmit} className="bg-slate-800/80 p-5 rounded-2xl border border-slate-700 space-y-4">
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <Plus className="w-4 h-4 text-emerald-400" />
                      <span>নতুন বিজ্ঞাপন যোগ করুন</span>
                    </h3>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                      <div>
                        <label className="font-bold text-slate-300 block mb-1">বিজ্ঞাপনের শিরোনাম</label>
                        <input
                          type="text"
                          required
                          value={newAdTitle}
                          onChange={(e) => setNewAdTitle(e.target.value)}
                          placeholder="e.g. মেগা ডিসকাউন্ট ব্যানার"
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="font-bold text-slate-300 block mb-1">বিজ্ঞাপনের অবস্থান (Placement)</label>
                        <select
                          value={newAdPlacement}
                          onChange={(e) => setNewAdPlacement(e.target.value as any)}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none"
                        >
                          <option value="top_header">উপরে (Top Header Banner)</option>
                          <option value="home_middle">হোমপেজের মাঝে (Home Middle)</option>
                          <option value="sidebar">সাইডবার (Sidebar Adsterra/AdSense)</option>
                          <option value="footer">ফুটার (Footer Banner)</option>
                        </select>
                      </div>

                      <div>
                        <label className="font-bold text-slate-300 block mb-1">বিজ্ঞাপনের ধরন (Type)</label>
                        <select
                          value={newAdType}
                          onChange={(e) => setNewAdType(e.target.value as any)}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none"
                        >
                          <option value="image">ইমেজ ব্যানার (Custom Image)</option>
                          <option value="adsense">Google AdSense কোড</option>
                          <option value="adsterra">Adsterra Ad Script কোড</option>
                        </select>
                      </div>
                    </div>

                    {newAdType === 'image' ? (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                        <div>
                          <label className="font-bold text-slate-300 block mb-1">ব্যানার ছবির লিংক (Image URL)</label>
                          <input
                            type="url"
                            value={newAdImage}
                            onChange={(e) => setNewAdImage(e.target.value)}
                            placeholder="https://..."
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="font-bold text-slate-300 block mb-1">ক্লিক লিংক (Target Link)</label>
                          <input
                            type="text"
                            value={newAdLink}
                            onChange={(e) => setNewAdLink(e.target.value)}
                            placeholder="#flash-sale অথবা URL"
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none"
                          />
                        </div>
                      </div>
                    ) : (
                      <div className="text-xs">
                        <label className="font-bold text-slate-300 block mb-1">HTML / Adsterra / Google AdSense কোড</label>
                        <textarea
                          rows={3}
                          value={newAdCode}
                          onChange={(e) => setNewAdCode(e.target.value)}
                          placeholder="<script>...</script> অথবা HTML ব্যানার কোড"
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white font-mono focus:outline-none"
                        />
                      </div>
                    )}

                    <div className="flex justify-end">
                      <button
                        type="submit"
                        className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl transition-colors cursor-pointer"
                      >
                        বিজ্ঞাপন যোগ করুন
                      </button>
                    </div>
                  </form>

                  {/* Active Ads List */}
                  <div className="space-y-3">
                    <h3 className="text-sm font-bold text-white">বর্তমান বিজ্ঞাপন তালিকা ({ads.length})</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {ads.map((ad) => (
                        <div key={ad.id} className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700 flex items-center justify-between gap-3">
                          <div className="space-y-1">
                            <span className="text-[10px] font-bold uppercase bg-slate-900 text-amber-400 px-2 py-0.5 rounded">
                              {ad.placement} · {ad.type}
                            </span>
                            <h4 className="font-bold text-white text-sm">{ad.title}</h4>
                            <p className="text-[11px] text-slate-400 truncate max-w-xs">{ad.imageUrl || ad.targetUrl || 'Code Banner'}</p>
                          </div>

                          <div className="flex items-center gap-2">
                            {/* Toggle Enable */}
                            <button
                              onClick={() => onToggleAd(ad.id)}
                              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                                ad.isEnabled 
                                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' 
                                  : 'bg-slate-700 text-slate-400'
                              }`}
                            >
                              {ad.isEnabled ? 'চালু (Enabled)' : 'বন্ধ (Disabled)'}
                            </button>

                            <button
                              onClick={() => onDeleteAd(ad.id)}
                              className="p-1.5 bg-rose-900/30 hover:bg-rose-900/60 text-rose-400 rounded-xl transition-colors"
                              title="ডিলিট"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 5: COUPONS */}
              {activeTab === 'coupons' && (
                <div className="space-y-6">
                  <div>
                    <h2 className="text-xl font-bold text-white">কুপন ও ছাড় নিয়ন্ত্রণ (Coupon & Discount)</h2>
                    <p className="text-xs text-slate-400">নতুন প্রোমো কোড তৈরি করুন যা ক্রেতারা চেকআউটে ব্যবহার করতে পারবে</p>
                  </div>

                  {/* Add Coupon Form */}
                  <form onSubmit={handleAddCouponSubmit} className="bg-slate-800/80 p-5 rounded-2xl border border-slate-700 space-y-4">
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <Ticket className="w-4 h-4 text-emerald-400" />
                      <span>নতুন কুপন কোড তৈরি করুন</span>
                    </h3>

                    <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
                      <div>
                        <label className="font-bold text-slate-300 block mb-1">কুপন কোড (Promo Code)</label>
                        <input
                          type="text"
                          required
                          value={newCouponCode}
                          onChange={(e) => setNewCouponCode(e.target.value.toUpperCase())}
                          placeholder="e.g. TOHID20"
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white font-mono uppercase focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="font-bold text-slate-300 block mb-1">ছাড়ের ধরন</label>
                        <select
                          value={newCouponType}
                          onChange={(e) => setNewCouponType(e.target.value as any)}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none"
                        >
                          <option value="percentage">শতকরা ছাড় (%)</option>
                          <option value="fixed">নির্দিষ্ট টাকা (৳ Flat)</option>
                        </select>
                      </div>

                      <div>
                        <label className="font-bold text-slate-300 block mb-1">ছাড়ের পরিমাণ</label>
                        <input
                          type="number"
                          required
                          value={newCouponValue}
                          onChange={(e) => setNewCouponValue(Number(e.target.value))}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="font-bold text-slate-300 block mb-1">ন্যূনতম অর্ডার মূল্য (৳)</label>
                        <input
                          type="number"
                          value={newCouponMinOrder}
                          onChange={(e) => setNewCouponMinOrder(Number(e.target.value))}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="flex justify-end">
                      <button
                        type="submit"
                        className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl transition-colors cursor-pointer"
                      >
                        কুপন তৈরি করুন
                      </button>
                    </div>
                  </form>

                  {/* Active Coupons */}
                  <div className="space-y-3">
                    <h3 className="text-sm font-bold text-white">সক্রিয় কুপন কোড সমূহ</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                      {coupons.map((c) => (
                        <div key={c.id} className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700 flex items-center justify-between">
                          <div>
                            <span className="font-mono text-base font-black text-amber-400 block">{c.code}</span>
                            <span className="text-xs text-slate-300 font-bold block mt-0.5">
                              {c.discountType === 'percentage' ? `${c.discountValue}% ছাড়` : `৳${c.discountValue} ছাড়`}
                            </span>
                            <span className="text-[11px] text-slate-500">মিনিমাম অর্ডার: ৳{c.minOrderAmount}</span>
                          </div>

                          <button
                            onClick={() => onDeleteCoupon(c.id)}
                            className="p-1.5 text-rose-400 hover:bg-rose-900/40 rounded-lg transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 6: DELIVERY SETTINGS */}
              {activeTab === 'delivery' && (
                <div className="space-y-6">
                  <div>
                    <h2 className="text-xl font-bold text-white">ডেলিভারি সিস্টেম ও চার্জ নিয়ন্ত্রণ</h2>
                    <p className="text-xs text-slate-400">ঢাকার ভিতরে ও সারা বাংলাদেশের ডেলিভারি চার্জ নির্ধারণ করুন</p>
                  </div>

                  <form onSubmit={handleSaveSettings} className="bg-slate-800/80 p-5 rounded-2xl border border-slate-700 space-y-4 max-w-xl text-xs">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="font-bold text-slate-300 block mb-1">ঢাকার ভেতরের ডেলিভারি চার্জ (৳)</label>
                        <input
                          type="number"
                          value={settingsForm.insideDhakaCharge}
                          onChange={(e) => setSettingsForm({ ...settingsForm, insideDhakaCharge: Number(e.target.value) })}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white font-bold text-sm focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="font-bold text-slate-300 block mb-1">ঢাকার বাইরের ডেলিভারি চার্জ (৳)</label>
                        <input
                          type="number"
                          value={settingsForm.outsideDhakaCharge}
                          onChange={(e) => setSettingsForm({ ...settingsForm, outsideDhakaCharge: Number(e.target.value) })}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white font-bold text-sm focus:outline-none"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="font-bold text-slate-300 block mb-1">ফ্রি ডেলিভারি অফারের ন্যূনতম অর্ডার মূল্য (৳)</label>
                      <input
                        type="number"
                        value={settingsForm.freeDeliveryThreshold}
                        onChange={(e) => setSettingsForm({ ...settingsForm, freeDeliveryThreshold: Number(e.target.value) })}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none"
                      />
                      <span className="text-[11px] text-slate-500 mt-1 block">এই পরিমাণের বেশি অর্ডারে ফ্রি ডেলিভারির সুবিধা প্রযোজ্য হবে</span>
                    </div>

                    <div className="pt-2">
                      <button
                        type="submit"
                        className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-5 py-2.5 rounded-xl transition-colors cursor-pointer flex items-center gap-2"
                      >
                        <Save className="w-4 h-4" />
                        <span>ডেলিভারি চার্জ সংরক্ষণ করুন</span>
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* TAB 7: BUSINESS REPORTS */}
              {activeTab === 'reports' && (
                <div className="space-y-6">
                  <div>
                    <h2 className="text-xl font-bold text-white">ব্যবসায়িক রিপোর্ট ও অ্যানালিটিক্স</h2>
                    <p className="text-xs text-slate-400">দৈনিক ও মাসিক বিক্রির হিসাব, অর্ডার ট্রেন্ড এবং মুনাফার প্রাক্কলন</p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="bg-slate-800 p-5 rounded-2xl border border-slate-700">
                      <span className="text-xs text-slate-400 block mb-1">মোট বিক্রির পরিমাণ</span>
                      <p className="text-2xl font-black text-emerald-400">৳{totalSales.toLocaleString()}</p>
                      <span className="text-[11px] text-slate-400 mt-1 block">সর্বমোট প্রাপ্ত আয়</span>
                    </div>

                    <div className="bg-slate-800 p-5 rounded-2xl border border-slate-700">
                      <span className="text-xs text-slate-400 block mb-1">আনুমানিক গ্রস প্রফিট (২৫%)</span>
                      <p className="text-2xl font-black text-amber-400">৳{Math.round(totalSales * 0.25).toLocaleString()}</p>
                      <span className="text-[11px] text-slate-400 mt-1 block">নিট লাভের আনুমানিক হিসাব</span>
                    </div>

                    <div className="bg-slate-800 p-5 rounded-2xl border border-slate-700">
                      <span className="text-xs text-slate-400 block mb-1">গড় অর্ডার সাইজ</span>
                      <p className="text-2xl font-black text-sky-400">
                        ৳{totalOrders > 0 ? Math.round(totalSales / totalOrders).toLocaleString() : 0}
                      </p>
                      <span className="text-[11px] text-slate-400 mt-1 block">প্রতি অর্ডারে গড় খরচ</span>
                    </div>
                  </div>

                  {/* Orders by Status breakdown */}
                  <div className="bg-slate-800 p-5 rounded-2xl border border-slate-700 space-y-3">
                    <h3 className="text-sm font-bold text-white">অর্ডারের স্ট্যাটাস অনুপাত</h3>
                    <div className="space-y-2 text-xs">
                      {(['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled'] as OrderStatus[]).map((st) => {
                        const count = orders.filter((o) => o.status === st).length;
                        const percentage = totalOrders > 0 ? Math.round((count / totalOrders) * 100) : 0;
                        return (
                          <div key={st} className="space-y-1">
                            <div className="flex justify-between text-slate-300">
                              <span className="uppercase font-bold">{st}</span>
                              <span>{count} টি ({percentage}%)</span>
                            </div>
                            <div className="w-full bg-slate-900 rounded-full h-2 overflow-hidden">
                              <div
                                className={`h-2 rounded-full ${
                                  st === 'delivered' ? 'bg-emerald-500' :
                                  st === 'cancelled' ? 'bg-rose-500' :
                                  st === 'shipped' ? 'bg-indigo-500' : 'bg-amber-500'
                                }`}
                                style={{ width: `${percentage}%` }}
                              />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 8: WEBSITE SETTINGS */}
              {activeTab === 'settings' && (
                <div className="space-y-6">
                  <div>
                    <h2 className="text-xl font-bold text-white">ওয়েবসাইট নিয়ন্ত্রণ ও সোশ্যাল মিডিয়া (Settings)</h2>
                    <p className="text-xs text-slate-400">
                      লোগো, ওয়েবসাইটের নাম, হোয়াটসঅ্যাপ নম্বর, বিকাশ/নগদ নম্বর এবং ফেসবুক/ইউটিউব লিংক পরিবর্তন করুন
                    </p>
                  </div>

                  {settingsSaved && (
                    <div className="p-3 bg-emerald-950/60 border border-emerald-500/40 rounded-xl flex items-center gap-2 text-emerald-400 text-xs font-bold">
                      <Check className="w-4 h-4" />
                      <span>ওয়েবসাইটের তথ্য সফলভাবে আপডেট করা হয়েছে!</span>
                    </div>
                  )}

                  <form onSubmit={handleSaveSettings} className="space-y-5 text-xs">
                    {/* Brand Identity */}
                    <div className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700 space-y-3">
                      <h3 className="text-sm font-bold text-white border-b border-slate-700 pb-2">ব্র্যান্ড ও শিরোনাম</h3>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="font-bold text-slate-300 block mb-1">ওয়েবসাইটের নাম (English)</label>
                          <input
                            type="text"
                            value={settingsForm.siteName}
                            onChange={(e) => setSettingsForm({ ...settingsForm, siteName: e.target.value })}
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="font-bold text-slate-300 block mb-1">ওয়েবসাইটের নাম (বাংলা)</label>
                          <input
                            type="text"
                            value={settingsForm.siteNameBn}
                            onChange={(e) => setSettingsForm({ ...settingsForm, siteNameBn: e.target.value })}
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="font-bold text-slate-300 block mb-1">টপ অ্যানাউন্সমেন্ট টেক্সট (Notice Bar)</label>
                        <input
                          type="text"
                          value={settingsForm.announcementText}
                          onChange={(e) => setSettingsForm({ ...settingsForm, announcementText: e.target.value })}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none"
                        />
                      </div>
                    </div>

                    {/* Payment Numbers */}
                    <div className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700 space-y-3">
                      <h3 className="text-sm font-bold text-white border-b border-slate-700 pb-2">বিকাশ ও নগদ পেমেন্ট নম্বর</h3>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="font-bold text-pink-400 block mb-1">বিকাশ নম্বর (bKash Number)</label>
                          <input
                            type="text"
                            value={settingsForm.bkashNumber}
                            onChange={(e) => setSettingsForm({ ...settingsForm, bkashNumber: e.target.value })}
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white font-mono focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="font-bold text-amber-400 block mb-1">নগদ নম্বর (Nagad Number)</label>
                          <input
                            type="text"
                            value={settingsForm.nagadNumber}
                            onChange={(e) => setSettingsForm({ ...settingsForm, nagadNumber: e.target.value })}
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white font-mono focus:outline-none"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Contact & Social Links */}
                    <div className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700 space-y-3">
                      <h3 className="text-sm font-bold text-white border-b border-slate-700 pb-2">যোগাযোগ ও সোশ্যাল মিডিয়া লিংক</h3>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="font-bold text-slate-300 block mb-1">হোয়াটসঅ্যাপ নম্বর (WhatsApp)</label>
                          <input
                            type="text"
                            value={settingsForm.whatsappNumber}
                            onChange={(e) => setSettingsForm({ ...settingsForm, whatsappNumber: e.target.value })}
                            placeholder="+8801700000000"
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white font-mono focus:outline-none"
                          />
                        </div>

                        <div>
                          <label className="font-bold text-slate-300 block mb-1">ফোন নম্বর (Helpline)</label>
                          <input
                            type="text"
                            value={settingsForm.phoneContact}
                            onChange={(e) => setSettingsForm({ ...settingsForm, phoneContact: e.target.value })}
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none"
                          />
                        </div>

                        <div>
                          <label className="font-bold text-slate-300 block mb-1">ফেসবুক পেজ লিংক (Facebook URL)</label>
                          <input
                            type="url"
                            value={settingsForm.facebookUrl}
                            onChange={(e) => setSettingsForm({ ...settingsForm, facebookUrl: e.target.value })}
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none"
                          />
                        </div>

                        <div>
                          <label className="font-bold text-slate-300 block mb-1">ইউটিউব চ্যানেল লিংক (YouTube URL)</label>
                          <input
                            type="url"
                            value={settingsForm.youtubeUrl}
                            onChange={(e) => setSettingsForm({ ...settingsForm, youtubeUrl: e.target.value })}
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Admin Access & Security Credentials */}
                    <div className="bg-slate-800/80 p-4 rounded-2xl border border-amber-500/40 space-y-3">
                      <div className="flex items-center gap-2 border-b border-slate-700 pb-2">
                        <ShieldCheck className="w-4 h-4 text-amber-400" />
                        <h3 className="text-sm font-bold text-white">অ্যাডমিন অ্যাক্সেস ক্রেডেনশিয়াল (Admin Login Settings)</h3>
                      </div>
                      <p className="text-[11px] text-slate-400">
                        অ্যাডমিন কন্ট্রোল সেন্টারে লগইন করার জন্য ইমেইল ও পাসওয়ার্ড পরিচালনা করুন।
                      </p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="font-bold text-emerald-400 block mb-1">অ্যাডমিন ইমেইল (Admin Email)</label>
                          <input
                            type="email"
                            required
                            value={settingsForm.adminEmail || 'rapeday8@gmail.com'}
                            onChange={(e) => setSettingsForm({ ...settingsForm, adminEmail: e.target.value })}
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white font-mono focus:outline-none focus:ring-1 focus:ring-emerald-500"
                          />
                        </div>
                        <div>
                          <label className="font-bold text-amber-400 block mb-1">অ্যাডমিন পাসওয়ার্ড (Admin Password)</label>
                          <input
                            type="text"
                            required
                            value={settingsForm.adminPasswordHash || 'Tohid@123'}
                            onChange={(e) => setSettingsForm({ ...settingsForm, adminPasswordHash: e.target.value })}
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white font-mono focus:outline-none focus:ring-1 focus:ring-amber-500"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Submit Changes */}
                    <div className="pt-2 flex justify-end">
                      <button
                        type="submit"
                        className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 px-6 rounded-2xl shadow-lg shadow-emerald-600/30 transition-all cursor-pointer text-xs flex items-center gap-2"
                      >
                        <Save className="w-4 h-4" />
                        <span>সেটিংস পরিবর্তন সংরক্ষণ করুন (Save Settings)</span>
                      </button>
                    </div>
                  </form>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
