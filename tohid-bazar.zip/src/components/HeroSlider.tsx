import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, ShoppingBag, ArrowRight, Sparkles, Shield, Truck } from 'lucide-react';

interface Slide {
  id: string;
  badge: string;
  titleBn: string;
  titleEn: string;
  subtitleBn: string;
  image: string;
  ctaText: string;
  ctaLink: string;
  bgColor: string;
  badgeBg: string;
}

const SLIDES: Slide[] = [
  {
    id: 'slide-1',
    badge: '🔥 মেগা ডিসকাউন্ট অফার ২০২৬',
    titleBn: 'শতভাগ খাঁটি সুন্দরবনের মধু ও প্রাকৃতিক পণ্য',
    titleEn: '100% Pure Organic Honey & Healthy Living',
    subtitleBn: 'সরাসরি মৌয়ালদের থেকে সংগৃহীত। কোনো কেমিক্যাল বা চিনি নেই। আজই অর্ডার করুন!',
    image: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=1000&auto=format&fit=crop&q=80',
    ctaText: 'এখনই কিনুন (Shop Now)',
    ctaLink: '#products',
    bgColor: 'from-amber-900 via-amber-800 to-slate-900',
    badgeBg: 'bg-amber-500/20 text-amber-300 border-amber-500/30'
  },
  {
    id: 'slide-2',
    badge: '⚡ ফ্ল্যাশ সেল ৫০% ছাড়',
    titleBn: 'ট্রেন্ডিং ইলেকট্রনিক্স ও স্মার্ট গ্যাজেট কালেকশন',
    titleEn: 'Latest Wireless TWS, Smart Watches & Accessories',
    subtitleBn: 'অরিজিনাল কোয়ালিটি নিশ্চিত ওয়ারেন্টিসহ। সারা বাংলাদেশে হোম ডেলিভারি সুবিধা।',
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=1000&auto=format&fit=crop&q=80',
    ctaText: 'অফারগুলো দেখুন (View Offers)',
    ctaLink: '#flash-sale',
    bgColor: 'from-slate-900 via-teal-950 to-emerald-950',
    badgeBg: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
  },
  {
    id: 'slide-3',
    badge: '👔 প্রিমিয়াম ফ্যাশন ২০২৬',
    titleBn: 'অভিজাত কটন খাদি ও ট্র্যাডিশনাল পোশাক',
    titleEn: 'Comfortable Handloom Mens & Womens Collection',
    subtitleBn: 'আরামদায়ক কাপড়ে প্রিমিয়াম ফিনিশিং। যেকোনো আয়োজনে রাজকীয় রূপ।',
    image: 'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=1000&auto=format&fit=crop&q=80',
    ctaText: 'কালেকশন দেখুন (Explore)',
    ctaLink: '#products',
    bgColor: 'from-indigo-950 via-slate-900 to-stone-900',
    badgeBg: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30'
  }
];

interface HeroSliderProps {
  onCtaClick: () => void;
}

export const HeroSlider: React.FC<HeroSliderProps> = ({ onCtaClick }) => {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % SLIDES.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const slide = SLIDES[currentSlide];

  return (
    <div className="relative overflow-hidden rounded-2xl md:rounded-3xl shadow-xl bg-slate-900 text-white my-4 max-w-7xl mx-auto">
      {/* Slider Content */}
      <div className={`relative min-h-[360px] md:min-h-[420px] lg:min-h-[460px] bg-gradient-to-r ${slide.bgColor} flex items-center transition-all duration-700`}>
        {/* Background Image Overlay with Gradient */}
        <div className="absolute inset-0 opacity-25 mix-blend-luminosity overflow-hidden">
          <img 
            src={slide.image} 
            alt={slide.titleBn} 
            className="w-full h-full object-cover object-center scale-105 transition-transform duration-1000" 
          />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-12 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center w-full">
          {/* Text Left Column */}
          <div className="lg:col-span-7 space-y-4">
            <span className={`inline-flex items-center gap-1.5 text-xs md:text-sm font-semibold px-3 py-1 rounded-full border backdrop-blur-sm ${slide.badgeBg}`}>
              <Sparkles className="w-4 h-4" />
              {slide.badge}
            </span>

            <h1 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-extrabold tracking-tight leading-tight md:leading-snug">
              {slide.titleBn}
            </h1>

            <p className="text-slate-300 text-sm sm:text-base md:text-lg max-w-xl font-normal leading-relaxed">
              {slide.subtitleBn}
            </p>

            {/* CTAs & Trust Points */}
            <div className="pt-2 flex flex-wrap items-center gap-4">
              <a
                href={slide.ctaLink}
                onClick={onCtaClick}
                className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold px-6 py-3 rounded-full shadow-lg shadow-emerald-500/30 flex items-center gap-2 hover:gap-3 transition-all cursor-pointer text-sm sm:text-base"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>{slide.ctaText}</span>
                <ArrowRight className="w-4 h-4" />
              </a>

              <div className="flex items-center gap-3 text-xs text-slate-300 border-l border-white/20 pl-4">
                <div className="flex items-center gap-1">
                  <Truck className="w-4 h-4 text-emerald-400" />
                  <span>দ্রুত ডেলিভারি</span>
                </div>
                <div className="flex items-center gap-1">
                  <Shield className="w-4 h-4 text-amber-400" />
                  <span>ক্যাশ অন ডেলিভারি</span>
                </div>
              </div>
            </div>
          </div>

          {/* Image Right Column */}
          <div className="lg:col-span-5 hidden sm:flex justify-center items-center">
            <div className="relative w-64 h-64 sm:w-72 sm:h-72 lg:w-84 lg:h-84 rounded-2xl overflow-hidden border-4 border-white/10 shadow-2xl group">
              <img 
                src={slide.image} 
                alt={slide.titleBn} 
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent flex items-end p-4">
                <span className="text-xs font-semibold text-emerald-300 bg-black/50 backdrop-blur-sm px-2.5 py-1 rounded-md">
                  তৌহিদ বাজার ভেরিফাইড প্রোডাক্ট
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Prev / Next Arrows */}
      <button
        onClick={() => setCurrentSlide((prev) => (prev === 0 ? SLIDES.length - 1 : prev - 1))}
        className="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/40 hover:bg-black/70 backdrop-blur-sm text-white flex items-center justify-center transition-all z-20 cursor-pointer"
        aria-label="Previous slide"
      >
        <ChevronLeft className="w-5 h-5" />
      </button>

      <button
        onClick={() => setCurrentSlide((prev) => (prev + 1) % SLIDES.length)}
        className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/40 hover:bg-black/70 backdrop-blur-sm text-white flex items-center justify-center transition-all z-20 cursor-pointer"
        aria-label="Next slide"
      >
        <ChevronRight className="w-5 h-5" />
      </button>

      {/* Slide Indicator Dots */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-2 z-20">
        {SLIDES.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setCurrentSlide(idx)}
            className={`transition-all rounded-full ${
              currentSlide === idx 
                ? 'w-8 h-2.5 bg-emerald-400' 
                : 'w-2.5 h-2.5 bg-white/40 hover:bg-white/70'
            }`}
            aria-label={`Go to slide ${idx + 1}`}
          />
        ))}
      </div>
    </div>
  );
};
