import React, { useState } from 'react';
import { Download, X, Smartphone, Share, PlusSquare, CheckCircle2 } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface MobileAppInstallBannerProps {
  onInstalled?: () => void;
}

export const MobileAppInstallBanner: React.FC<MobileAppInstallBannerProps> = ({ onInstalled }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [isDismissed, setIsDismissed] = useState(false);
  const [showIOSModal, setShowIOSModal] = useState(false);

  // If already running as standalone installed app or dismissed by user
  if (isInstalled || isDismissed) {
    return null;
  }

  const handleInstallClick = async () => {
    if (isIOS) {
      setShowIOSModal(true);
    } else if (isInstallable) {
      const success = await install();
      if (success && onInstalled) {
        onInstalled();
      }
    } else {
      // Fallback for desktop or non-supported
      setShowIOSModal(true);
    }
  };

  return (
    <>
      {/* Top Banner on Mobile */}
      <div className="bg-gradient-to-r from-emerald-700 via-teal-700 to-emerald-800 text-white px-3 py-2 sm:py-2.5 shadow-md border-b border-emerald-600 relative z-30">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-xl bg-white/20 backdrop-blur-xs flex items-center justify-center shrink-0 border border-white/25">
              <Smartphone className="w-4 h-4 text-emerald-100" />
            </div>
            <div className="truncate">
              <span className="font-extrabold text-white block truncate leading-tight">
                তৌহিদ বাজার মোবাইল অ্যাপ
              </span>
              <span className="text-[11px] text-emerald-200 block truncate leading-tight">
                সহজে অর্ডার করতে অ্যাপ হিসেবে ফোনে ইনস্টল করুন
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={handleInstallClick}
              className="bg-amber-400 hover:bg-amber-300 text-slate-950 font-black px-3 py-1 rounded-full text-xs shadow-xs active:scale-95 transition-all flex items-center gap-1 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>ইনস্টল করুন</span>
            </button>
            <button
              onClick={() => setIsDismissed(true)}
              className="p-1 text-emerald-200 hover:text-white rounded-full transition-colors"
              title="বন্ধ করুন"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* iOS / General Installation Instructions Modal */}
      {showIOSModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl relative border border-slate-100">
            <button
              onClick={() => setShowIOSModal(false)}
              className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="w-14 h-14 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto mb-4 shadow-xs">
              <Smartphone className="w-7 h-7" />
            </div>

            <h3 className="text-lg font-bold text-slate-900 text-center">
              ফোনে অ্যাপ ইনস্টল করুন
            </h3>
            <p className="text-xs text-slate-500 text-center mt-1">
              তৌহিদ বাজারকে যেকোনো অ্যাপ স্টোর ছাড়াই সরাসরি ফোনে যুক্ত করুন:
            </p>

            <div className="mt-4 space-y-3 bg-slate-50 p-4 rounded-2xl border border-slate-200/80 text-xs">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0 font-bold text-[11px] mt-0.5">
                  ১
                </div>
                <p className="text-slate-700">
                  ব্রাউজারের নিচে বা উপরে থাকা <strong>Share (শেয়ার)</strong> অথবা <strong>তিন ডট (⋮) মেনুতে</strong> চাপ দিন।
                </p>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0 font-bold text-[11px] mt-0.5">
                  ২
                </div>
                <p className="text-slate-700">
                  মেনু থেকে <strong>"Add to Home screen"</strong> বা <strong>"হোম স্ক্রিনে যোগ করুন"</strong> নির্বাচন করুন।
                </p>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0 font-bold text-[11px] mt-0.5">
                  ৩
                </div>
                <p className="text-slate-700">
                  <strong>Add</strong> বাটনে চাপ দিলে আপনার মোবাইলের হোম স্ক্রিনে অ্যাপের আইকন যুক্ত হয়ে যাবে!
                </p>
              </div>
            </div>

            <button
              onClick={() => setShowIOSModal(false)}
              className="mt-5 w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition-colors cursor-pointer"
            >
              বুঝেছি, ধন্যবাদ
            </button>
          </div>
        </div>
      )}
    </>
  );
};
