import React from 'react';
import { Share2, Video, Heart, Youtube, MessageCircle, Facebook, Sparkles, ExternalLink } from 'lucide-react';
import { SocialPost } from '../types';

interface PostsSectionProps {
  posts: SocialPost[];
  onSharePost: (post: SocialPost) => void;
  onLikePost: (postId: string) => void;
}

export const PostsSection: React.FC<PostsSectionProps> = ({
  posts,
  onSharePost,
  onLikePost
}) => {
  if (posts.length === 0) return null;

  return (
    <section id="social-feed" className="my-10 max-w-7xl mx-auto px-4">
      {/* Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-indigo-100 text-indigo-800 text-xs font-black px-2.5 py-0.5 rounded-full uppercase">
              ভিডিও ও আপডেট
            </span>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              ইউটিউব ও সোশ্যাল পোস্ট (Posts & Video Reviews)
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            পণ্য রিভিউ, আনবক্সিং এবং বিশেষ অফারের ভিডিও দেখুন ও বন্ধুদের সাথে শেয়ার করুন
          </p>
        </div>
      </div>

      {/* Posts Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {posts.map((post) => (
          <div
            key={post.id}
            className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-xl transition-all flex flex-col justify-between"
          >
            <div>
              {/* Media Preview (Image or Video) */}
              {post.imageUrl && (
                <div className="relative aspect-video bg-slate-900 overflow-hidden group">
                  <img
                    src={post.imageUrl}
                    alt={post.titleBn}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  {post.videoUrl && (
                    <a
                      href={post.videoUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="absolute inset-0 bg-black/40 hover:bg-black/30 flex items-center justify-center transition-colors"
                    >
                      <div className="w-14 h-14 rounded-full bg-red-600 text-white flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                        <Youtube className="w-8 h-8 fill-white" />
                      </div>
                    </a>
                  )}
                  <div className="absolute bottom-3 left-3 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded-lg text-white text-[11px] font-medium flex items-center gap-1.5">
                    <Video className="w-3.5 h-3.5 text-rose-400" />
                    <span>ইউটিউব রিভিউ</span>
                  </div>
                </div>
              )}

              {/* Content Details */}
              <div className="p-5">
                <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
                  <span className="font-semibold text-emerald-700">তৌহিদ বাজার অফিসিয়াল পোস্ট</span>
                  <span>{post.date}</span>
                </div>

                <h3 className="text-base sm:text-lg font-bold text-slate-900 leading-snug hover:text-emerald-700 transition-colors">
                  {post.titleBn}
                </h3>

                <p className="mt-2 text-xs sm:text-sm text-slate-600 leading-relaxed line-clamp-3">
                  {post.content}
                </p>
              </div>
            </div>

            {/* Social Share & Interaction Footer */}
            <div className="px-5 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
              {/* Like Button */}
              <button
                onClick={() => onLikePost(post.id)}
                className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-rose-600 transition-colors cursor-pointer"
              >
                <Heart className="w-4 h-4 hover:fill-rose-600" />
                <span>লাইক ({post.likes})</span>
              </button>

              {/* Social Share Group */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => onSharePost(post)}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all cursor-pointer"
                  title="ফেসবুক, হোয়াটসঅ্যাপে শেয়ার করুন"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span>শেয়ার করুন (Share)</span>
                </button>

                {post.videoUrl && (
                  <a
                    href={post.videoUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="p-1.5 text-slate-500 hover:text-red-600 rounded-lg hover:bg-slate-200 transition-colors"
                    title="ভিডিওটি সরাসরি ইউটিউবে দেখুন"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </a>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
