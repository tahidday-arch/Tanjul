import React from 'react';
import { Apple, Headphones, Shirt, Home, Sparkles, ShoppingBag, Flame, Tag } from 'lucide-react';
import { INITIAL_CATEGORIES } from '../data/initialData';

interface MobileStoryCategoriesProps {
  selectedCategory: string;
  onSelectCategory: (id: string) => void;
  onOpenFlashSale?: () => void;
}

export const MobileStoryCategories: React.FC<MobileStoryCategoriesProps> = ({
  selectedCategory,
  onSelectCategory,
  onOpenFlashSale
}) => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Apple': return <Apple className="w-5 h-5 text-emerald-600" />;
      case 'Headphones': return <Headphones className="w-5 h-5 text-indigo-600" />;
      case 'Shirt': return <Shirt className="w-5 h-5 text-sky-600" />;
      case 'Home': return <Home className="w-5 h-5 text-amber-600" />;
      case 'Sparkles': return <Sparkles className="w-5 h-5 text-rose-600" />;
      default: return <ShoppingBag className="w-5 h-5 text-teal-600" />;
    }
  };

  return (
    <div className="bg-white border-b border-slate-100 py-3 px-3 shadow-xs">
      <div className="flex items-center justify-between mb-2 px-1">
        <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
          <Tag className="w-3 h-3 text-emerald-600" />
          <span>ক্যাটাগরি বাছাই করুন</span>
        </span>
        <button
          onClick={() => onSelectCategory('all')}
          className="text-[11px] font-bold text-emerald-600 hover:text-emerald-700 active:scale-95 transition-transform"
        >
          সব দেখুন
        </button>
      </div>

      <div className="flex items-center gap-3.5 overflow-x-auto pb-1 scrollbar-none scroll-smooth">
        {/* Flash Sale Story Bubble */}
        <button
          onClick={() => {
            const el = document.getElementById('flash-sale');
            if (el) {
              el.scrollIntoView({ behavior: 'smooth' });
            } else if (onOpenFlashSale) {
              onOpenFlashSale();
            }
          }}
          className="flex flex-col items-center gap-1 shrink-0 active:scale-90 transition-transform group"
        >
          <div className="w-14 h-14 rounded-full p-[2px] bg-gradient-to-tr from-rose-500 via-amber-500 to-red-500 shadow-sm group-hover:shadow-rose-500/20">
            <div className="w-full h-full rounded-full bg-rose-50 flex items-center justify-center border-2 border-white">
              <Flame className="w-6 h-6 text-rose-600 animate-pulse" />
            </div>
          </div>
          <span className="text-[11px] font-bold text-rose-600 whitespace-nowrap">ফ্ল্যাশ সেল</span>
        </button>

        {/* 'All' Bubble */}
        <button
          onClick={() => onSelectCategory('all')}
          className="flex flex-col items-center gap-1 shrink-0 active:scale-90 transition-transform group"
        >
          <div className={`w-14 h-14 rounded-full p-[2px] transition-all ${
            selectedCategory === 'all'
              ? 'bg-gradient-to-tr from-emerald-600 to-teal-400 ring-2 ring-emerald-500/30'
              : 'bg-slate-200'
          }`}>
            <div className={`w-full h-full rounded-full flex items-center justify-center border-2 border-white ${
              selectedCategory === 'all' ? 'bg-emerald-600 text-white' : 'bg-slate-50 text-slate-700'
            }`}>
              <ShoppingBag className="w-5 h-5" />
            </div>
          </div>
          <span className={`text-[11px] whitespace-nowrap ${
            selectedCategory === 'all' ? 'font-bold text-emerald-700' : 'font-medium text-slate-600'
          }`}>
            সকল পণ্য
          </span>
        </button>

        {/* Dynamic Categories */}
        {INITIAL_CATEGORIES.map((cat) => {
          const isSelected = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat.id)}
              className="flex flex-col items-center gap-1 shrink-0 active:scale-90 transition-transform group"
            >
              <div className={`w-14 h-14 rounded-full p-[2px] transition-all ${
                isSelected
                  ? 'bg-gradient-to-tr from-emerald-600 to-teal-400 ring-2 ring-emerald-500/30 shadow-md'
                  : 'bg-gradient-to-tr from-slate-200 to-slate-100 hover:from-emerald-300 hover:to-teal-200'
              }`}>
                <div className={`w-full h-full rounded-full flex items-center justify-center border-2 border-white ${
                  isSelected ? 'bg-emerald-50' : 'bg-white'
                }`}>
                  {getIcon(cat.icon)}
                </div>
              </div>
              <span className={`text-[11px] whitespace-nowrap ${
                isSelected ? 'font-bold text-emerald-700' : 'font-medium text-slate-600'
              }`}>
                {cat.nameBn}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
