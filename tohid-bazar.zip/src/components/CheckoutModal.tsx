import React, { useState } from 'react';
import { 
  X, 
  CheckCircle2, 
  Truck, 
  CreditCard, 
  Phone, 
  MapPin, 
  User, 
  FileText, 
  Copy, 
  Check, 
  AlertCircle,
  ShieldCheck,
  Building2
} from 'lucide-react';
import { CartItem, Coupon, Order, PaymentMethod, WebsiteSettings } from '../types';
import { BANGLADESH_DISTRICTS } from '../data/initialData';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  appliedCoupon: Coupon | null;
  settings: WebsiteSettings;
  deliveryArea: 'inside_dhaka' | 'outside_dhaka';
  onChangeDeliveryArea: (area: 'inside_dhaka' | 'outside_dhaka') => void;
  onSubmitOrder: (orderData: Omit<Order, 'id' | 'date' | 'status' | 'trackingTimeline'>) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  cart,
  appliedCoupon,
  settings,
  deliveryArea,
  onChangeDeliveryArea,
  onSubmitOrder
}) => {
  const [customerName, setCustomerName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [district, setDistrict] = useState('Dhaka');
  const [upazila, setUpazila] = useState('');
  const [address, setAddress] = useState('');
  const [note, setNote] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cod');
  const [transactionId, setTransactionId] = useState('');
  const [senderNumber, setSenderNumber] = useState('');
  const [copiedNumber, setCopiedNumber] = useState(false);
  const [formError, setFormError] = useState('');

  if (!isOpen) return null;

  // Calculate pricing
  const subtotal = cart.reduce((acc, item) => acc + item.product.discountPrice * item.quantity, 0);
  const deliveryCharge = deliveryArea === 'inside_dhaka' ? settings.insideDhakaCharge : settings.outsideDhakaCharge;
  
  let discountAmount = 0;
  if (appliedCoupon && subtotal >= appliedCoupon.minOrderAmount) {
    if (appliedCoupon.discountType === 'percentage') {
      discountAmount = Math.round((subtotal * appliedCoupon.discountValue) / 100);
    } else {
      discountAmount = appliedCoupon.discountValue;
    }
  }

  const grandTotal = Math.max(0, subtotal - discountAmount + deliveryCharge);

  const handleCopyPaymentNumber = (number: string) => {
    navigator.clipboard.writeText(number);
    setCopiedNumber(true);
    setTimeout(() => setCopiedNumber(false), 2000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!customerName.trim()) {
      setFormError('দয়া করে আপনার নাম লিখুন।');
      return;
    }

    const cleanPhone = phoneNumber.replace(/[^0-9]/g, '');
    if (cleanPhone.length < 11) {
      setFormError('সঠিক ১১ ডিজিটের মোবাইল নম্বর দিন (যেমন: 017XXXXXXXX)।');
      return;
    }

    if (!address.trim()) {
      setFormError('পণ্য পৌঁছানোর সম্পূর্ণ ঠিকানা লিখুন।');
      return;
    }

    if ((paymentMethod === 'bkash' || paymentMethod === 'nagad') && !transactionId.trim()) {
      setFormError('বিকাশ অথবা নগদ পেমেন্টের পর প্রাপ্ত TrxID (Transaction ID) লিখুন।');
      return;
    }

    const orderItems = cart.map((item) => ({
      productId: item.product.id,
      productName: item.product.nameBn,
      productImage: item.product.image,
      price: item.product.discountPrice,
      quantity: item.quantity,
      total: item.product.discountPrice * item.quantity
    }));

    onSubmitOrder({
      customerName: customerName.trim(),
      phoneNumber: cleanPhone,
      district,
      upazila: upazila.trim() || district,
      address: address.trim(),
      note: note.trim(),
      deliveryArea,
      deliveryCharge,
      subtotal,
      discountAmount,
      couponCode: appliedCoupon?.code,
      grandTotal,
      paymentMethod,
      paymentStatus: paymentMethod === 'cod' ? 'unpaid' : 'paid',
      transactionId: transactionId.trim() || undefined,
      senderNumber: senderNumber.trim() || cleanPhone,
      items: orderItems
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full my-8 shadow-2xl overflow-hidden border border-slate-200 relative animate-fade-in max-h-[95vh] flex flex-col">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-emerald-700 text-white shrink-0">
          <div>
            <h2 className="text-lg sm:text-xl font-black tracking-tight">
              অর্ডার ফর্ম (Complete Your Order)
            </h2>
            <p className="text-xs text-emerald-100 mt-0.5">
              নিচের তথ্যগুলো পূরণ করে অর্ডার কনফার্ম করুন
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-emerald-800 text-emerald-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Form */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-6">
          {formError && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-2 text-rose-700 text-xs font-semibold">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{formError}</span>
            </div>
          )}

          {/* Section 1: Customer Information */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 border-b border-slate-100 pb-2">
              <User className="w-4 h-4 text-emerald-600" />
              <span>১. ক্রেতার ব্যক্তিগত তথ্য ও যোগাযোগের নম্বর</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  আপনার নাম (Full Name) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="আপনার পূর্ণ নাম লিখুন"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  মোবাইল নম্বর (Phone Number) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="tel"
                  required
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  placeholder="017XXXXXXXX"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Delivery Address */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 border-b border-slate-100 pb-2">
              <MapPin className="w-4 h-4 text-emerald-600" />
              <span>২. পণ্য পৌঁছানোর ঠিকানা (Delivery Address)</span>
            </h3>

            {/* Delivery Area Selection */}
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1.5">
                ডেলিভারি এরিয়া (Delivery Charge):
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => onChangeDeliveryArea('inside_dhaka')}
                  className={`p-3 rounded-2xl border text-left flex items-center justify-between cursor-pointer transition-all ${
                    deliveryArea === 'inside_dhaka'
                      ? 'border-emerald-600 bg-emerald-50 ring-2 ring-emerald-600/20'
                      : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">ঢাকার ভিতরে</span>
                    <span className="text-[11px] text-slate-500">হোম ডেলিভারি</span>
                  </div>
                  <span className="text-xs font-black text-emerald-700">৳{settings.insideDhakaCharge}</span>
                </button>

                <button
                  type="button"
                  onClick={() => onChangeDeliveryArea('outside_dhaka')}
                  className={`p-3 rounded-2xl border text-left flex items-center justify-between cursor-pointer transition-all ${
                    deliveryArea === 'outside_dhaka'
                      ? 'border-emerald-600 bg-emerald-50 ring-2 ring-emerald-600/20'
                      : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">ঢাকার বাইরে</span>
                    <span className="text-[11px] text-slate-500">সারা বাংলাদেশ</span>
                  </div>
                  <span className="text-xs font-black text-emerald-700">৳{settings.outsideDhakaCharge}</span>
                </button>
              </div>
            </div>

            {/* District & Upazila */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  জেলা (District) <span className="text-rose-500">*</span>
                </label>
                <select
                  value={district}
                  onChange={(e) => {
                    setDistrict(e.target.value);
                    if (e.target.value === 'Dhaka') {
                      onChangeDeliveryArea('inside_dhaka');
                    } else {
                      onChangeDeliveryArea('outside_dhaka');
                    }
                  }}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                >
                  {BANGLADESH_DISTRICTS.map((d) => (
                    <option key={d.name} value={d.name}>
                      {d.nameBn} ({d.name})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  উপজেলা / থানা (Upazila / Thana)
                </label>
                <input
                  type="text"
                  value={upazila}
                  onChange={(e) => setUpazila(e.target.value)}
                  placeholder="e.g. মিরপুর, ধানমন্ডি, বাড্ডা, পটিয়া"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                />
              </div>
            </div>

            {/* Full Detailed Address */}
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                সম্পূর্ণ ঠিকানা (Full Street Address) <span className="text-rose-500">*</span>
              </label>
              <textarea
                required
                rows={2}
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="বাসা নম্বর, রোড নম্বর, এলাকা, ল্যান্ডমার্ক ইত্যাদি বিস্তারিত লিখুন..."
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
              />
            </div>

            <div>
              <label className="text-xs font-medium text-slate-500 block mb-1">
                বিশেষ কোনো নির্দেশনা বা নোট (ঐচ্ছিক)
              </label>
              <input
                type="text"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="e.g. বিকাল ৪টার পর কল দিবেন"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* Section 3: Payment Method */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 border-b border-slate-100 pb-2">
              <CreditCard className="w-4 h-4 text-emerald-600" />
              <span>৩. পেমেন্ট পদ্ধতি নির্বাচন করুন (Payment Method)</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Cash on Delivery */}
              <label className={`p-3.5 rounded-2xl border flex items-center gap-3 cursor-pointer transition-all ${
                paymentMethod === 'cod'
                  ? 'border-emerald-600 bg-emerald-50 ring-2 ring-emerald-600/20'
                  : 'border-slate-200 hover:bg-slate-50'
              }`}>
                <input
                  type="radio"
                  name="payment"
                  value="cod"
                  checked={paymentMethod === 'cod'}
                  onChange={() => setPaymentMethod('cod')}
                  className="w-4 h-4 text-emerald-600 focus:ring-emerald-500"
                />
                <div>
                  <span className="text-xs font-bold text-slate-900 block">ক্যাশ অন ডেলিভারি (Cash on Delivery)</span>
                  <span className="text-[11px] text-slate-500">পণ্য হাতে পেয়ে টাকা পরিশোধ করুন</span>
                </div>
              </label>

              {/* bKash */}
              <label className={`p-3.5 rounded-2xl border flex items-center gap-3 cursor-pointer transition-all ${
                paymentMethod === 'bkash'
                  ? 'border-pink-600 bg-pink-50 ring-2 ring-pink-600/20'
                  : 'border-slate-200 hover:bg-slate-50'
              }`}>
                <input
                  type="radio"
                  name="payment"
                  value="bkash"
                  checked={paymentMethod === 'bkash'}
                  onChange={() => setPaymentMethod('bkash')}
                  className="w-4 h-4 text-pink-600 focus:ring-pink-500"
                />
                <div>
                  <span className="text-xs font-bold text-pink-700 block">বিকাশ (bKash Payment)</span>
                  <span className="text-[11px] text-slate-500">মোবাইল ব্যাংকিং (সেন্ড মানি)</span>
                </div>
              </label>

              {/* Nagad */}
              <label className={`p-3.5 rounded-2xl border flex items-center gap-3 cursor-pointer transition-all ${
                paymentMethod === 'nagad'
                  ? 'border-amber-600 bg-amber-50 ring-2 ring-amber-600/20'
                  : 'border-slate-200 hover:bg-slate-50'
              }`}>
                <input
                  type="radio"
                  name="payment"
                  value="nagad"
                  checked={paymentMethod === 'nagad'}
                  onChange={() => setPaymentMethod('nagad')}
                  className="w-4 h-4 text-amber-600 focus:ring-amber-500"
                />
                <div>
                  <span className="text-xs font-bold text-amber-700 block">নগদ (Nagad Payment)</span>
                  <span className="text-[11px] text-slate-500">মোবাইল ব্যাংকিং (সেন্ড মানি)</span>
                </div>
              </label>

              {/* Online Payment */}
              <label className={`p-3.5 rounded-2xl border flex items-center gap-3 cursor-pointer transition-all ${
                paymentMethod === 'online'
                  ? 'border-indigo-600 bg-indigo-50 ring-2 ring-indigo-600/20'
                  : 'border-slate-200 hover:bg-slate-50'
              }`}>
                <input
                  type="radio"
                  name="payment"
                  value="online"
                  checked={paymentMethod === 'online'}
                  onChange={() => setPaymentMethod('online')}
                  className="w-4 h-4 text-indigo-600 focus:ring-indigo-500"
                />
                <div>
                  <span className="text-xs font-bold text-indigo-700 block">অনলাইন পেমেন্ট (Card / Net Banking)</span>
                  <span className="text-[11px] text-slate-500">ভিসা, মাস্টারকার্ড ও অন্যান্য</span>
                </div>
              </label>
            </div>

            {/* bKash instructions & TrxID form */}
            {paymentMethod === 'bkash' && (
              <div className="p-4 bg-pink-50 border border-pink-200 rounded-2xl space-y-3">
                <div className="flex items-center justify-between">
                  <div className="text-xs text-pink-950 font-medium">
                    <span className="font-bold">বিকাশ সেন্ড মানি নম্বর: </span>
                    <span className="font-mono font-bold text-pink-700 text-sm">{settings.bkashNumber}</span>
                    <span className="text-[10px] ml-1 text-slate-500">({settings.bkashType === 'personal' ? 'পার্সোনাল' : 'মার্চেন্ট'})</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleCopyPaymentNumber(settings.bkashNumber)}
                    className="text-xs bg-white border border-pink-300 text-pink-700 px-2.5 py-1 rounded-lg font-bold flex items-center gap-1 hover:bg-pink-100 cursor-pointer"
                  >
                    {copiedNumber ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedNumber ? 'কপি হয়েছে' : 'কপি নম্বর'}</span>
                  </button>
                </div>
                <p className="text-[11px] text-pink-800">
                  সর্বমোট ৳{grandTotal.toLocaleString()} টাকা উপরের বিকাশ নম্বরে সেন্ড মানি করে নিচে ট্রানজেকশন আইডি (TrxID) দিন:
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-bold text-pink-900 block mb-1">যে নম্বর থেকে টাকা পাঠিয়েছেন</label>
                    <input
                      type="tel"
                      value={senderNumber}
                      onChange={(e) => setSenderNumber(e.target.value)}
                      placeholder="017XXXXXXXX"
                      className="w-full bg-white border border-pink-300 rounded-xl px-3 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-pink-500"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-bold text-pink-900 block mb-1">
                      বিকাশ TrxID (Transaction ID) <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={transactionId}
                      onChange={(e) => setTransactionId(e.target.value.toUpperCase())}
                      placeholder="e.g. 9J83KX94B"
                      className="w-full bg-white border border-pink-300 rounded-xl px-3 py-2 text-xs font-mono uppercase focus:outline-none focus:ring-2 focus:ring-pink-500"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Nagad instructions & TrxID form */}
            {paymentMethod === 'nagad' && (
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl space-y-3">
                <div className="flex items-center justify-between">
                  <div className="text-xs text-amber-950 font-medium">
                    <span className="font-bold">নগদ সেন্ড মানি নম্বর: </span>
                    <span className="font-mono font-bold text-amber-700 text-sm">{settings.nagadNumber}</span>
                    <span className="text-[10px] ml-1 text-slate-500">({settings.nagadType === 'personal' ? 'পার্সোনাল' : 'মার্চেন্ট'})</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleCopyPaymentNumber(settings.nagadNumber)}
                    className="text-xs bg-white border border-amber-300 text-amber-700 px-2.5 py-1 rounded-lg font-bold flex items-center gap-1 hover:bg-amber-100 cursor-pointer"
                  >
                    {copiedNumber ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedNumber ? 'কপি হয়েছে' : 'কপি নম্বর'}</span>
                  </button>
                </div>
                <p className="text-[11px] text-amber-800">
                  সর্বমোট ৳{grandTotal.toLocaleString()} টাকা নগদ অ্যাপ বা ইউএসএসডি কোড দিয়ে পাঠিয়ে নিচে TrxID দিন:
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-bold text-amber-900 block mb-1">যে নম্বর থেকে পাঠিয়েছেন</label>
                    <input
                      type="tel"
                      value={senderNumber}
                      onChange={(e) => setSenderNumber(e.target.value)}
                      placeholder="018XXXXXXXX"
                      className="w-full bg-white border border-amber-300 rounded-xl px-3 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-bold text-amber-900 block mb-1">
                      নগদ TrxID <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={transactionId}
                      onChange={(e) => setTransactionId(e.target.value.toUpperCase())}
                      placeholder="e.g. 7192847B"
                      className="w-full bg-white border border-amber-300 rounded-xl px-3 py-2 text-xs font-mono uppercase focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Section 4: Order Summary Box */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2 text-xs">
            <h4 className="font-bold text-slate-800 text-sm mb-2">অর্ডারের সারাংশ ({cart.length} টি পণ্য)</h4>
            
            <div className="max-h-36 overflow-y-auto space-y-2 pr-1 divide-y divide-slate-100">
              {cart.map((item) => (
                <div key={item.product.id} className="pt-2 first:pt-0 flex justify-between items-center text-slate-700">
                  <span className="truncate max-w-[240px]">
                    {item.product.nameBn} <span className="text-slate-400">× {item.quantity}</span>
                  </span>
                  <span className="font-bold shrink-0">৳{(item.product.discountPrice * item.quantity).toLocaleString()}</span>
                </div>
              ))}
            </div>

            <div className="pt-3 border-t border-slate-200 space-y-1 text-slate-600">
              <div className="flex justify-between">
                <span>পণ্যের দাম (Subtotal):</span>
                <span className="font-semibold text-slate-900">৳{subtotal.toLocaleString()}</span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between text-emerald-600 font-bold">
                  <span>ছাড় (Discount):</span>
                  <span>-৳{discountAmount.toLocaleString()}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span>ডেলিভারি চার্জ ({deliveryArea === 'inside_dhaka' ? 'ঢাকার ভিতরে' : 'ঢাকার বাইরে'}):</span>
                <span className="font-semibold text-slate-900">৳{deliveryCharge}</span>
              </div>
              <div className="pt-2 border-t border-slate-200 flex justify-between text-base font-black text-slate-900">
                <span>সর্বমোট প্রদেয় টাকা (Grand Total):</span>
                <span className="text-emerald-700 text-lg">৳{grandTotal.toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* Confirm Button */}
          <div className="pt-2">
            <button
              type="submit"
              className="w-full bg-emerald-600 hover:bg-emerald-700 active:scale-99 text-white font-extrabold py-3.5 px-6 rounded-2xl shadow-xl shadow-emerald-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer text-base"
            >
              <CheckCircle2 className="w-5 h-5" />
              <span>অর্ডার নিশ্চিত করুন (Confirm Order — ৳{grandTotal.toLocaleString()})</span>
            </button>
            <p className="text-[11px] text-slate-400 text-center mt-2">
              🔒 আপনার তথ্য তৌহিদ বাজারে সম্পূর্ণ নিরাপদ ও সুরক্ষিত
            </p>
          </div>
        </form>
      </div>
    </div>
  );
};
