import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { CheckCircle2, MessageCircle, Truck, ArrowRight, ShoppingBag, PhoneCall, Copy, Check } from 'lucide-react';
import { Order, WebsiteSettings } from '../types';
import { getWhatsAppUrl } from '../utils';

interface OrderSuccessModalProps {
  order: Order | null;
  onClose: () => void;
  onTrackOrder: (orderId: string) => void;
  settings: WebsiteSettings;
}

export const OrderSuccessModal: React.FC<OrderSuccessModalProps> = ({
  order,
  onClose,
  onTrackOrder,
  settings
}) => {
  const [copied, setCopied] = React.useState(false);

  useEffect(() => {
    if (order) {
      // Fire celebration confetti
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 }
        });
      } catch {
        // ignore
      }
    }
  }, [order]);

  if (!order) return null;

  const handleCopyOrderId = () => {
    navigator.clipboard.writeText(order.id);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSendToWhatsApp = () => {
    const text = `আসসালামু আলাইকুম, আমি তৌহিদ বাজারে একটি অর্ডার দিয়েছি।\nঅর্ডার আইডি: ${order.id}\nনাম: ${order.customerName}\nফোন: ${order.phoneNumber}\nসর্বমোট: ৳${order.grandTotal}\nপেমেন্ট পদ্ধতি: ${order.paymentMethod.toUpperCase()}`;
    const url = getWhatsAppUrl(settings.whatsappNumber, text);
    window.open(url, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl relative border border-slate-100 text-center">
        {/* Animated Checkmark Badge */}
        <div className="w-16 h-16 sm:w-20 sm:h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4 ring-8 ring-emerald-50 animate-bounce">
          <CheckCircle2 className="w-10 h-10 sm:w-12 sm:h-12" />
        </div>

        <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
          অভিনন্দন! আপনার অর্ডার সফল হয়েছে
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          অর্ডারটি আমাদের সিস্টেমে সংরক্ষিত হয়েছে এবং প্রস্তুত করা হচ্ছে।
        </p>

        {/* Order ID Pill */}
        <div className="mt-4 inline-flex items-center gap-2 bg-slate-100 px-4 py-2 rounded-2xl border border-slate-200">
          <span className="text-xs font-bold text-slate-600">অর্ডার নম্বর:</span>
          <span className="text-sm font-mono font-black text-emerald-700">{order.id}</span>
          <button
            onClick={handleCopyOrderId}
            className="p-1 hover:bg-slate-200 rounded-md text-slate-500 transition-colors"
            title="অর্ডার নম্বর কপি করুন"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
          </button>
        </div>

        {/* Order Brief Card */}
        <div className="mt-5 bg-slate-50 p-4 rounded-2xl border border-slate-200 text-left space-y-2 text-xs">
          <div className="flex justify-between text-slate-700">
            <span>গ্রাহকের নাম:</span>
            <span className="font-bold text-slate-900">{order.customerName}</span>
          </div>
          <div className="flex justify-between text-slate-700">
            <span>মোবাইল নম্বর:</span>
            <span className="font-bold text-slate-900">{order.phoneNumber}</span>
          </div>
          <div className="flex justify-between text-slate-700">
            <span>পণ্য পৌঁছানোর ঠিকানা:</span>
            <span className="font-bold text-slate-900 text-right max-w-[200px] truncate">{order.address}, {order.district}</span>
          </div>
          <div className="flex justify-between text-slate-700">
            <span>পেমেন্ট মেথড:</span>
            <span className="font-bold text-emerald-700 uppercase">{order.paymentMethod}</span>
          </div>
          <div className="pt-2 border-t border-slate-200 flex justify-between text-sm font-black text-slate-900">
            <span>সর্বমোট টাকা:</span>
            <span className="text-emerald-700">৳{order.grandTotal.toLocaleString()}</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="mt-6 space-y-2.5">
          <button
            onClick={handleSendToWhatsApp}
            className="w-full bg-[#25D366] hover:bg-[#20ba59] text-white font-bold py-3 px-4 rounded-2xl flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer text-sm"
          >
            <MessageCircle className="w-4 h-4" />
            <span>হোয়াটসঅ্যাপে নিশ্চিত করুন (WhatsApp Confirmation)</span>
          </button>

          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => {
                onClose();
                onTrackOrder(order.id);
              }}
              className="py-2.5 px-3 rounded-2xl border border-emerald-600 text-emerald-700 hover:bg-emerald-50 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <Truck className="w-3.5 h-3.5" />
              <span>অর্ডার ট্র্যাক করুন</span>
            </button>

            <button
              onClick={onClose}
              className="py-2.5 px-3 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>আরও কেনাকাটা করুন</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
