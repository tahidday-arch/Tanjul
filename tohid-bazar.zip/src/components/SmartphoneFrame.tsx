import React, { useState, useEffect } from 'react';
import { Smartphone, Monitor, Wifi, Battery, Signal, ArrowLeft } from 'lucide-react';

interface SmartphoneFrameProps {
  children: React.ReactNode;
  isAppViewMode: boolean;
  onToggleAppViewMode: (enabled: boolean) => void;
}

export const SmartphoneFrame: React.FC<SmartphoneFrameProps> = ({
  children,
  isAppViewMode,
  onToggleAppViewMode,
}) => {
  const [currentTime, setCurrentTime] = useState('09:41');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = now.getHours().toString().padStart(2, '0');
      const minutes = now.getMinutes().toString().padStart(2, '0');
      setCurrentTime(`${hours}:${minutes}`);
    };
    updateTime();
    const timer = setInterval(updateTime, 10000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col items-center">
      {/* Top Desktop Floating Switcher Bar */}
      <div className="hidden lg:flex items-center justify-between w-full max-w-7xl px-6 py-2 bg-white/90 backdrop-blur-md border-b border-slate-200 sticky top-0 z-50 shadow-xs">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-xs font-bold text-slate-700">
            তৌহিদ বাজার মোবাইল অ্যাপ প্রিভিউ (Mobile App & Web Experience)
          </span>
        </div>

        {/* View Mode Switcher Pills */}
        <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-2xl border border-slate-200">
          <button
            onClick={() => onToggleAppViewMode(true)}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              isAppViewMode
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>📱 মোবাইল অ্যাপ ফ্রেম</span>
          </button>

          <button
            onClick={() => onToggleAppViewMode(false)}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              !isAppViewMode
                ? 'bg-slate-900 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>💻 সাধারণ ফুলস্ক্রিন ভিউ</span>
          </button>
        </div>
      </div>

      {/* Frame Container */}
      {isAppViewMode ? (
        <div className="w-full flex-1 flex justify-center items-start py-4 lg:py-8 px-2 sm:px-4">
          {/* Smartphone Hardware Frame (Only rendered with bezel on large screens) */}
          <div className="w-full max-w-[430px] bg-slate-900 rounded-none sm:rounded-[50px] p-0 sm:p-3 shadow-2xl sm:ring-1 sm:ring-slate-800/80 relative">
            {/* Phone Speaker & Camera Bezel Notch on desktop */}
            <div className="hidden sm:flex justify-center items-center h-4 relative">
              <div className="w-20 h-3.5 bg-slate-950 rounded-full flex items-center justify-center gap-2">
                <div className="w-2 h-2 rounded-full bg-slate-800" />
                <div className="w-8 h-1 rounded-full bg-slate-800" />
              </div>
            </div>

            {/* Smartphone Screen Viewport */}
            <div className="w-full bg-slate-50 rounded-none sm:rounded-[40px] overflow-hidden flex flex-col relative min-h-[844px] max-h-[92vh] border border-slate-200/50 shadow-inner">
              {/* Native App Top Status Bar */}
              <div className="bg-emerald-700 text-white px-5 py-2 flex items-center justify-between text-xs font-semibold shrink-0 z-40 select-none">
                <span className="font-mono text-[11px] tracking-tight">{currentTime}</span>
                <div className="flex items-center gap-1.5 text-emerald-100">
                  <Signal className="w-3 h-3" />
                  <span className="text-[10px] font-bold">5G</span>
                  <Wifi className="w-3 h-3" />
                  <Battery className="w-3.5 h-3.5 text-white" />
                </div>
              </div>

              {/* Scrollable Screen Content */}
              <div className="flex-1 overflow-y-auto overscroll-contain relative scrollbar-thin">
                {children}
              </div>

              {/* Native Home Swipe Bar */}
              <div className="hidden sm:flex items-center justify-center h-5 bg-white/95 shrink-0 border-t border-slate-100 select-none">
                <div className="w-32 h-1 bg-slate-300 rounded-full" />
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Full Screen Web Mode */
        <div className="w-full flex-1">
          {children}
        </div>
      )}
    </div>
  );
};
