import React from 'react';
import { 
  Phone, 
  Mail, 
  MapPin, 
  Facebook, 
  Youtube, 
  Instagram, 
  ShieldCheck, 
  Truck, 
  RotateCcw, 
  Headphones, 
  Lock,
  Heart,
  MessageCircle
} from 'lucide-react';
import { WebsiteSettings } from '../types';
import { getWhatsAppUrl } from '../utils';

interface FooterProps {
  settings: WebsiteSettings;
  onOpenAdmin: () => void;
  onOpenTracking: () => void;
  onSelectCategory: (catId: string) => void;
}

export const Footer: React.FC<FooterProps> = ({
  settings,
  onOpenAdmin,
  onOpenTracking,
  onSelectCategory
}) => {
  return (
    <footer className="bg-slate-950 text-slate-300 pt-12 pb-8 border-t border-slate-800">
      {/* 4 Feature Badges */}
      <div className="max-w-7xl mx-auto px-4 pb-12 border-b border-slate-800">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0 border border-emerald-500/20">
              <Truck className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">দ্রুত ডেলিভারি</h4>
              <p className="text-xs text-slate-400">সারা বাংলাদেশে দ্রুত হোম ডেলিভারি</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/10 text-amber-400 flex items-center justify-center shrink-0 border border-amber-500/20">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">১০০% অরিজিনাল পণ্য</h4>
              <p className="text-xs text-slate-400">কোয়ালিটি গ্যারান্টিযুক্ত তাজা পণ্য</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center shrink-0 border border-indigo-500/20">
              <RotateCcw className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">সহজ রিটার্ন পলিসি</h4>
              <p className="text-xs text-slate-400">সমস্যা হলে দ্রুত পরিবর্তনের সুবিধা</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-pink-500/10 text-pink-400 flex items-center justify-center shrink-0 border border-pink-500/20">
              <Headphones className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">২৪/৭ কাস্টমার সাপোর্ট</h4>
              <p className="text-xs text-slate-400">হোয়াটসঅ্যাপ ও ফোনে সার্বক্ষণিক সেবা</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Content */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Col 1: About Tohid Bazar */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-emerald-600 flex items-center justify-center text-white font-black text-lg shadow-md">
                T
              </div>
              <div className="flex flex-col">
                <span className="text-lg font-black text-white tracking-tight">{settings.siteNameBn}</span>
                <span className="text-[10px] uppercase font-bold text-emerald-400 -mt-1 tracking-widest">{settings.siteName}</span>
              </div>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              {settings.siteNameBn} বাংলাদেশের একটি নির্ভরযোগ্য অনলাইন শপ। খাঁটি অরগানিক পণ্য, গ্রোসারি, ইলেকট্রনিক্স ও নিত্যপ্রয়োজনীয় জিনিসপত্র সুলভ মূল্যে আপনার দোরগোড়ায় পৌঁছে দেওয়াই আমাদের লক্ষ্য।
            </p>

            {/* Social Links */}
            <div className="flex items-center gap-3 pt-2">
              {settings.facebookUrl && (
                <a
                  href={settings.facebookUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="w-8 h-8 rounded-full bg-slate-800 hover:bg-[#1877F2] text-slate-300 hover:text-white flex items-center justify-center transition-colors"
                  title="ফেসবুক পেজ"
                >
                  <Facebook className="w-4 h-4" />
                </a>
              )}
              {settings.youtubeUrl && (
                <a
                  href={settings.youtubeUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="w-8 h-8 rounded-full bg-slate-800 hover:bg-[#FF0000] text-slate-300 hover:text-white flex items-center justify-center transition-colors"
                  title="ইউটিউব চ্যানেল"
                >
                  <Youtube className="w-4 h-4" />
                </a>
              )}
              <a
                href={getWhatsAppUrl(settings.whatsappNumber)}
                target="_blank"
                rel="noreferrer"
                className="w-8 h-8 rounded-full bg-slate-800 hover:bg-[#25D366] text-slate-300 hover:text-white flex items-center justify-center transition-colors"
                title="হোয়াটসঅ্যাপ"
              >
                <MessageCircle className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Col 2: Categories */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider">পণ্য ক্যাটাগরি</h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <button onClick={() => onSelectCategory('grocery')} className="hover:text-emerald-400 transition-colors">
                  গ্রোসারি ও অরগানিক খাবার
                </button>
              </li>
              <li>
                <button onClick={() => onSelectCategory('electronics')} className="hover:text-emerald-400 transition-colors">
                  ইলেকট্রনিক্স ও মোবাইল গ্যাজেট
                </button>
              </li>
              <li>
                <button onClick={() => onSelectCategory('fashion')} className="hover:text-emerald-400 transition-colors">
                  ফ্যাশন ও লাইফস্টাইল
                </button>
              </li>
              <li>
                <button onClick={() => onSelectCategory('home')} className="hover:text-emerald-400 transition-colors">
                  হোম ও কিচেন সামগ্রী
                </button>
              </li>
              <li>
                <button onClick={() => onSelectCategory('beauty')} className="hover:text-emerald-400 transition-colors">
                  স্বাস্থ্য ও স্কিন কেয়ার
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Customer Service & Quick Links */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider">গ্রাহক সেবা ও তথ্য</h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <button onClick={onOpenTracking} className="hover:text-emerald-400 transition-colors">
                  লাইভ অর্ডার ট্র্যাকিং
                </button>
              </li>
              <li>
                <a href="#flash-sale" className="hover:text-emerald-400 transition-colors">
                  ফ্ল্যাশ সেল ও স্পেশাল অফার
                </a>
              </li>
              <li>
                <a href="#social-feed" className="hover:text-emerald-400 transition-colors">
                  ইউটিউব ও সোশ্যাল পোস্ট
                </a>
              </li>
              <li>
                <span className="text-slate-400">ডেলিভারি চার্জ: ঢাকা ৳{settings.insideDhakaCharge} / বাইরে ৳{settings.outsideDhakaCharge}</span>
              </li>
              <li>
                <span className="text-slate-400">ক্যাশ অন ডেলিভারি সুবিধা আছে</span>
              </li>
            </ul>
          </div>

          {/* Col 4: Contact Information */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider">যোগাযোগের ঠিকানা</h4>
            <ul className="space-y-2.5 text-xs text-slate-400">
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>মিরপুর, ঢাকা - ১২১৬, বাংলাদেশ</span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
                <a href={`tel:${settings.phoneContact}`} className="hover:underline text-slate-200">
                  {settings.phoneContact}
                </a>
              </li>
              <li className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                <a 
                  href={getWhatsAppUrl(settings.whatsappNumber, 'আসসালামু আলাইকুম')}
                  target="_blank"
                  rel="noreferrer"
                  className="hover:underline text-emerald-300 font-semibold"
                >
                  WhatsApp: {settings.whatsappNumber}
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-emerald-400 shrink-0" />
                <a href="mailto:support@tohidbazar.com" className="hover:underline">
                  support@tohidbazar.com
                </a>
              </li>
            </ul>

            {/* Payment Logos Pill */}
            <div className="pt-2">
              <span className="text-[11px] text-slate-500 block mb-1.5 font-medium">নিরাপদ পেমেন্ট পার্টনার:</span>
              <div className="flex flex-wrap gap-1.5 items-center">
                <span className="px-2 py-0.5 bg-pink-900/40 border border-pink-700/50 text-pink-300 text-[10px] font-bold rounded">
                  bKash: {settings.bkashNumber}
                </span>
                <span className="px-2 py-0.5 bg-amber-900/40 border border-amber-700/50 text-amber-300 text-[10px] font-bold rounded">
                  Nagad: {settings.nagadNumber}
                </span>
                <span className="px-2 py-0.5 bg-emerald-900/40 border border-emerald-700/50 text-emerald-300 text-[10px] font-bold rounded">
                  ক্যাশ অন ডেলিভারি
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar with Admin Link */}
      <div className="max-w-7xl mx-auto px-4 pt-6 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
        <p>© {new Date().getFullYear()} {settings.siteNameBn} (Tohid Bazar). সর্বস্বত্ব সংরক্ষিত।</p>

        <div className="flex items-center gap-4">
          <button
            onClick={onOpenAdmin}
            className="text-slate-400 hover:text-amber-400 flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Lock className="w-3.5 h-3.5" />
            <span>অ্যাডমিন প্যানেল (Control Center)</span>
          </button>
        </div>
      </div>
    </footer>
  );
};
