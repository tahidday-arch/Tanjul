import React from 'react';
import { INITIAL_CATEGORIES } from '../data/initialData';
import { ShoppingBag, Apple, Headphones, Shirt, Home, Sparkles } from 'lucide-react';

interface CategoryListProps {
  selectedCategory: string;
  onSelectCategory: (id: string) => void;
}

export const CategoryList: React.FC<CategoryListProps> = ({
  selectedCategory,
  onSelectCategory,
}) => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Apple': return <Apple className="w-5 h-5 text-emerald-600" />;
      case 'Headphones': return <Headphones className="w-5 h-5 text-indigo-600" />;
      case 'Shirt': return <Shirt className="w-5 h-5 text-sky-600" />;
      case 'Home': return <Home className="w-5 h-5 text-amber-600" />;
      case 'Sparkles': return <Sparkles className="w-5 h-5 text-rose-600" />;
      default: return <ShoppingBag className="w-5 h-5 text-teal-600" />;
    }
  };

  return (
    <section className="my-8 max-w-7xl mx-auto px-4">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            জনপ্রিয় ক্যাটাগরি সমূহ (Popular Categories)
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            আপনার প্রয়োজনীয় পণ্য সহজে খুঁজে নিতে বিভাগ নির্বাচন করুন
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 sm:gap-4">
        {INITIAL_CATEGORIES.map((cat) => {
          const isSelected = selectedCategory === cat.id;

          return (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat.id)}
              className={`p-3.5 rounded-2xl flex flex-col items-center text-center transition-all cursor-pointer border ${
                isSelected
                  ? 'bg-emerald-50 border-emerald-500 shadow-md ring-2 ring-emerald-500/20'
                  : 'bg-white border-slate-200 hover:border-emerald-300 hover:shadow-sm'
              }`}
            >
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-2 transition-transform ${
                isSelected ? 'bg-emerald-100 scale-110' : 'bg-slate-100 hover:scale-105'
              }`}>
                {getIcon(cat.icon)}
              </div>
              <span className={`text-xs sm:text-sm font-bold block ${
                isSelected ? 'text-emerald-800' : 'text-slate-800'
              }`}>
                {cat.nameBn}
              </span>
              <span className="text-[11px] text-slate-400 mt-0.5">
                {cat.count} টি আইটেম
              </span>
            </button>
          );
        })}
      </div>
    </section>
  );
};
