import React from 'react';
import { Home, Grid, Zap, ShoppingCart, Menu, ArrowRight } from 'lucide-react';

interface MobileBottomNavProps {
  activeTab: 'home' | 'categories' | 'offers' | 'cart' | 'menu';
  cartCount: number;
  cartTotal: number;
  wishlistCount: number;
  onNavigateTab: (tab: 'home' | 'categories' | 'offers' | 'cart' | 'menu') => void;
  onOpenCart: () => void;
  onOpenCategories: () => void;
  onOpenMenu: () => void;
  onOpenFlashSale: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  activeTab,
  cartCount,
  cartTotal,
  wishlistCount,
  onNavigateTab,
  onOpenCart,
  onOpenCategories,
  onOpenMenu,
  onOpenFlashSale,
}) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-40">
      {/* Optional Floating Mini Cart Bar when cart has items */}
      {cartCount > 0 && (
        <div className="max-w-md mx-auto px-3 pb-1">
          <button
            onClick={onOpenCart}
            className="w-full bg-slate-900/95 backdrop-blur-md text-white px-4 py-2 rounded-2xl shadow-xl border border-slate-700/50 flex items-center justify-between active:scale-98 transition-transform cursor-pointer"
          >
            <div className="flex items-center gap-2.5">
              <div className="relative">
                <div className="w-8 h-8 rounded-full bg-emerald-500 flex items-center justify-center text-white">
                  <ShoppingCart className="w-4 h-4" />
                </div>
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-amber-400 text-slate-950 font-black text-[10px] rounded-full flex items-center justify-center">
                  {cartCount}
                </span>
              </div>
              <div className="text-left">
                <p className="text-xs font-bold leading-tight">{cartCount} টি পণ্য যোগ করা হয়েছে</p>
                <p className="text-[11px] text-emerald-400 font-semibold leading-tight">সর্বমোট: ৳{cartTotal.toLocaleString()}</p>
              </div>
            </div>

            <div className="flex items-center gap-1 text-xs font-bold text-emerald-400 bg-white/10 px-2.5 py-1 rounded-xl">
              <span>কার্ট দেখুন</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </div>
          </button>
        </div>
      )}

      {/* Main Native App Style Bottom Tab Bar */}
      <nav 
        aria-label="Mobile Navigation"
        className="bg-white/95 backdrop-blur-xl border-t border-slate-200/90 shadow-[0_-8px_24px_rgba(0,0,0,0.06)] px-2 py-1.5 safe-area-bottom"
      >
        <div className="max-w-md mx-auto grid grid-cols-5 gap-1">
          {/* 1. Home Tab */}
          <button
            onClick={() => {
              onNavigateTab('home');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all cursor-pointer active:scale-90 ${
              activeTab === 'home' ? 'text-emerald-600 font-bold' : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            <div className="relative">
              <Home className={`w-5 h-5 ${activeTab === 'home' ? 'stroke-[2.5px]' : 'stroke-2'}`} />
              {activeTab === 'home' && (
                <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 bg-emerald-600 rounded-full" />
              )}
            </div>
            <span className="text-[10px] mt-1 leading-tight">হোম</span>
          </button>

          {/* 2. Categories Tab */}
          <button
            onClick={() => {
              onNavigateTab('categories');
              onOpenCategories();
            }}
            className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all cursor-pointer active:scale-90 ${
              activeTab === 'categories' ? 'text-emerald-600 font-bold' : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            <div className="relative">
              <Grid className={`w-5 h-5 ${activeTab === 'categories' ? 'stroke-[2.5px]' : 'stroke-2'}`} />
              {activeTab === 'categories' && (
                <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 bg-emerald-600 rounded-full" />
              )}
            </div>
            <span className="text-[10px] mt-1 leading-tight">ক্যাটাগরি</span>
          </button>

          {/* 3. Flash Offers Tab */}
          <button
            onClick={() => {
              onNavigateTab('offers');
              onOpenFlashSale();
            }}
            className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all cursor-pointer active:scale-90 relative ${
              activeTab === 'offers' ? 'text-rose-600 font-bold' : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            <div className="relative">
              <Zap className={`w-5 h-5 ${activeTab === 'offers' ? 'stroke-[2.5px] text-rose-600' : 'text-rose-500'}`} />
              <span className="absolute -top-1 -right-1 flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
              </span>
              {activeTab === 'offers' && (
                <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 bg-rose-600 rounded-full" />
              )}
            </div>
            <span className="text-[10px] mt-1 leading-tight text-rose-600">অফার</span>
          </button>

          {/* 4. Cart Tab */}
          <button
            onClick={() => {
              onNavigateTab('cart');
              onOpenCart();
            }}
            className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all cursor-pointer active:scale-90 ${
              activeTab === 'cart' ? 'text-emerald-600 font-bold' : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            <div className="relative">
              <ShoppingCart className={`w-5 h-5 ${activeTab === 'cart' ? 'stroke-[2.5px]' : 'stroke-2'}`} />
              {cartCount > 0 && (
                <span className="absolute -top-1.5 -right-2.5 bg-rose-500 text-white font-extrabold text-[9px] min-w-[16px] h-4 px-1 rounded-full flex items-center justify-center ring-2 ring-white">
                  {cartCount}
                </span>
              )}
              {activeTab === 'cart' && (
                <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 bg-emerald-600 rounded-full" />
              )}
            </div>
            <span className="text-[10px] mt-1 leading-tight">কার্ট</span>
          </button>

          {/* 5. Menu / Account Tab */}
          <button
            onClick={() => {
              onNavigateTab('menu');
              onOpenMenu();
            }}
            className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all cursor-pointer active:scale-90 ${
              activeTab === 'menu' ? 'text-emerald-600 font-bold' : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            <div className="relative">
              <Menu className={`w-5 h-5 ${activeTab === 'menu' ? 'stroke-[2.5px]' : 'stroke-2'}`} />
              {wishlistCount > 0 && (
                <span className="absolute -top-1 -right-1 w-2 h-2 bg-rose-500 rounded-full" />
              )}
              {activeTab === 'menu' && (
                <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 bg-emerald-600 rounded-full" />
              )}
            </div>
            <span className="text-[10px] mt-1 leading-tight">মেনু</span>
          </button>
        </div>
      </nav>
    </div>
  );
};
