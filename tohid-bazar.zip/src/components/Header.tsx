import React, { useState } from 'react';
import { 
  ShoppingBag, 
  Search, 
  Heart, 
  ShoppingCart, 
  Phone, 
  ShieldCheck, 
  Truck, 
  Menu, 
  X, 
  SlidersHorizontal,
  Compass,
  Sparkles,
  Zap,
  Tag,
  Share2,
  Video,
  UserCheck,
  MessageCircle
} from 'lucide-react';
import { WebsiteSettings, Product } from '../types';
import { getWhatsAppUrl } from '../utils';

interface HeaderProps {
  settings: WebsiteSettings;
  cartCount: number;
  cartTotal: number;
  wishlistCount: number;
  onOpenCart: () => void;
  onOpenWishlist?: () => void;
  onOpenTracking: () => void;
  onOpenAdmin: () => void;
  onOpenInfo?: (page: string) => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  selectedCategory: string;
  onSelectCategory: (catId: string) => void;
  products?: Product[];
  onSelectProduct?: (product: Product) => void;
  activeSection?: string;
  onNavigateSection?: (section: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  settings,
  cartCount,
  cartTotal,
  wishlistCount,
  onOpenCart,
  onOpenWishlist = () => {},
  onOpenTracking,
  onOpenAdmin,
  onOpenInfo = (_page: string) => {},
  searchQuery,
  onSearchChange,
  selectedCategory,
  onSelectCategory,
  products = [],
  onSelectProduct = (_product: Product) => {},
  activeSection = 'home',
  onNavigateSection = (_section: string) => {}
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isSearchFocused, setIsSearchFocused] = useState(false);

  // Instant search recommendations
  const searchResults = searchQuery.trim().length > 0 
    ? products.filter(p => 
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.nameBn.includes(searchQuery) ||
        p.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.brand.toLowerCase().includes(searchQuery.toLowerCase())
      ).slice(0, 5)
    : [];

  return (
    <header className="sticky top-0 z-40 bg-white shadow-sm border-b border-slate-200">
      {/* Top Announcement Bar */}
      <div className="bg-emerald-700 text-white text-xs md:text-sm py-1.5 px-4 font-medium">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-1">
          <div className="flex items-center gap-2 text-center sm:text-left">
            <span className="bg-emerald-800 text-emerald-100 text-[11px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">
              অফার
            </span>
            <span className="truncate">{settings.announcementText}</span>
          </div>
          <div className="flex items-center gap-3 sm:gap-4 text-xs">
            <a 
              href={getWhatsAppUrl(settings.whatsappNumber, 'আসসালামু আলাইকুম, আমি তৌহিদ বাজার থেকে কিছু জানতে চাই।')}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-1 text-emerald-100 hover:text-white transition-colors"
              title="হোয়াটসঅ্যাপ চ্যাট"
            >
              <MessageCircle className="w-3.5 h-3.5 text-emerald-300" />
              <span className="font-semibold">{settings.whatsappNumber}</span>
            </a>
            <span className="hidden md:inline opacity-60">|</span>
            <button 
              onClick={onOpenTracking}
              className="flex items-center gap-1 hover:text-emerald-200 transition-colors cursor-pointer"
            >
              <Truck className="w-3.5 h-3.5" />
              <span>অর্ডার ট্র্যাকিং</span>
            </button>
            <span className="hidden md:inline opacity-60">|</span>
            <button
              onClick={onOpenAdmin}
              className="bg-amber-400 text-slate-900 px-2 py-0.5 rounded font-bold text-[11px] hover:bg-amber-300 transition-colors flex items-center gap-1 cursor-pointer"
              title="Click to access Admin Control Panel"
            >
              <ShieldCheck className="w-3 h-3" />
              <span>অ্যাডমিন</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Header Row */}
      <div className="max-w-7xl mx-auto px-4 py-3 sm:py-4">
        <div className="flex items-center justify-between gap-3 md:gap-6">
          {/* Logo & Brand Identity */}
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-lg text-slate-700 hover:bg-slate-100"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>

            <button 
              onClick={() => onNavigateSection('home')}
              className="flex items-center gap-2.5 text-left group cursor-pointer"
            >
              <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-md shadow-emerald-600/20 group-hover:scale-105 transition-transform">
                <ShoppingBag className="w-6 h-6" />
              </div>
              <div>
                <span className="text-xl sm:text-2xl font-extrabold tracking-tight text-slate-900 block leading-tight">
                  {settings.siteName}
                </span>
                <span className="text-[11px] font-semibold text-emerald-700 block tracking-wide">
                  {settings.siteNameBn}
                </span>
              </div>
            </button>
          </div>

          {/* Search Bar with Live Suggestions */}
          <div className="relative flex-1 max-w-xl hidden md:block">
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                onFocus={() => setIsSearchFocused(true)}
                placeholder="পণ্য বা ব্র্যান্ড খুঁজুন... (e.g. মধু, ইয়ারবাডস, তেল, পাঞ্জাবি)"
                className="w-full pl-10 pr-10 py-2.5 bg-slate-100 border border-slate-200 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition-all"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
              {searchQuery && (
                <button
                  onClick={() => onSearchChange('')}
                  className="absolute right-3.5 top-3 text-slate-400 hover:text-slate-600 text-xs"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Instant Search Suggestions Box */}
            {isSearchFocused && searchQuery.trim().length > 0 && (
              <div 
                className="absolute top-full left-0 right-0 mt-1.5 bg-white border border-slate-200 rounded-2xl shadow-xl z-50 overflow-hidden"
                onMouseDown={(e) => e.preventDefault()}
              >
                <div className="p-2 border-b border-slate-100 bg-slate-50 text-xs text-slate-500 font-medium flex justify-between">
                  <span>অনুসন্ধানের ফলাফল ({searchResults.length})</span>
                  <span>Esc বা ক্লিক করে বন্ধ করুন</span>
                </div>
                {searchResults.length > 0 ? (
                  <div className="divide-y divide-slate-100">
                    {searchResults.map((product) => (
                      <button
                        key={product.id}
                        onClick={() => {
                          onSelectProduct(product);
                          setIsSearchFocused(false);
                        }}
                        className="w-full text-left p-3 hover:bg-emerald-50 flex items-center gap-3 transition-colors cursor-pointer"
                      >
                        <img 
                          src={product.image} 
                          alt={product.nameBn} 
                          className="w-10 h-10 object-cover rounded-lg border border-slate-200 shrink-0" 
                        />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold text-slate-900 truncate">{product.nameBn}</p>
                          <p className="text-xs text-slate-500 truncate">{product.brand} · {product.categoryBn}</p>
                        </div>
                        <div className="text-right shrink-0">
                          <span className="text-sm font-bold text-emerald-700">৳{product.discountPrice}</span>
                          {product.regularPrice > product.discountPrice && (
                            <span className="text-xs text-slate-400 line-through block">৳{product.regularPrice}</span>
                          )}
                        </div>
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="p-4 text-center text-sm text-slate-500">
                    "{searchQuery}" এর সাথে মিলে এমন কোনো পণ্য পাওয়া যায়নি।
                  </div>
                )}
              </div>
            )}
          </div>

          {/* User Actions: Wishlist & Cart */}
          <div className="flex items-center gap-2 sm:gap-4">
            {/* Wishlist Button */}
            <button
              onClick={onOpenWishlist}
              className="relative p-2.5 rounded-full text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
              title="পছন্দের তালিকা (Wishlist)"
            >
              <Heart className="w-5 h-5" />
              {wishlistCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-rose-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                  {wishlistCount}
                </span>
              )}
            </button>

            {/* Shopping Cart Pill Button */}
            <button
              onClick={onOpenCart}
              className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-3 sm:px-4 py-2 sm:py-2.5 rounded-full shadow-sm hover:shadow transition-all cursor-pointer group"
            >
              <div className="relative">
                <ShoppingCart className="w-5 h-5 group-hover:scale-110 transition-transform" />
                {cartCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-amber-400 text-slate-950 text-[11px] font-black w-4 h-4 rounded-full flex items-center justify-center ring-2 ring-emerald-600">
                    {cartCount}
                  </span>
                )}
              </div>
              <div className="text-left hidden sm:block">
                <span className="text-[10px] uppercase font-bold text-emerald-100 block leading-tight">কার্ট</span>
                <span className="text-xs font-extrabold leading-tight">৳{cartTotal.toLocaleString()}</span>
              </div>
            </button>
          </div>
        </div>

        {/* Mobile Search Bar */}
        <div className="mt-3 md:hidden">
          <div className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="পণ্য বা ব্র্যান্ড খুঁজুন..."
              className="w-full pl-9 pr-8 py-2 bg-slate-100 border border-slate-200 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Navigation Sub-header / Category Links */}
      <nav className="bg-slate-50 border-t border-slate-200 hidden lg:block">
        <div className="max-w-7xl mx-auto px-4 flex items-center justify-between text-sm font-medium">
          <div className="flex items-center space-x-1">
            <button
              onClick={() => onSelectCategory('all')}
              className={`px-3.5 py-2.5 flex items-center gap-1.5 transition-colors cursor-pointer ${
                selectedCategory === 'all' 
                  ? 'text-emerald-700 font-bold border-b-2 border-emerald-600' 
                  : 'text-slate-700 hover:text-emerald-600'
              }`}
            >
              <SlidersHorizontal className="w-4 h-4" />
              <span>সকল ক্যাটাগরি</span>
            </button>

            <button
              onClick={() => onSelectCategory('grocery')}
              className={`px-3.5 py-2.5 transition-colors cursor-pointer ${
                selectedCategory === 'grocery' 
                  ? 'text-emerald-700 font-bold border-b-2 border-emerald-600' 
                  : 'text-slate-700 hover:text-emerald-600'
              }`}
            >
              গ্রোসারি ও অরগানিক
            </button>

            <button
              onClick={() => onSelectCategory('electronics')}
              className={`px-3.5 py-2.5 transition-colors cursor-pointer ${
                selectedCategory === 'electronics' 
                  ? 'text-emerald-700 font-bold border-b-2 border-emerald-600' 
                  : 'text-slate-700 hover:text-emerald-600'
              }`}
            >
              ইলেকট্রনিক্স ও গ্যাজেট
            </button>

            <button
              onClick={() => onSelectCategory('fashion')}
              className={`px-3.5 py-2.5 transition-colors cursor-pointer ${
                selectedCategory === 'fashion' 
                  ? 'text-emerald-700 font-bold border-b-2 border-emerald-600' 
                  : 'text-slate-700 hover:text-emerald-600'
              }`}
            >
              ফ্যাশন ও পোশাক
            </button>

            <button
              onClick={() => onSelectCategory('home')}
              className={`px-3.5 py-2.5 transition-colors cursor-pointer ${
                selectedCategory === 'home' 
                  ? 'text-emerald-700 font-bold border-b-2 border-emerald-600' 
                  : 'text-slate-700 hover:text-emerald-600'
              }`}
            >
              হোম ও কিচেন
            </button>

            <button
              onClick={() => onSelectCategory('beauty')}
              className={`px-3.5 py-2.5 transition-colors cursor-pointer ${
                selectedCategory === 'beauty' 
                  ? 'text-emerald-700 font-bold border-b-2 border-emerald-600' 
                  : 'text-slate-700 hover:text-emerald-600'
              }`}
            >
              স্বাস্থ্য ও রূপচর্চা
            </button>
          </div>

          <div className="flex items-center space-x-3 text-xs">
            <a 
              href="#flash-sale"
              className="flex items-center gap-1 text-rose-600 font-bold hover:underline"
            >
              <Zap className="w-3.5 h-3.5" />
              <span>ফ্ল্যাশ সেল</span>
            </a>
            <a 
              href="#social-feed"
              className="flex items-center gap-1 text-indigo-600 font-bold hover:underline"
            >
              <Video className="w-3.5 h-3.5" />
              <span>ভিডিও ও পোস্ট</span>
            </a>
            <button
              onClick={() => onOpenInfo('contact')}
              className="text-slate-600 hover:text-emerald-600"
            >
              হেল্পলাইন
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white px-4 py-4 space-y-3">
          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">ক্যাটাগরি সমূহ</p>
          <div className="grid grid-cols-2 gap-2">
            {[
              { id: 'all', name: 'সকল ক্যাটাগরি' },
              { id: 'grocery', name: 'গ্রোসারি ও মধু' },
              { id: 'electronics', name: 'ইলেকট্রনিক্স' },
              { id: 'fashion', name: 'ফ্যাশন পোশাক' },
              { id: 'home', name: 'হোম ও কিচেন' },
              { id: 'beauty', name: 'স্বাস্থ্য ও রূপচর্চা' }
            ].map(cat => (
              <button
                key={cat.id}
                onClick={() => {
                  onSelectCategory(cat.id);
                  setMobileMenuOpen(false);
                }}
                className={`p-2.5 text-left text-xs font-semibold rounded-lg border ${
                  selectedCategory === cat.id 
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200' 
                    : 'bg-slate-50 text-slate-700 border-slate-100 hover:bg-slate-100'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>

          <div className="pt-2 border-t border-slate-100 space-y-2">
            <button
              onClick={() => {
                onOpenTracking();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-between p-2.5 text-xs font-semibold rounded-lg bg-emerald-50 text-emerald-800"
            >
              <span className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-emerald-600" />
                <span>আমার অর্ডার ট্র্যাক করুন</span>
              </span>
              <span>›</span>
            </button>

            <button
              onClick={() => {
                onOpenAdmin();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-between p-2.5 text-xs font-semibold rounded-lg bg-amber-50 text-amber-900 border border-amber-200"
            >
              <span className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-amber-600" />
                <span>অ্যাডমিন কন্ট্রোল সেন্টার</span>
              </span>
              <span>›</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
