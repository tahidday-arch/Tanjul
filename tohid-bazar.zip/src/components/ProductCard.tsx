import React from 'react';
import { ShoppingCart, Heart, Share2, Star, Zap, Eye, Video, CheckCircle, AlertTriangle } from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
  onBuyNow: (product: Product) => void;
  onSelectProduct: (product: Product) => void;
  onShare: (product: Product) => void;
  isWishlisted: boolean;
  onToggleWishlist: (productId: string) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onAddToCart,
  onBuyNow,
  onSelectProduct,
  onShare,
  isWishlisted,
  onToggleWishlist,
}) => {
  const discountPercent = product.regularPrice > product.discountPrice
    ? Math.round(((product.regularPrice - product.discountPrice) / product.regularPrice) * 100)
    : 0;

  const isOutOfStock = product.stock <= 0;
  const isLowStock = product.stock > 0 && product.stock <= 5;

  return (
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden hover:shadow-xl hover:border-emerald-300 transition-all flex flex-col justify-between group relative">
      {/* Image Container with Badges */}
      <div className="relative overflow-hidden bg-slate-100 aspect-square">
        <img
          src={product.image}
          alt={product.nameBn}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 cursor-pointer"
          onClick={() => onSelectProduct(product)}
          loading="lazy"
        />

        {/* Top Badges */}
        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1 z-10">
          {discountPercent > 0 && (
            <span className="bg-rose-600 text-white text-[11px] font-black px-2 py-0.5 rounded-full shadow-sm">
              {discountPercent}% ছাড়
            </span>
          )}
          {product.isFlashSale && (
            <span className="bg-amber-400 text-slate-950 text-[10px] font-extrabold px-2 py-0.5 rounded-full shadow-sm flex items-center gap-0.5">
              <Zap className="w-2.5 h-2.5 fill-current" />
              <span>ফ্ল্যাশ সেল</span>
            </span>
          )}
        </div>

        {/* Quick Actions overlay: Wishlist, Share, Quick View */}
        <div className="absolute top-2.5 right-2.5 flex flex-col gap-1.5 z-10">
          <button
            onClick={() => onToggleWishlist(product.id)}
            className={`w-8 h-8 rounded-full flex items-center justify-center transition-all backdrop-blur-sm shadow-sm cursor-pointer ${
              isWishlisted
                ? 'bg-rose-50 text-rose-600'
                : 'bg-white/90 text-slate-600 hover:text-rose-600 hover:bg-white'
            }`}
            title={isWishlisted ? 'পছন্দ তালিকা থেকে সরান' : 'পছন্দ তালিকায় যোগ করুন'}
          >
            <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-rose-600' : ''}`} />
          </button>

          <button
            onClick={() => onShare(product)}
            className="w-8 h-8 rounded-full bg-white/90 hover:bg-white text-slate-600 hover:text-emerald-600 flex items-center justify-center transition-all backdrop-blur-sm shadow-sm cursor-pointer"
            title="ফেসবুক/হোয়াটসঅ্যাপে শেয়ার করুন"
          >
            <Share2 className="w-4 h-4" />
          </button>

          <button
            onClick={() => onSelectProduct(product)}
            className="w-8 h-8 rounded-full bg-white/90 hover:bg-white text-slate-600 hover:text-emerald-600 flex items-center justify-center transition-all backdrop-blur-sm shadow-sm cursor-pointer"
            title="বিস্তারিত দেখুন (Quick View)"
          >
            <Eye className="w-4 h-4" />
          </button>
        </div>

        {/* Video badge if video exists */}
        {product.videoUrl && (
          <div className="absolute bottom-2.5 left-2.5 bg-black/60 backdrop-blur-md text-white text-[11px] px-2 py-0.5 rounded-md flex items-center gap-1">
            <Video className="w-3 h-3 text-red-400" />
            <span>ভিডিও রিভিউ</span>
          </div>
        )}

        {/* Out of stock overlay */}
        {isOutOfStock && (
          <div className="absolute inset-0 bg-black/50 backdrop-blur-[2px] flex items-center justify-center">
            <span className="bg-rose-600 text-white font-bold text-xs px-3 py-1.5 rounded-xl uppercase tracking-wider shadow-lg">
              স্টক আউট (Stock Out)
            </span>
          </div>
        )}
      </div>

      {/* Product Information */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          {/* Category & Brand */}
          <div className="flex items-center justify-between text-[11px] text-slate-400 font-medium mb-1">
            <span className="text-emerald-700 font-semibold uppercase">{product.categoryBn}</span>
            <span>{product.brand}</span>
          </div>

          {/* Product Title in Bangla */}
          <h3
            onClick={() => onSelectProduct(product)}
            className="font-bold text-slate-900 text-sm leading-snug line-clamp-2 hover:text-emerald-700 transition-colors cursor-pointer"
            title={product.nameBn}
          >
            {product.nameBn}
          </h3>

          {/* Rating & SKU */}
          <div className="mt-2 flex items-center justify-between text-xs">
            <div className="flex items-center gap-1">
              <div className="flex items-center text-amber-400">
                <Star className="w-3.5 h-3.5 fill-amber-400" />
              </div>
              <span className="font-bold text-slate-700">{product.rating}</span>
              <span className="text-slate-400 text-[11px]">({product.reviewCount})</span>
            </div>

            {product.unit && (
              <span className="text-[11px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded">
                {product.unit}
              </span>
            )}
          </div>

          {/* Price */}
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-lg font-extrabold text-slate-900">
              ৳{product.discountPrice.toLocaleString()}
            </span>
            {product.regularPrice > product.discountPrice && (
              <span className="text-xs text-slate-400 line-through">
                ৳{product.regularPrice.toLocaleString()}
              </span>
            )}
          </div>

          {/* Stock Alert info */}
          <div className="mt-1.5">
            {isLowStock ? (
              <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-600">
                <AlertTriangle className="w-3 h-3" />
                <span>মাত্র {product.stock} টি অবশিষ্ট আছে</span>
              </span>
            ) : isOutOfStock ? (
              <span className="text-[11px] font-medium text-rose-500">আপাতত মজুত নেই</span>
            ) : (
              <span className="inline-flex items-center gap-1 text-[11px] font-medium text-emerald-600">
                <CheckCircle className="w-3 h-3" />
                <span>ইন স্টক ({product.stock} টি)</span>
              </span>
            )}
          </div>
        </div>

        {/* Buttons Action Bar */}
        <div className="mt-4 pt-3 border-t border-slate-100 grid grid-cols-2 gap-2">
          <button
            disabled={isOutOfStock}
            onClick={() => onAddToCart(product)}
            className={`py-2 px-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer border ${
              isOutOfStock
                ? 'opacity-40 cursor-not-allowed border-slate-200 text-slate-400'
                : 'border-emerald-600 text-emerald-700 hover:bg-emerald-50 active:scale-98'
            }`}
          >
            <ShoppingCart className="w-3.5 h-3.5" />
            <span>কার্ট</span>
          </button>

          <button
            disabled={isOutOfStock}
            onClick={() => onBuyNow(product)}
            className={`py-2 px-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition-all shadow-sm cursor-pointer ${
              isOutOfStock
                ? 'opacity-40 cursor-not-allowed bg-slate-300 text-slate-600'
                : 'bg-emerald-600 hover:bg-emerald-700 text-white hover:shadow active:scale-98'
            }`}
          >
            <span>এখনই কিনুন</span>
          </button>
        </div>
      </div>
    </div>
  );
};
