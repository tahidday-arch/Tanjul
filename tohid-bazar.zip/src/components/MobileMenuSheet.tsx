import React from 'react';
import { 
  X, 
  Truck, 
  Heart, 
  Phone, 
  MessageCircle, 
  ShieldCheck, 
  Download, 
  Share2, 
  HelpCircle, 
  ShoppingBag,
  Info,
  ChevronRight
} from 'lucide-react';
import { WebsiteSettings } from '../types';
import { getWhatsAppUrl } from '../utils';

interface MobileMenuSheetProps {
  isOpen: boolean;
  onClose: () => void;
  settings: WebsiteSettings;
  wishlistCount: number;
  onOpenWishlist: () => void;
  onOpenTracking: () => void;
  onOpenAdmin: () => void;
  onOpenShareApp: () => void;
  onInstallApp?: () => void;
  isInstallable?: boolean;
}

export const MobileMenuSheet: React.FC<MobileMenuSheetProps> = ({
  isOpen,
  onClose,
  settings,
  wishlistCount,
  onOpenWishlist,
  onOpenTracking,
  onOpenAdmin,
  onOpenShareApp,
  onInstallApp,
  isInstallable = true,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* Sheet Modal */}
      <div className="relative w-full max-w-lg bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl z-10 max-h-[90vh] flex flex-col animate-in slide-in-from-bottom duration-200">
        {/* Pull Handle */}
        <div className="w-12 h-1.5 bg-slate-200 rounded-full mx-auto mt-3 mb-1" />

        {/* Profile / App Header Box */}
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-md shadow-emerald-500/20">
              <ShoppingBag className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-slate-900 leading-tight">
                {settings.siteNameBn}
              </h3>
              <p className="text-xs text-emerald-700 font-medium leading-tight mt-0.5">
                বিশ্বস্ত অনলাইন শপিং অ্যাপ
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Options List */}
        <div className="p-4 overflow-y-auto space-y-2.5 flex-1">
          {/* 1. Track Order */}
          <button
            onClick={() => {
              onOpenTracking();
              onClose();
            }}
            className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-emerald-50 hover:bg-emerald-100/80 border border-emerald-200 text-emerald-900 transition-all cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-xs">
                <Truck className="w-5 h-5" />
              </div>
              <div className="text-left">
                <span className="text-sm font-bold block">অর্ডার ট্র্যাক করুন</span>
                <span className="text-xs text-emerald-700">লাইভ কুরিয়ার ও ডেলিভারি স্ট্যাটাস</span>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-emerald-600" />
          </button>

          {/* 2. Wishlist */}
          <button
            onClick={() => {
              onOpenWishlist();
              onClose();
            }}
            className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-slate-50 hover:bg-slate-100 border border-slate-200 transition-all cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center">
                <Heart className="w-5 h-5" />
              </div>
              <div className="text-left">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold text-slate-800">পছন্দের তালিকা (Wishlist)</span>
                  {wishlistCount > 0 && (
                    <span className="bg-rose-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">
                      {wishlistCount}
                    </span>
                  )}
                </div>
                <span className="text-xs text-slate-400">আপনার সংরক্ষিত পছন্দের পণ্য</span>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>

          {/* 3. WhatsApp Direct Contact */}
          <a
            href={getWhatsAppUrl(settings.whatsappNumber, 'আসসালামু আলাইকুম, আমি তৌহিদ বাজার অ্যাপ থেকে যোগাযোগ করছি।')}
            target="_blank"
            rel="noreferrer"
            className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-[#25D366]/10 hover:bg-[#25D366]/20 border border-[#25D366]/30 transition-all text-slate-900 cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#25D366] text-white flex items-center justify-center shadow-xs">
                <MessageCircle className="w-5 h-5" />
              </div>
              <div className="text-left">
                <span className="text-sm font-bold text-slate-900 block">হোয়াটসঅ্যাপ চ্যাট</span>
                <span className="text-xs font-semibold text-emerald-800">{settings.whatsappNumber}</span>
              </div>
            </div>
            <span className="text-xs font-bold text-[#25D366] bg-white px-2 py-1 rounded-lg shadow-xs">চ্যাট</span>
          </a>

          {/* 4. Phone Contact */}
          <a
            href={`tel:${settings.phoneContact}`}
            className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-slate-50 hover:bg-slate-100 border border-slate-200 transition-all text-slate-800 cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center">
                <Phone className="w-5 h-5" />
              </div>
              <div className="text-left">
                <span className="text-sm font-bold block">হটলাইন হেল্পলাইন</span>
                <span className="text-xs text-slate-500">{settings.phoneContact} (সকাল ৯টা - রাত ১০টা)</span>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </a>

          {/* 5. Share App */}
          <button
            onClick={() => {
              onOpenShareApp();
              onClose();
            }}
            className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-slate-50 hover:bg-slate-100 border border-slate-200 transition-all cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-100 text-indigo-600 flex items-center justify-center">
                <Share2 className="w-5 h-5" />
              </div>
              <div className="text-left">
                <span className="text-sm font-bold text-slate-800 block">অ্যাপ বন্ধুদের সাথে শেয়ার করুন</span>
                <span className="text-xs text-slate-400">ফেসবুক, হোয়াটসঅ্যাপ বা মেসেঞ্জারে</span>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>

          {/* 6. Install App PWA Trigger */}
          {onInstallApp && (
            <button
              onClick={() => {
                onInstallApp();
                onClose();
              }}
              className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-amber-50 hover:bg-amber-100 border border-amber-300 transition-all text-amber-900 cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center shadow-xs">
                  <Download className="w-5 h-5" />
                </div>
                <div className="text-left">
                  <span className="text-sm font-bold block">মোবাইল অ্যাপ ইনস্টল করুন</span>
                  <span className="text-xs text-amber-700">হোম স্ক্রিনে রাখুন দ্রুত এক-ক্লিকে প্রবেশের জন্য</span>
                </div>
              </div>
              <span className="text-xs font-bold bg-amber-200 text-amber-900 px-2 py-1 rounded-lg">ইনস্টল</span>
            </button>
          )}

          {/* 7. Admin Panel */}
          <button
            onClick={() => {
              onOpenAdmin();
              onClose();
            }}
            className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-slate-900 text-white hover:bg-slate-800 transition-all cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div className="text-left">
                <span className="text-sm font-bold block">অ্যাডমিন কন্ট্রোল সেন্টার</span>
                <span className="text-xs text-slate-400">পাসওয়ার্ড: admin123</span>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>
        </div>

        {/* Footer info in Sheet */}
        <div className="p-4 bg-slate-50 rounded-b-3xl text-center border-t border-slate-100">
          <p className="text-[11px] text-slate-400">
            {settings.siteName} App Version 2.0 · সর্বস্বত্ব সংরক্ষিত
          </p>
        </div>
      </div>
    </div>
  );
};
