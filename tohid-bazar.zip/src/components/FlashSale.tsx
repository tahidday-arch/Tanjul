import React, { useState, useEffect } from 'react';
import { Zap, Clock, ShoppingCart, ArrowRight } from 'lucide-react';
import { Product } from '../types';

interface FlashSaleProps {
  products: Product[];
  onAddToCart: (product: Product) => void;
  onBuyNow: (product: Product) => void;
  onSelectProduct: (product: Product) => void;
}

export const FlashSale: React.FC<FlashSaleProps> = ({
  products,
  onAddToCart,
  onBuyNow,
  onSelectProduct,
}) => {
  const flashProducts = products.filter((p) => p.isFlashSale);

  // Countdown timer for 8 hours flash sale
  const [timeLeft, setTimeLeft] = useState({
    hours: 7,
    minutes: 45,
    seconds: 20
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: 59, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        }
        return { hours: 8, minutes: 0, seconds: 0 }; // reset
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  if (flashProducts.length === 0) return null;

  return (
    <section id="flash-sale" className="my-8 max-w-7xl mx-auto px-4">
      <div className="bg-gradient-to-r from-rose-600 via-pink-600 to-red-600 rounded-2xl md:rounded-3xl p-4 sm:p-6 text-white shadow-xl">
        {/* Flash Sale Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-white/20">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center text-amber-300">
              <Zap className="w-6 h-6 fill-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-black tracking-tight">
                  ফ্ল্যাশ সেল (Flash Sale)
                </h2>
                <span className="bg-amber-300 text-slate-900 text-xs font-black px-2 py-0.5 rounded-full uppercase">
                  সীমিত সময়
                </span>
              </div>
              <p className="text-xs sm:text-sm text-pink-100 mt-0.5">
                সর্বোচ্চ ৫০% পর্যন্ত বিশেষ ছাড়! স্টক ফুরিয়ে যাওয়ার আগেই অর্ডার করুন।
              </p>
            </div>
          </div>

          {/* Countdown Clock Box */}
          <div className="flex items-center gap-2 bg-black/30 backdrop-blur-md px-4 py-2.5 rounded-2xl self-start md:self-auto border border-white/10">
            <Clock className="w-4 h-4 text-amber-300 shrink-0" />
            <span className="text-xs text-slate-200 font-medium mr-1">অফারের সময় বাকি:</span>
            <div className="flex items-center gap-1.5 font-mono font-bold text-sm">
              <span className="bg-slate-900 text-amber-300 px-2 py-1 rounded-lg">
                {String(timeLeft.hours).padStart(2, '0')}
              </span>
              <span>:</span>
              <span className="bg-slate-900 text-amber-300 px-2 py-1 rounded-lg">
                {String(timeLeft.minutes).padStart(2, '0')}
              </span>
              <span>:</span>
              <span className="bg-slate-900 text-amber-300 px-2 py-1 rounded-lg">
                {String(timeLeft.seconds).padStart(2, '0')}
              </span>
            </div>
          </div>
        </div>

        {/* Product Cards Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 pt-6">
          {flashProducts.map((product) => {
            const discountPercent = Math.round(
              ((product.regularPrice - product.discountPrice) / product.regularPrice) * 100
            );

            return (
              <div
                key={product.id}
                className="bg-white rounded-2xl p-4 text-slate-900 flex flex-col justify-between shadow-md hover:shadow-xl transition-all group"
              >
                <div>
                  <div className="relative overflow-hidden rounded-xl bg-slate-100 mb-3 aspect-square cursor-pointer"
                    onClick={() => onSelectProduct(product)}
                  >
                    <img
                      src={product.image}
                      alt={product.nameBn}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-2 left-2 bg-rose-600 text-white text-xs font-black px-2.5 py-1 rounded-full shadow-sm">
                      {discountPercent}% ছাড়
                    </div>
                    {product.stock <= 5 && (
                      <div className="absolute top-2 right-2 bg-amber-500 text-slate-950 text-[10px] font-bold px-2 py-0.5 rounded-md">
                        মজুত শেষ পর্যায়ে!
                      </div>
                    )}
                  </div>

                  <span className="text-[11px] font-semibold text-emerald-700 uppercase tracking-wider block mb-1">
                    {product.categoryBn}
                  </span>
                  <h3
                    onClick={() => onSelectProduct(product)}
                    className="font-bold text-slate-900 text-sm sm:text-base line-clamp-2 hover:text-emerald-700 cursor-pointer"
                  >
                    {product.nameBn}
                  </h3>

                  {/* Pricing */}
                  <div className="mt-2 flex items-baseline gap-2">
                    <span className="text-xl font-extrabold text-slate-900">
                      ৳{product.discountPrice.toLocaleString()}
                    </span>
                    <span className="text-xs text-slate-400 line-through">
                      ৳{product.regularPrice.toLocaleString()}
                    </span>
                  </div>

                  {/* Stock progress bar simulation */}
                  <div className="mt-3">
                    <div className="flex justify-between text-[11px] text-slate-500 mb-1">
                      <span>বিক্রি হয়েছে: ৭২%</span>
                      <span className="font-semibold text-rose-600">স্টক আছে: {product.stock} টি</span>
                    </div>
                    <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                      <div className="bg-rose-500 h-2 rounded-full w-[72%]" />
                    </div>
                  </div>
                </div>

                {/* Buttons */}
                <div className="mt-4 pt-3 border-t border-slate-100 grid grid-cols-2 gap-2">
                  <button
                    onClick={() => onAddToCart(product)}
                    className="py-2 px-2.5 rounded-xl border border-emerald-600 text-emerald-700 hover:bg-emerald-50 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <ShoppingCart className="w-3.5 h-3.5" />
                    <span>কার্ট</span>
                  </button>

                  <button
                    onClick={() => onBuyNow(product)}
                    className="py-2 px-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-colors shadow-sm cursor-pointer"
                  >
                    <span>অর্ডার করুন</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
