import React, { useState } from 'react';
import { 
  X, 
  Search, 
  Truck, 
  CheckCircle, 
  Clock, 
  Package, 
  CheckCheck, 
  AlertOctagon, 
  Phone, 
  MapPin, 
  MessageCircle,
  Calendar
} from 'lucide-react';
import { Order, OrderStatus, WebsiteSettings } from '../types';
import { getWhatsAppUrl } from '../utils';

interface OrderTrackingModalProps {
  isOpen: boolean;
  onClose: () => void;
  orders: Order[];
  initialOrderId?: string;
  settings: WebsiteSettings;
}

export const OrderTrackingModal: React.FC<OrderTrackingModalProps> = ({
  isOpen,
  onClose,
  orders,
  initialOrderId = '',
  settings
}) => {
  const [searchInput, setSearchInput] = useState(initialOrderId);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(
    initialOrderId ? orders.find(o => o.id.toLowerCase() === initialOrderId.toLowerCase()) || null : null
  );
  const [hasSearched, setHasSearched] = useState(!!initialOrderId);

  if (!isOpen) return null;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const query = searchInput.trim().toLowerCase();
    if (!query) return;

    setHasSearched(true);
    const found = orders.find(
      (o) => o.id.toLowerCase() === query || o.phoneNumber.includes(query)
    );
    setSelectedOrder(found || null);
  };

  const getStatusStepIndex = (status: OrderStatus) => {
    switch (status) {
      case 'pending': return 0;
      case 'confirmed': return 1;
      case 'processing': return 2;
      case 'shipped': return 3;
      case 'delivered': return 4;
      case 'cancelled': return -1;
      default: return 0;
    }
  };

  const steps = [
    { labelBn: 'অর্ডার জমা হয়েছে', desc: 'অপেক্ষমাণ (Pending)' },
    { labelBn: 'অর্ডার নিশ্চিত', desc: 'কনফার্মড (Confirmed)' },
    { labelBn: 'প্যাকেজিং প্রস্তুত', desc: 'প্রসেসিং (Processing)' },
    { labelBn: 'কুরিয়ারে পাঠানো হয়েছে', desc: 'শিপড (Shipped)' },
    { labelBn: 'ডেলিভারি সম্পন্ন', desc: 'ডেলিভার্ড (Delivered)' }
  ];

  const currentStep = selectedOrder ? getStatusStepIndex(selectedOrder.status) : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm overflow-y-auto animate-fade-in">
      <div className="bg-white rounded-3xl max-w-xl w-full p-5 sm:p-6 shadow-2xl relative border border-slate-200 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-slate-900 tracking-tight">
                লাইভ অর্ডার ট্র্যাকিং (Track Order)
              </h2>
              <p className="text-xs text-slate-500">আপনার অর্ডারের সর্বশেষ অবস্থা ও তথ্য দেখুন</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-600 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Bar */}
        <form onSubmit={handleSearch} className="my-4 flex gap-2">
          <div className="relative flex-1">
            <input
              type="text"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="অর্ডার আইডি (e.g. TB-98241) বা ফোন নম্বর লিখুন..."
              className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-300 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          </div>
          <button
            type="submit"
            className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2.5 rounded-2xl text-xs font-bold transition-colors shrink-0 cursor-pointer"
          >
            খুঁজুন
          </button>
        </form>

        {/* Search Results */}
        <div className="overflow-y-auto flex-1 space-y-4">
          {selectedOrder ? (
            <div className="space-y-4">
              {/* Order Basic Meta Card */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[11px] text-slate-500">অর্ডার আইডি:</span>
                    <h3 className="font-mono font-black text-base text-emerald-800">{selectedOrder.id}</h3>
                  </div>
                  <div className="text-right">
                    <span className="text-[11px] text-slate-500">অর্ডারের তারিখ:</span>
                    <p className="text-xs font-semibold text-slate-700">{selectedOrder.date}</p>
                  </div>
                </div>

                {/* Status Pill */}
                <div className="pt-2 border-t border-slate-200 flex items-center justify-between">
                  <span className="text-xs text-slate-600">বর্তমান স্ট্যাটাস:</span>
                  <span className={`text-xs font-bold px-3 py-1 rounded-full uppercase ${
                    selectedOrder.status === 'delivered'
                      ? 'bg-emerald-100 text-emerald-800'
                      : selectedOrder.status === 'cancelled'
                      ? 'bg-rose-100 text-rose-800'
                      : selectedOrder.status === 'shipped'
                      ? 'bg-indigo-100 text-indigo-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}>
                    {selectedOrder.status}
                  </span>
                </div>
              </div>

              {/* Visual Tracking Stepper */}
              {selectedOrder.status !== 'cancelled' ? (
                <div className="bg-white p-4 rounded-2xl border border-slate-200">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">
                    ডেলিভারি অগ্রগতি (Delivery Progress)
                  </h4>

                  <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
                    {steps.map((st, idx) => {
                      const isCompleted = currentStep >= idx;
                      const isCurrent = currentStep === idx;

                      return (
                        <div key={idx} className="relative">
                          {/* Indicator Dot */}
                          <div
                            className={`absolute -left-6 top-0 w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold border-2 transition-all ${
                              isCompleted
                                ? 'bg-emerald-600 border-emerald-600 text-white'
                                : 'bg-white border-slate-300 text-slate-400'
                            }`}
                          >
                            {isCompleted ? <CheckCheck className="w-3 h-3" /> : idx + 1}
                          </div>

                          <div className="text-left">
                            <p className={`text-xs font-bold ${isCurrent ? 'text-emerald-700' : isCompleted ? 'text-slate-800' : 'text-slate-400'}`}>
                              {st.labelBn}
                            </p>
                            <p className="text-[11px] text-slate-400">{st.desc}</p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ) : (
                <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl text-center space-y-1">
                  <AlertOctagon className="w-8 h-8 text-rose-600 mx-auto" />
                  <h4 className="font-bold text-rose-800 text-sm">অর্ডারটি বাতিল করা হয়েছে</h4>
                  <p className="text-xs text-rose-600">যেকোনো তথ্যের জন্য আমাদের কাস্টমার সাপোর্টে কল করুন।</p>
                </div>
              )}

              {/* Items & Financials */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2 text-xs">
                <h4 className="font-bold text-slate-800 text-xs uppercase tracking-wider mb-2">
                  অর্ডারের পণ্যসমূহ ({selectedOrder.items.length})
                </h4>
                {selectedOrder.items.map((item, i) => (
                  <div key={i} className="flex justify-between items-center text-slate-700">
                    <span className="truncate max-w-[260px]">{item.productName} × {item.quantity}</span>
                    <span className="font-bold">৳{item.total.toLocaleString()}</span>
                  </div>
                ))}
                <div className="pt-2 border-t border-slate-200 flex justify-between font-bold text-slate-900 text-sm">
                  <span>সর্বমোট বিল:</span>
                  <span className="text-emerald-700">৳{selectedOrder.grandTotal.toLocaleString()}</span>
                </div>
              </div>

              {/* Support Contact Button */}
              <div className="pt-2">
                <a
                  href={getWhatsAppUrl(settings.whatsappNumber, `আসসালামু আলাইকুম, আমি আমার অর্ডার (${selectedOrder.id}) সম্পর্কে জানতে চাই।`)}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full bg-[#25D366] hover:bg-[#20ba59] text-white font-bold py-2.5 px-4 rounded-2xl flex items-center justify-center gap-2 text-xs transition-colors"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>অর্ডার নিয়ে হোয়াটসঅ্যাপে কথা বলুন</span>
                </a>
              </div>
            </div>
          ) : hasSearched ? (
            <div className="text-center py-8 space-y-2">
              <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 mx-auto">
                <Package className="w-6 h-6" />
              </div>
              <p className="text-sm font-bold text-slate-800">কোনো অর্ডার পাওয়া যায়নি</p>
              <p className="text-xs text-slate-500 max-w-xs mx-auto">
                দয়া করে সঠিক অর্ডার নম্বর (যেমন: TB-98241) অথবা অর্ডার দেওয়ার মোবাইল নম্বরটি দিয়ে পুনরায় চেষ্টা করুন।
              </p>
            </div>
          ) : (
            <div className="text-center py-8 text-xs text-slate-400">
              উপরে আপনার অর্ডার নম্বর অথবা ফোন নম্বর দিয়ে সার্চ বাটনে ক্লিক করুন।
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
