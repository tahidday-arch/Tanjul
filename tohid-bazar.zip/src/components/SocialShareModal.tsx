import React, { useState } from 'react';
import { X, Check, Copy, Share2, Facebook, MessageCircle, Youtube, Twitter } from 'lucide-react';

interface SocialShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  url?: string;
  description?: string;
}

export const SocialShareModal: React.FC<SocialShareModalProps> = ({
  isOpen,
  onClose,
  title,
  url = window.location.href,
  description = 'তৌহিদ বাজারে অসাধারণ অফার চলছে! এখনই ভিজিট করুন।'
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const currentUrl = url || window.location.href;
  const encodedUrl = encodeURIComponent(currentUrl);
  const encodedText = encodeURIComponent(`${title} — ${description}`);

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(currentUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // fallback
    }
  };

  const handleFacebookShare = () => {
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`, '_blank');
  };

  const handleWhatsAppShare = () => {
    window.open(`https://api.whatsapp.com/send?text=${encodedText}%20${encodedUrl}`, '_blank');
  };

  const handleTwitterShare = () => {
    window.open(`https://twitter.com/intent/tweet?text=${encodedText}&url=${encodedUrl}`, '_blank');
  };

  const handleYouTubeVisit = () => {
    window.open(`https://www.youtube.com`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl relative border border-slate-100">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
            <Share2 className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-900">শেয়ার করুন (Share Post / Product)</h3>
            <p className="text-xs text-slate-500">ফেসবুক, হোয়াটসঅ্যাপ বা অন্যান্য মাধ্যমে বন্ধুদের সাথে শেয়ার করুন</p>
          </div>
        </div>

        {/* Item Title Preview */}
        <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-100 mb-5">
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">শেয়ার করার বিষয়বস্তু:</p>
          <p className="text-sm font-bold text-slate-800 line-clamp-2">{title}</p>
        </div>

        {/* Social Buttons Grid */}
        <div className="grid grid-cols-2 gap-3 mb-5">
          <button
            onClick={handleFacebookShare}
            className="flex items-center justify-center gap-2 py-3 px-4 rounded-2xl bg-[#1877F2] hover:bg-[#166fe5] text-white font-semibold text-sm transition-all shadow-sm hover:shadow"
          >
            <Facebook className="w-4 h-4" />
            <span>ফেসবুক (Facebook)</span>
          </button>

          <button
            onClick={handleWhatsAppShare}
            className="flex items-center justify-center gap-2 py-3 px-4 rounded-2xl bg-[#25D366] hover:bg-[#20ba59] text-white font-semibold text-sm transition-all shadow-sm hover:shadow"
          >
            <MessageCircle className="w-4 h-4" />
            <span>হোয়াটসঅ্যাপ (WhatsApp)</span>
          </button>

          <button
            onClick={handleYouTubeVisit}
            className="flex items-center justify-center gap-2 py-3 px-4 rounded-2xl bg-[#FF0000] hover:bg-[#e60000] text-white font-semibold text-sm transition-all shadow-sm hover:shadow"
          >
            <Youtube className="w-4 h-4" />
            <span>ইউটিউব চ্যানেল</span>
          </button>

          <button
            onClick={handleTwitterShare}
            className="flex items-center justify-center gap-2 py-3 px-4 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-sm transition-all shadow-sm hover:shadow"
          >
            <Twitter className="w-4 h-4" />
            <span>Twitter / X</span>
          </button>
        </div>

        {/* Copy Link Input */}
        <div className="relative">
          <input
            type="text"
            readOnly
            value={currentUrl}
            className="w-full bg-slate-100 border border-slate-200 rounded-xl py-2.5 pl-3 pr-24 text-xs font-mono text-slate-600 focus:outline-none"
          />
          <button
            onClick={handleCopyLink}
            className="absolute right-1.5 top-1.5 bottom-1.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold flex items-center gap-1 transition-colors"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-white" />
                <span>কপি হয়েছে</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>লিংক কপি</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
