import React, { useState } from 'react';
import { 
  X, 
  Star, 
  ShoppingCart, 
  Truck, 
  ShieldCheck, 
  RotateCcw, 
  Share2, 
  Plus, 
  Minus, 
  Video, 
  Check, 
  MessageSquare,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { Product, ProductReview } from '../types';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, quantity: number) => void;
  onBuyNow: (product: Product, quantity: number) => void;
  onShare: (product: Product) => void;
  relatedProducts: Product[];
  onSelectRelated: (product: Product) => void;
  onAddReview: (productId: string, review: Omit<ProductReview, 'id' | 'date'>) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onAddToCart,
  onBuyNow,
  onShare,
  relatedProducts,
  onSelectRelated,
  onAddReview
}) => {
  const [selectedImage, setSelectedImage] = useState<string>('');
  const [quantity, setQuantity] = useState(1);
  const [showVideo, setShowVideo] = useState(false);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [reviewName, setReviewName] = useState('');
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [reviewSubmitted, setReviewSubmitted] = useState(false);

  if (!product) return null;

  const currentImage = selectedImage || product.image;
  const discountPercent = product.regularPrice > product.discountPrice
    ? Math.round(((product.regularPrice - product.discountPrice) / product.regularPrice) * 100)
    : 0;

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewName.trim() || !reviewComment.trim()) return;

    onAddReview(product.id, {
      userName: reviewName.trim(),
      rating: reviewRating,
      comment: reviewComment.trim()
    });

    setReviewSubmitted(true);
    setTimeout(() => {
      setReviewSubmitted(false);
      setShowReviewForm(false);
      setReviewName('');
      setReviewComment('');
    }, 2000);
  };

  // Convert youtube watch URL to embed URL if needed
  const getEmbedVideoUrl = (url: string) => {
    if (!url) return '';
    if (url.includes('youtube.com/watch?v=')) {
      return url.replace('watch?v=', 'embed/');
    }
    if (url.includes('youtu.be/')) {
      return url.replace('youtu.be/', 'youtube.com/embed/');
    }
    return url;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-4xl w-full my-8 shadow-2xl overflow-hidden border border-slate-200 relative animate-fade-in max-h-[90vh] flex flex-col">
        {/* Sticky Header with Close & Share */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50 shrink-0">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-500">
            <span>{product.brand}</span>
            <span>·</span>
            <span className="text-emerald-700">{product.categoryBn}</span>
            <span>·</span>
            <span className="font-mono text-slate-400">SKU: {product.sku}</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onShare(product)}
              className="p-2 rounded-full hover:bg-slate-200 text-slate-600 transition-colors flex items-center gap-1.5 text-xs font-bold px-3 bg-white border border-slate-200"
              title="শেয়ার করুন"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>শেয়ার</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-full hover:bg-slate-200 text-slate-500 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
            {/* Left: Gallery & Video */}
            <div>
              <div className="relative aspect-square rounded-2xl overflow-hidden bg-slate-100 border border-slate-200 mb-3 shadow-inner">
                {showVideo && product.videoUrl ? (
                  <iframe
                    src={getEmbedVideoUrl(product.videoUrl)}
                    title={product.nameBn}
                    className="w-full h-full"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  />
                ) : (
                  <img
                    src={currentImage}
                    alt={product.nameBn}
                    className="w-full h-full object-cover"
                  />
                )}

                {discountPercent > 0 && (
                  <span className="absolute top-3 left-3 bg-rose-600 text-white font-black text-xs px-2.5 py-1 rounded-full shadow-md">
                    {discountPercent}% ছাড়
                  </span>
                )}

                {product.videoUrl && (
                  <button
                    onClick={() => setShowVideo(!showVideo)}
                    className="absolute bottom-3 right-3 bg-slate-900/80 hover:bg-slate-900 text-white text-xs font-bold px-3 py-1.5 rounded-full flex items-center gap-1.5 backdrop-blur-sm transition-all"
                  >
                    <Video className="w-4 h-4 text-rose-400" />
                    <span>{showVideo ? 'ছবি দেখুন' : 'ভিডিও দেখুন'}</span>
                  </button>
                )}
              </div>

              {/* Thumbnails */}
              {product.images && product.images.length > 1 && (
                <div className="flex items-center gap-2 overflow-x-auto pb-2">
                  {product.images.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => {
                        setSelectedImage(img);
                        setShowVideo(false);
                      }}
                      className={`w-16 h-16 rounded-xl overflow-hidden border-2 shrink-0 transition-all ${
                        currentImage === img && !showVideo
                          ? 'border-emerald-600 ring-2 ring-emerald-600/30'
                          : 'border-slate-200 opacity-70 hover:opacity-100'
                      }`}
                    >
                      <img src={img} alt="" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}

              {/* Trust Badges */}
              <div className="mt-4 grid grid-cols-3 gap-2 bg-slate-50 p-3 rounded-2xl border border-slate-100 text-center">
                <div className="flex flex-col items-center">
                  <ShieldCheck className="w-5 h-5 text-emerald-600 mb-1" />
                  <span className="text-[11px] font-bold text-slate-800">১০০% আসল পণ্য</span>
                </div>
                <div className="flex flex-col items-center">
                  <Truck className="w-5 h-5 text-indigo-600 mb-1" />
                  <span className="text-[11px] font-bold text-slate-800">সারা দেশে ডেলিভারি</span>
                </div>
                <div className="flex flex-col items-center">
                  <RotateCcw className="w-5 h-5 text-amber-600 mb-1" />
                  <span className="text-[11px] font-bold text-slate-800">৭ দিনের রিটার্ন</span>
                </div>
              </div>
            </div>

            {/* Right: Product Meta, Details & Controls */}
            <div className="flex flex-col justify-between">
              <div>
                <h1 className="text-xl sm:text-2xl font-black text-slate-900 leading-tight">
                  {product.nameBn}
                </h1>
                <p className="text-xs text-slate-400 mt-1">{product.name}</p>

                {/* Rating & Stock */}
                <div className="mt-3 flex items-center gap-4 text-sm">
                  <div className="flex items-center gap-1">
                    <div className="flex text-amber-400">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < Math.floor(product.rating) ? 'fill-amber-400 text-amber-400' : 'text-slate-300'
                          }`}
                        />
                      ))}
                    </div>
                    <span className="font-bold text-slate-800 ml-1">{product.rating}</span>
                    <span className="text-slate-400 text-xs">({product.reviewCount} টি রিভিউ)</span>
                  </div>

                  <span className="text-slate-300">|</span>

                  <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                    product.stock > 5 
                      ? 'bg-emerald-100 text-emerald-800' 
                      : product.stock > 0 
                      ? 'bg-amber-100 text-amber-800' 
                      : 'bg-rose-100 text-rose-800'
                  }`}>
                    {product.stock > 0 ? `ইন স্টক (${product.stock} টি)` : 'স্টক আউট'}
                  </span>
                </div>

                {/* Price Box */}
                <div className="mt-4 p-4 rounded-2xl bg-emerald-50/70 border border-emerald-100 flex items-baseline gap-3">
                  <span className="text-2xl sm:text-3xl font-black text-emerald-800">
                    ৳{product.discountPrice.toLocaleString()}
                  </span>
                  {product.regularPrice > product.discountPrice && (
                    <span className="text-base text-slate-400 line-through">
                      ৳{product.regularPrice.toLocaleString()}
                    </span>
                  )}
                  {discountPercent > 0 && (
                    <span className="text-xs font-black text-rose-600 bg-rose-100 px-2 py-0.5 rounded-full ml-auto">
                      সাশ্রয় ৳{(product.regularPrice - product.discountPrice).toLocaleString()}
                    </span>
                  )}
                </div>

                {/* Description */}
                <div className="mt-4">
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                    পণ্যের বিবরণ (Description)
                  </h3>
                  <p className="text-sm text-slate-700 leading-relaxed font-normal">
                    {product.descriptionBn}
                  </p>
                </div>

                {/* Quantity Selector */}
                <div className="mt-6 flex items-center gap-4">
                  <span className="text-xs font-bold text-slate-700 uppercase">পরিমাণ:</span>
                  <div className="flex items-center border border-slate-300 rounded-xl overflow-hidden bg-white">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="p-2 hover:bg-slate-100 text-slate-600 transition-colors"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="px-4 py-1 text-sm font-bold text-slate-800">
                      {quantity}
                    </span>
                    <button
                      onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                      className="p-2 hover:bg-slate-100 text-slate-600 transition-colors"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                  <span className="text-xs text-slate-500 font-medium">
                    মোট: <span className="font-bold text-emerald-700">৳{(product.discountPrice * quantity).toLocaleString()}</span>
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-6 pt-4 border-t border-slate-100 grid grid-cols-2 gap-3">
                <button
                  disabled={product.stock <= 0}
                  onClick={() => {
                    onAddToCart(product, quantity);
                    onClose();
                  }}
                  className="py-3 px-4 rounded-2xl border-2 border-emerald-600 text-emerald-700 hover:bg-emerald-50 font-bold text-sm flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <ShoppingCart className="w-4 h-4" />
                  <span>কার্টে যোগ করুন</span>
                </button>

                <button
                  disabled={product.stock <= 0}
                  onClick={() => {
                    onBuyNow(product, quantity);
                    onClose();
                  }}
                  className="py-3 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 transition-all cursor-pointer"
                >
                  <span>এখনই কিনুন (Buy Now)</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Customer Reviews Section */}
          <div className="pt-6 border-t border-slate-200">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-lg font-bold text-slate-900">
                  গ্রাহক রিভিউ ও মতামত ({product.reviews?.length || 0})
                </h3>
                <p className="text-xs text-slate-500">ক্রেতাদের বাস্তব অভিজ্ঞতা ও রেটিং</p>
              </div>

              <button
                onClick={() => setShowReviewForm(!showReviewForm)}
                className="text-xs font-bold text-emerald-700 hover:text-emerald-800 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200 flex items-center gap-1 cursor-pointer"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>{showReviewForm ? 'বন্ধ করুন' : 'রিভিউ দিন'}</span>
              </button>
            </div>

            {/* Review Form */}
            {showReviewForm && (
              <form onSubmit={handleReviewSubmit} className="bg-slate-50 p-4 rounded-2xl border border-slate-200 mb-4 space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">আপনার নাম</label>
                    <input
                      type="text"
                      required
                      value={reviewName}
                      onChange={(e) => setReviewName(e.target.value)}
                      placeholder="e.g. রাশেদ করিম"
                      className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">রেটিং (স্টার)</label>
                    <div className="flex items-center gap-1 mt-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setReviewRating(star)}
                          className="p-1 text-amber-400 hover:scale-110 transition-transform"
                        >
                          <Star className={`w-5 h-5 ${star <= reviewRating ? 'fill-amber-400' : 'text-slate-300'}`} />
                        </button>
                      ))}
                      <span className="text-xs font-bold text-slate-700 ml-2">{reviewRating} স্টার</span>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">আপনার মতামত বা মন্তব্য</label>
                  <textarea
                    required
                    rows={2}
                    value={reviewComment}
                    onChange={(e) => setReviewComment(e.target.value)}
                    placeholder="পণ্যটির গুণগত মান সম্পর্কে আপনার অভিজ্ঞতা লিখুন..."
                    className="w-full bg-white border border-slate-300 rounded-xl p-3 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-4 py-2 rounded-xl transition-colors cursor-pointer"
                  >
                    {reviewSubmitted ? 'রিভিউ জমা হয়েছে!' : 'রিভিউ সাবমিট করুন'}
                  </button>
                </div>
              </form>
            )}

            {/* Existing Reviews List */}
            {product.reviews && product.reviews.length > 0 ? (
              <div className="space-y-3">
                {product.reviews.map((rev) => (
                  <div key={rev.id} className="bg-slate-50 p-3.5 rounded-2xl border border-slate-100">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-bold text-slate-800">{rev.userName}</span>
                      <span className="text-[11px] text-slate-400">{rev.date}</span>
                    </div>
                    <div className="flex text-amber-400 mb-1.5">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-3 h-3 ${i < rev.rating ? 'fill-amber-400' : 'text-slate-200'}`}
                        />
                      ))}
                    </div>
                    <p className="text-xs text-slate-600">{rev.comment}</p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-400 text-center py-3">
                এখনও কোনো রিভিউ দেওয়া হয়নি। প্রথম রিভিউ দিন!
              </p>
            )}
          </div>

          {/* Related Products */}
          {relatedProducts.length > 0 && (
            <div className="pt-6 border-t border-slate-200">
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-3">
                একই ধরনের পণ্য (Related Products)
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {relatedProducts.slice(0, 4).map((rel) => (
                  <div
                    key={rel.id}
                    onClick={() => {
                      onSelectRelated(rel);
                      setSelectedImage('');
                      setShowVideo(false);
                    }}
                    className="p-2 bg-slate-50 hover:bg-emerald-50 rounded-2xl border border-slate-200 hover:border-emerald-300 transition-all cursor-pointer group"
                  >
                    <div className="aspect-square rounded-xl overflow-hidden bg-white mb-2">
                      <img src={rel.image} alt={rel.nameBn} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                    </div>
                    <p className="text-xs font-bold text-slate-800 truncate">{rel.nameBn}</p>
                    <span className="text-xs font-black text-emerald-700">৳{rel.discountPrice}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
