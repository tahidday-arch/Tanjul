import React from 'react';
import { Advertisement } from '../types';
import { ExternalLink, Sparkles } from 'lucide-react';

interface AdvertisementBannerProps {
  ad: Advertisement | undefined;
  placementLabel?: string;
}

export const AdvertisementBanner: React.FC<AdvertisementBannerProps> = ({
  ad,
  placementLabel
}) => {
  if (!ad || !ad.isEnabled) return null;

  return (
    <div className="my-6 max-w-7xl mx-auto px-4">
      <div className="relative rounded-2xl md:rounded-3xl overflow-hidden border border-slate-200 shadow-sm bg-gradient-to-r from-slate-900 to-slate-800 text-white">
        {/* Sponsored Label */}
        <div className="absolute top-2 right-2 z-10 bg-black/60 backdrop-blur-xs px-2 py-0.5 rounded text-[10px] font-semibold text-amber-300 uppercase tracking-wider flex items-center gap-1">
          <Sparkles className="w-2.5 h-2.5" />
          <span>Sponsored Ad ({ad.type === 'adsense' ? 'Google AdSense' : ad.type === 'adsterra' ? 'Adsterra Partner' : 'বিজ্ঞাপন'})</span>
        </div>

        {ad.type === 'image' && ad.imageUrl && (
          <a
            href={ad.targetUrl || '#'}
            target={ad.targetUrl?.startsWith('http') ? '_blank' : '_self'}
            rel="noreferrer"
            className="block relative group overflow-hidden"
          >
            <img
              src={ad.imageUrl}
              alt={ad.title}
              className="w-full h-28 sm:h-36 md:h-44 object-cover group-hover:scale-102 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/30 to-transparent flex items-center p-6">
              <div className="max-w-md">
                <span className="text-xs font-bold text-amber-400 block mb-1">তৌহিদ বাজার বিশেষ প্রচার</span>
                <h3 className="text-base sm:text-xl font-black text-white">{ad.title}</h3>
                <span className="mt-2 inline-flex items-center gap-1 text-xs font-bold text-emerald-400 hover:text-emerald-300">
                  <span>বিস্তারিত দেখুন</span>
                  <ExternalLink className="w-3 h-3" />
                </span>
              </div>
            </div>
          </a>
        )}

        {(ad.type === 'adsense' || ad.type === 'adsterra') && ad.adCode && (
          <div
            className="p-6 text-center"
            dangerouslySetInnerHTML={{ __html: ad.adCode }}
          />
        )}
      </div>
    </div>
  );
};
