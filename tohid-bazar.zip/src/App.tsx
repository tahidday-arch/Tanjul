import React, { useState, useEffect, useMemo } from 'react';
import { 
  storageService 
} from './services/storage';
import { 
  Product, 
  Order, 
  Advertisement, 
  Coupon, 
  SocialPost, 
  WebsiteSettings, 
  CartItem, 
  OrderStatus 
} from './types';

// Components
import { Header } from './components/Header';
import { HeroSlider } from './components/HeroSlider';
import { CategoryList } from './components/CategoryList';
import { FlashSale } from './components/FlashSale';
import { ProductCard } from './components/ProductCard';
import { ProductDetailModal } from './components/ProductDetailModal';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { OrderSuccessModal } from './components/OrderSuccessModal';
import { OrderTrackingModal } from './components/OrderTrackingModal';
import { AdminPanel } from './components/AdminPanel';
import { SocialShareModal } from './components/SocialShareModal';
import { PostsSection } from './components/PostsSection';
import { AdvertisementBanner } from './components/AdvertisementBanner';
import { Footer } from './components/Footer';
import { SmartphoneFrame } from './components/SmartphoneFrame';
import { MobileStoryCategories } from './components/MobileStoryCategories';
import { MobileBottomNav } from './components/MobileBottomNav';
import { MobileCategoryDrawer } from './components/MobileCategoryDrawer';
import { MobileMenuSheet } from './components/MobileMenuSheet';
import { MobileAppInstallBanner } from './components/MobileAppInstallBanner';
import { usePWAInstall } from './hooks/usePWAInstall';
import { getWhatsAppUrl } from './utils';

// Icons
import { 
  MessageCircle, 
  SlidersHorizontal, 
  ArrowUpDown, 
  Sparkles, 
  PackageSearch, 
  Check,
  PhoneCall,
  ShoppingBag
} from 'lucide-react';

export default function App() {
  // Core application state from localStorage
  const [products, setProducts] = useState<Product[]>(() => storageService.getProducts());
  const [orders, setOrders] = useState<Order[]>(() => storageService.getOrders());
  const [cart, setCart] = useState<CartItem[]>(() => storageService.getCart());
  const [wishlist, setWishlist] = useState<string[]>(() => storageService.getWishlist());
  const [ads, setAds] = useState<Advertisement[]>(() => storageService.getAdvertisements());
  const [coupons, setCoupons] = useState<Coupon[]>(() => storageService.getCoupons());
  const [posts, setPosts] = useState<SocialPost[]>(() => storageService.getPosts());
  const [settings, setSettings] = useState<WebsiteSettings>(() => storageService.getSettings());

  // UI & Shopping state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [sortBy, setSortBy] = useState<'featured' | 'price_asc' | 'price_desc' | 'rating' | 'newest'>('featured');
  const [deliveryArea, setDeliveryArea] = useState<'inside_dhaka' | 'outside_dhaka'>('inside_dhaka');
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);

  // Modals visibility
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isTrackingOpen, setIsTrackingOpen] = useState(false);
  const [trackingInitialId, setTrackingInitialId] = useState('');
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [successOrder, setSuccessOrder] = useState<Order | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Mobile App View and Navigation Drawer states
  const [isAppViewMode, setIsAppViewMode] = useState<boolean>(() => {
    return localStorage.getItem('tohid_bazar_app_mode') === 'true';
  });
  const [isCategoryDrawerOpen, setIsCategoryDrawerOpen] = useState(false);
  const [isMenuSheetOpen, setIsMenuSheetOpen] = useState(false);
  const [activeMobileTab, setActiveMobileTab] = useState<'home' | 'categories' | 'offers' | 'cart' | 'menu'>('home');
  const { isInstallable, install } = usePWAInstall();

  const handleToggleAppViewMode = (enabled: boolean) => {
    setIsAppViewMode(enabled);
    localStorage.setItem('tohid_bazar_app_mode', enabled ? 'true' : 'false');
  };

  // Social Share modal
  const [shareData, setShareData] = useState<{
    isOpen: boolean;
    title: string;
    text?: string;
    url: string;
    image?: string;
  }>({
    isOpen: false,
    title: '',
    url: ''
  });

  // Sync to storage
  useEffect(() => {
    storageService.saveProducts(products);
  }, [products]);

  useEffect(() => {
    storageService.saveOrders(orders);
  }, [orders]);

  useEffect(() => {
    storageService.saveCart(cart);
  }, [cart]);

  useEffect(() => {
    storageService.saveWishlist(wishlist);
  }, [wishlist]);

  useEffect(() => {
    storageService.saveAdvertisements(ads);
  }, [ads]);

  useEffect(() => {
    storageService.saveCoupons(coupons);
  }, [coupons]);

  useEffect(() => {
    storageService.savePosts(posts);
  }, [posts]);

  useEffect(() => {
    storageService.saveSettings(settings);
  }, [settings]);

  // Toast notification helper
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 2500);
  };

  // Cart operations
  const handleAddToCart = (product: Product, quantity: number = 1) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity }];
    });
    showToast(`"${product.nameBn}" কার্টে যুক্ত হয়েছে!`);
  };

  const handleUpdateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) =>
        item.product.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const handleRemoveFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
    showToast('পণ্যটি কার্ট থেকে সরানো হয়েছে');
  };

  const handleQuickBuy = (product: Product) => {
    // Add to cart if not already present, then trigger checkout directly
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) return prev;
      return [...prev, { product, quantity: 1 }];
    });
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  // Wishlist toggle
  const handleToggleWishlist = (productId: string) => {
    setWishlist((prev) => {
      const isFavorited = prev.includes(productId);
      if (isFavorited) {
        showToast('উইশলিস্ট থেকে সরানো হয়েছে');
        return prev.filter((id) => id !== productId);
      } else {
        showToast('উইশলিস্টে যুক্ত হয়েছে ❤️');
        return [...prev, productId];
      }
    });
  };

  // Coupon application
  const handleApplyCoupon = (code: string) => {
    const cleanCode = code.trim().toUpperCase();
    const found = coupons.find(
      (c) => c.code.toUpperCase() === cleanCode && c.isActive
    );

    if (!found) {
      return { success: false, message: 'অকার্যকর বা মেয়াদোত্তীর্ণ কুপন কোড।' };
    }

    const subtotal = cart.reduce(
      (acc, item) => acc + item.product.discountPrice * item.quantity,
      0
    );

    if (subtotal < found.minOrderAmount) {
      return {
        success: false,
        message: `এই কুপন ব্যবহারের জন্য সর্বনিম্ন ৳${found.minOrderAmount} টাকার অর্ডার প্রয়োজন।`
      };
    }

    setAppliedCoupon(found);
    return { success: true, message: `কুপন "${found.code}" সফলভাবে যুক্ত হয়েছে!` };
  };

  const handleRemoveCoupon = () => {
    setAppliedCoupon(null);
    showToast('কুপন বাতিল করা হয়েছে');
  };

  // Submit Order from Checkout Modal
  const handleSubmitOrder = (
    orderData: Omit<Order, 'id' | 'date' | 'status' | 'trackingTimeline'>
  ) => {
    const newOrderId = `TB-${Math.floor(10000 + Math.random() * 90000)}`;
    const now = new Date();
    const formattedDate = now.toLocaleDateString('bn-BD', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });

    const fullOrder: Order = {
      ...orderData,
      id: newOrderId,
      date: formattedDate,
      status: 'pending',
      trackingTimeline: [
        {
          status: 'pending',
          time: now.toLocaleTimeString('bn-BD', { hour12: true }),
          description: 'অর্ডারটি তৌহিদ বাজার সিস্টেমে জমা হয়েছে।'
        }
      ]
    };

    // Update state & persist
    const updatedOrders = [fullOrder, ...orders];
    setOrders(updatedOrders);
    storageService.saveOrders(updatedOrders);

    // Clear cart and close checkout
    setCart([]);
    setAppliedCoupon(null);
    setIsCheckoutOpen(false);

    // Show celebratory order success modal
    setSuccessOrder(fullOrder);
  };

  // Admin order status update
  const handleUpdateOrderStatus = (orderId: string, status: OrderStatus, note?: string) => {
    const updated = storageService.updateOrderStatus(orderId, status, note);
    setOrders(updated);
    showToast(`অর্ডার #${orderId} এর স্ট্যাটাস "${status}" এ পরিবর্তন হয়েছে`);
  };

  // Product Admin Operations
  const handleAddProduct = (newProduct: Product) => {
    const updated = [newProduct, ...products];
    setProducts(updated);
    showToast(`নতুন পণ্য "${newProduct.nameBn}" যোগ করা হয়েছে!`);
  };

  const handleUpdateProduct = (updatedProduct: Product) => {
    const updated = products.map((p) =>
      p.id === updatedProduct.id ? updatedProduct : p
    );
    setProducts(updated);
    showToast(`"${updatedProduct.nameBn}" আপডেট করা হয়েছে!`);
  };

  const handleDeleteProduct = (productId: string) => {
    const updated = products.filter((p) => p.id !== productId);
    setProducts(updated);
    showToast('পণ্যটি সফলভাবে মুছে ফেলা হয়েছে');
  };

  // Advertisement Admin Operations
  const handleToggleAd = (adId: string) => {
    const updated = ads.map((a) =>
      a.id === adId ? { ...a, isEnabled: !a.isEnabled } : a
    );
    setAds(updated);
  };

  const handleAddAd = (newAd: Advertisement) => {
    const updated = [newAd, ...ads];
    setAds(updated);
    showToast('বিজ্ঞাপন সফলভাবে যোগ হয়েছে');
  };

  const handleDeleteAd = (adId: string) => {
    const updated = ads.filter((a) => a.id !== adId);
    setAds(updated);
    showToast('বিজ্ঞাপন মুছে ফেলা হয়েছে');
  };

  // Coupon Admin Operations
  const handleAddCoupon = (newCoupon: Coupon) => {
    const updated = [newCoupon, ...coupons];
    setCoupons(updated);
    showToast(`কুপন "${newCoupon.code}" সফলভাবে তৈরি হয়েছে!`);
  };

  const handleDeleteCoupon = (couponId: string) => {
    const updated = coupons.filter((c) => c.id !== couponId);
    setCoupons(updated);
    showToast('কুপন মুছে ফেলা হয়েছে');
  };

  // Social Share Handlers
  const handleOpenShareProduct = (product: Product) => {
    setShareData({
      isOpen: true,
      title: `${product.nameBn} - মাত্র ৳${product.discountPrice}`,
      text: `${product.nameBn} কিনুন তৌহিদ বাজার থেকে সবচেয়ে কম দামে। ক্যাশ অন ডেলিভারি সুবিধা আছে!`,
      url: window.location.href,
      image: product.image
    });
  };

  const handleOpenSharePost = (post: SocialPost) => {
    setShareData({
      isOpen: true,
      title: post.titleBn,
      text: post.content,
      url: post.videoUrl || window.location.href,
      image: post.imageUrl
    });
  };

  const handleLikePost = (postId: string) => {
    setPosts((prev) =>
      prev.map((p) => (p.id === postId ? { ...p, likes: p.likes + 1 } : p))
    );
    showToast('পোস্টে লাইক দেওয়া হয়েছে ❤️');
  };

  // Reset demo data to default
  const handleResetToDefault = () => {
    storageService.resetAllToDefault();
    setProducts(storageService.getProducts());
    setOrders(storageService.getOrders());
    setCart(storageService.getCart());
    setWishlist(storageService.getWishlist());
    setAds(storageService.getAdvertisements());
    setCoupons(storageService.getCoupons());
    setPosts(storageService.getPosts());
    setSettings(storageService.getSettings());
    showToast('সমস্ত তথ্য সফলভাবে ডিফল্ট অবস্থায় ফিরিয়ে আনা হয়েছে!');
  };

  // Filter and sort products
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      const matchesCategory =
        selectedCategory === 'all' || p.category === selectedCategory;
      const matchesSearch =
        !searchQuery.trim() ||
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.nameBn.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.categoryBn.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.brand.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    }).sort((a, b) => {
      switch (sortBy) {
        case 'price_asc':
          return a.discountPrice - b.discountPrice;
        case 'price_desc':
          return b.discountPrice - a.discountPrice;
        case 'rating':
          return b.rating - a.rating;
        case 'newest':
          return b.id.localeCompare(a.id);
        case 'featured':
        default:
          return (b.isFeatured ? 1 : 0) - (a.isFeatured ? 1 : 0);
      }
    });
  }, [products, selectedCategory, searchQuery, sortBy]);

  // Flash Sale products
  const flashSaleProducts = useMemo(() => {
    return products.filter((p) => p.isFlashSale);
  }, [products]);

  // Advertisements by placement
  const topAd = ads.find((a) => a.placement === 'top_header' && a.isEnabled);
  const middleAd = ads.find((a) => a.placement === 'home_middle' && a.isEnabled);

  return (
    <SmartphoneFrame
      isAppViewMode={isAppViewMode}
      onToggleAppViewMode={handleToggleAppViewMode}
    >
      <div className="min-h-screen bg-slate-50 text-slate-800 font-sans selection:bg-emerald-500 selection:text-white flex flex-col relative">
        {/* Top Mobile App Installation Bar (PWA) */}
        <MobileAppInstallBanner onInstalled={() => showToast('তৌহিদ বাজার অ্যাপ ইনস্টল সফল হয়েছে!')} />

        {/* Toast Popup Notification */}
        {toastMessage && (
          <div className="fixed bottom-24 sm:bottom-6 left-1/2 -translate-x-1/2 z-50 bg-slate-900/95 text-white text-xs sm:text-sm font-semibold px-4 py-2.5 rounded-full shadow-2xl backdrop-blur-md border border-slate-700 flex items-center gap-2 animate-fade-in">
            <Check className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{toastMessage}</span>
          </div>
        )}

        {/* 1. Header (Top Bar, Logo, Search, Navigation, Cart/Tracking) */}
        <Header
          settings={settings}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          cartCount={cart.reduce((acc, item) => acc + item.quantity, 0)}
          cartTotal={cart.reduce((acc, item) => acc + item.product.discountPrice * item.quantity, 0)}
          wishlistCount={wishlist.length}
          onOpenCart={() => setIsCartOpen(true)}
          onOpenWishlist={() => setIsMenuSheetOpen(true)}
          onOpenTracking={() => {
            setTrackingInitialId('');
            setIsTrackingOpen(true);
          }}
          onOpenAdmin={() => setIsAdminOpen(true)}
          selectedCategory={selectedCategory}
          onSelectCategory={setSelectedCategory}
          products={products}
          onSelectProduct={setSelectedProduct}
        />

        {/* Mobile Story Categories Bar (App-like circular horizontal scroll) */}
        <MobileStoryCategories
          selectedCategory={selectedCategory}
          onSelectCategory={(catId) => {
            setSelectedCategory(catId);
            const el = document.getElementById('all-products-section');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}
          onOpenFlashSale={() => {
            const el = document.getElementById('flash-sale');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}
        />

        {/* Optional Top Header Advertisement */}
        {topAd && <AdvertisementBanner ad={topAd} />}

        {/* Main Page Body with bottom padding for mobile app dock bar */}
        <main className="flex-1 pb-28 sm:pb-12">
          {/* 2. Hero Banner Slider */}
          <HeroSlider onShopNow={() => {
            const el = document.getElementById('all-products-section');
            el?.scrollIntoView({ behavior: 'smooth' });
          }} />

          {/* 3. Category Icons Grid */}
          <CategoryList
            selectedCategory={selectedCategory}
            onSelectCategory={setSelectedCategory}
          />

          {/* 4. Flash Sale with Countdown Timer */}
          {flashSaleProducts.length > 0 && (
            <FlashSale
              products={flashSaleProducts}
              onAddToCart={handleAddToCart}
              onQuickBuy={handleQuickBuy}
              onSelectProduct={setSelectedProduct}
              onToggleWishlist={handleToggleWishlist}
              wishlist={wishlist}
              onShareProduct={handleOpenShareProduct}
            />
          )}

          {/* 5. Main Product Catalog ("সব পণ্য ও কালেকশন") */}
          <section id="all-products-section" className="my-10 max-w-7xl mx-auto px-4">
            {/* Section Header with Controls */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-200">
              <div>
                <div className="flex items-center gap-2">
                  <span className="bg-emerald-100 text-emerald-800 text-xs font-black px-2.5 py-0.5 rounded-full uppercase">
                    আমাদের শপ
                  </span>
                  <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                    {selectedCategory === 'all'
                      ? 'সব পণ্য ও কালেকশন (All Products)'
                      : `ক্যাটাগরি: ${products.find(p => p.category === selectedCategory)?.categoryBn || selectedCategory}`}
                  </h2>
                </div>
                <p className="text-xs sm:text-sm text-slate-500 mt-1">
                  তৌহিদ বাজারের সেরা মূল্যের খাঁটি ও মানসম্মত পণ্যের তালিকা
                </p>
              </div>

              {/* Filter & Sort Bar */}
              <div className="flex flex-wrap items-center gap-3">
                {/* Category Quick Selector Tabs */}
                <div className="flex items-center gap-1 bg-white border border-slate-200 p-1 rounded-2xl overflow-x-auto text-xs font-semibold">
                  {[
                    { id: 'all', label: 'সকল' },
                    { id: 'grocery', label: 'গ্রোসারি' },
                    { id: 'electronics', label: 'ইলেকট্রনিক্স' },
                    { id: 'fashion', label: 'ফ্যাশন' },
                    { id: 'home', label: 'হোম' },
                    { id: 'beauty', label: 'রূপচর্চা' }
                  ].map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => setSelectedCategory(cat.id)}
                      className={`px-3 py-1.5 rounded-xl transition-colors cursor-pointer ${
                        selectedCategory === cat.id
                          ? 'bg-emerald-600 text-white shadow-xs'
                          : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                      }`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>

                {/* Sorting Dropdown */}
                <div className="flex items-center gap-1.5 bg-white border border-slate-200 px-3 py-1.5 rounded-2xl text-xs">
                  <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as any)}
                    className="bg-transparent font-bold text-slate-700 focus:outline-none cursor-pointer"
                  >
                    <option value="featured">ফিচার্ড (Featured)</option>
                    <option value="price_asc">দাম: কম থেকে বেশি</option>
                    <option value="price_desc">দাম: বেশি থেকে কম</option>
                    <option value="rating">সর্বোচ্চ রেটিং</option>
                    <option value="newest">নতুন কালেকশন</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Search Query Feedback */}
            {searchQuery.trim() && (
              <div className="mt-4 p-3 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center justify-between text-xs text-emerald-900">
                <span>
                  "<strong>{searchQuery}</strong>" সম্পর্কিত <strong>{filteredProducts.length}</strong> টি পণ্য পাওয়া গেছে।
                </span>
                <button
                  onClick={() => setSearchQuery('')}
                  className="font-bold text-emerald-700 hover:underline cursor-pointer"
                >
                  ফিল্টার মুছুন
                </button>
              </div>
            )}

            {/* Product Cards Grid */}
            {filteredProducts.length === 0 ? (
              <div className="text-center py-16 bg-white rounded-3xl border border-slate-200 my-6 p-6">
                <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 mx-auto mb-3">
                  <PackageSearch className="w-8 h-8" />
                </div>
                <h3 className="font-bold text-slate-800 text-base">কোনো পণ্য পাওয়া যায়নি</h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
                  আপনার অনুসন্ধানের সাথে মেলে এমন কোনো পণ্য বর্তমানে তালিকায় নেই। ক্যাটাগরি পরিবর্তন করে দেখুন।
                </p>
                <button
                  onClick={() => {
                    setSelectedCategory('all');
                    setSearchQuery('');
                  }}
                  className="mt-4 bg-emerald-600 text-white text-xs font-bold px-5 py-2.5 rounded-full hover:bg-emerald-700 transition-colors cursor-pointer"
                >
                  সব পণ্য দেখুন
                </button>
              </div>
            ) : (
              <div className="mt-6 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 sm:gap-4 md:gap-5">
                {filteredProducts.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onAddToCart={handleAddToCart}
                    onQuickBuy={handleQuickBuy}
                    onSelectProduct={setSelectedProduct}
                    onToggleWishlist={handleToggleWishlist}
                    isWishlisted={wishlist.includes(product.id)}
                    onShareProduct={handleOpenShareProduct}
                  />
                ))}
              </div>
            )}
          </section>

          {/* 6. Mid-Page Advertisement Banner */}
          {middleAd && <AdvertisementBanner ad={middleAd} />}

          {/* 7. YouTube & Social Media Post Feed with Sharing */}
          <PostsSection
            posts={posts}
            onSharePost={handleOpenSharePost}
            onLikePost={handleLikePost}
          />
        </main>

        {/* 8. Comprehensive Footer with Links & Contacts */}
        <Footer
          settings={settings}
          onOpenAdmin={() => setIsAdminOpen(true)}
          onOpenTracking={() => {
            setTrackingInitialId('');
            setIsTrackingOpen(true);
          }}
          onSelectCategory={(catId) => {
            setSelectedCategory(catId);
            const el = document.getElementById('all-products-section');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}
        />

        {/* Floating WhatsApp Live Chat Button (positioned above bottom dock bar on mobile) */}
        <a
          href={getWhatsAppUrl(settings.whatsappNumber, 'আসসালামু আলাইকুম, আমি তৌহিদ বাজার থেকে কিছু পণ্য অর্ডার করতে চাই।')}
          target="_blank"
          rel="noreferrer"
          className="fixed bottom-20 right-4 sm:bottom-6 sm:right-6 z-40 bg-[#25D366] hover:bg-[#20ba59] active:scale-95 text-white p-3.5 sm:p-4 rounded-full shadow-2xl flex items-center justify-center gap-2 group transition-all cursor-pointer"
          title="সরাসরি হোয়াটসঅ্যাপে কথা বলুন"
        >
          <MessageCircle className="w-5 h-5 sm:w-6 sm:h-6 fill-white" />
          <span className="hidden sm:inline text-xs font-bold max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-300 ease-in-out whitespace-nowrap">
            হোয়াটসঅ্যাপে অর্ডার করুন
          </span>
        </a>

        {/* Native Mobile Bottom Navigation Dock */}
        <MobileBottomNav
          activeTab={activeMobileTab}
          cartCount={cart.reduce((acc, item) => acc + item.quantity, 0)}
          cartTotal={cart.reduce((acc, item) => acc + item.product.discountPrice * item.quantity, 0)}
          wishlistCount={wishlist.length}
          onNavigateTab={setActiveMobileTab}
          onOpenCart={() => setIsCartOpen(true)}
          onOpenCategories={() => setIsCategoryDrawerOpen(true)}
          onOpenMenu={() => setIsMenuSheetOpen(true)}
          onOpenFlashSale={() => {
            const el = document.getElementById('flash-sale');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}
        />

        {/* Mobile Category Drawer Sheet */}
        <MobileCategoryDrawer
          isOpen={isCategoryDrawerOpen}
          onClose={() => setIsCategoryDrawerOpen(false)}
          selectedCategory={selectedCategory}
          onSelectCategory={(catId) => {
            setSelectedCategory(catId);
            const el = document.getElementById('all-products-section');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}
        />

        {/* Mobile Menu & Quick Actions Sheet */}
        <MobileMenuSheet
          isOpen={isMenuSheetOpen}
          onClose={() => setIsMenuSheetOpen(false)}
          settings={settings}
          wishlistCount={wishlist.length}
          onOpenWishlist={() => {
            if (wishlist.length > 0) {
              showToast(`${wishlist.length} টি পছন্দের পণ্য সংরক্ষিত আছে`);
            } else {
              showToast('পছন্দের তালিকায় কোনো পণ্য নেই');
            }
          }}
          onOpenTracking={() => {
            setTrackingInitialId('');
            setIsTrackingOpen(true);
          }}
          onOpenAdmin={() => setIsAdminOpen(true)}
          onOpenShareApp={() => {
            handleOpenShareProduct({
              id: 'app',
              name: 'Tohid Bazar App',
              nameBn: 'তৌহিদ বাজার অনলাইন শপিং',
              brand: 'Tohid Bazar',
              sku: 'APP-01',
              description: 'তৌহিদ বাজার মোবাইল অ্যাপে কেনাকাটা করুন!',
              descriptionBn: 'তৌহিদ বাজার মোবাইল অ্যাপে কেনাকাটা করুন!',
              regularPrice: 0,
              discountPrice: 0,
              category: 'app',
              categoryBn: 'অ্যাপ',
              image: './icon.svg',
              images: ['./icon.svg'],
              stock: 100,
              isFlashSale: false,
              isFeatured: true,
              rating: 5,
              reviewCount: 120
            });
          }}
          onInstallApp={isInstallable ? install : undefined}
          isInstallable={isInstallable}
        />

        {/* Modals & Drawers */}
        {/* Product Detail Modal */}
        <ProductDetailModal
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
          onAddToCart={handleAddToCart}
          onQuickBuy={handleQuickBuy}
          onToggleWishlist={handleToggleWishlist}
          isWishlisted={selectedProduct ? wishlist.includes(selectedProduct.id) : false}
          onShareProduct={handleOpenShareProduct}
          settings={settings}
        />

        {/* Social Share Modal */}
        <SocialShareModal
          isOpen={shareData.isOpen}
          onClose={() => setShareData({ ...shareData, isOpen: false })}
          title={shareData.title}
          text={shareData.text}
          url={shareData.url}
          image={shareData.image}
        />

        {/* Cart Drawer */}
        <CartDrawer
          isOpen={isCartOpen}
          onClose={() => setIsCartOpen(false)}
          cart={cart}
          onUpdateQuantity={handleUpdateQuantity}
          onRemoveItem={handleRemoveFromCart}
          deliveryArea={deliveryArea}
          onChangeDeliveryArea={setDeliveryArea}
          appliedCoupon={appliedCoupon}
          onApplyCoupon={handleApplyCoupon}
          onRemoveCoupon={handleRemoveCoupon}
          onProceedToCheckout={() => setIsCheckoutOpen(true)}
          insideDhakaCharge={settings.insideDhakaCharge}
          outsideDhakaCharge={settings.outsideDhakaCharge}
        />

        {/* Checkout Modal */}
        <CheckoutModal
          isOpen={isCheckoutOpen}
          onClose={() => setIsCheckoutOpen(false)}
          cart={cart}
          appliedCoupon={appliedCoupon}
          settings={settings}
          deliveryArea={deliveryArea}
          onChangeDeliveryArea={setDeliveryArea}
          onSubmitOrder={handleSubmitOrder}
        />

        {/* Order Success Modal (With Confetti & WhatsApp button) */}
        <OrderSuccessModal
          order={successOrder}
          onClose={() => setSuccessOrder(null)}
          onTrackOrder={(orderId) => {
            setTrackingInitialId(orderId);
            setIsTrackingOpen(true);
          }}
          settings={settings}
        />

        {/* Live Order Tracking Modal */}
        <OrderTrackingModal
          isOpen={isTrackingOpen}
          onClose={() => setIsTrackingOpen(false)}
          orders={orders}
          initialOrderId={trackingInitialId}
          settings={settings}
        />

        {/* Admin Panel (Control Center) */}
        <AdminPanel
          isOpen={isAdminOpen}
          onClose={() => setIsAdminOpen(false)}
          products={products}
          onAddProduct={handleAddProduct}
          onUpdateProduct={handleUpdateProduct}
          onDeleteProduct={handleDeleteProduct}
          orders={orders}
          onUpdateOrderStatus={handleUpdateOrderStatus}
          ads={ads}
          onToggleAd={handleToggleAd}
          onAddAd={handleAddAd}
          onDeleteAd={handleDeleteAd}
          coupons={coupons}
          onAddCoupon={handleAddCoupon}
          onDeleteCoupon={handleDeleteCoupon}
          settings={settings}
          onUpdateSettings={(newSettings) => {
            setSettings(newSettings);
            showToast('ওয়েবসাইট সেটিংস সংরক্ষিত হয়েছে!');
          }}
          onResetToDefault={handleResetToDefault}
        />
      </div>
    </SmartphoneFrame>
  );
}
