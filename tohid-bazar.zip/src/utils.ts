/**
 * Helper utilities for formatting phone numbers and WhatsApp URLs
 */

export const cleanWhatsAppNumber = (phone: string): string => {
  if (!phone) return '';
  let clean = phone.replace(/[^0-9]/g, '');
  // If Bangladeshi local number format (e.g. 01858683583 -> 11 digits starting with 01), prefix country code 88
  if (clean.startsWith('01') && clean.length === 11) {
    clean = '88' + clean;
  }
  return clean;
};

export const getWhatsAppUrl = (phone: string, message: string = ''): string => {
  const clean = cleanWhatsAppNumber(phone);
  const query = message ? `&text=${encodeURIComponent(message)}` : '';
  return `https://api.whatsapp.com/send?phone=${clean}${query}`;
};
